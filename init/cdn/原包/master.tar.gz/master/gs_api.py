# encoding: utf-8
import requests,traceback,json,os,re
from flask import Blueprint, request

app_gs = Blueprint('app_gs', __name__)

log_path = '/var/log/httpguard/telegram.log'


@app_gs.route("/")
def index():
    print "hello"
    return "ok"


@app_gs.route('/telegram/send', methods=['POST'])
def telegram_send():
    try:
        chat_id = request.form["chat_id"]
        req_msg = request.form["text"]
        send_msg(chat_id, req_msg)
    except:
        traceback.print_exc(file=open(log_path,'a+'))
    return "success"


@app_gs.route('/telegram/callback', methods=['POST'])
def telegram_callback():
    try:
        data = request.get_json(force=True)
        message = json.dumps(data)
        log(message)
        chat_id = data["message"]["chat"]["id"]
        text = data["message"]["text"].encode('utf-8')
        texts = text.split()
        if texts[0] == "/get":
            url = texts[1]
            if url.find("|")== -1:
                curl_content = os.popen(
                    "curl -L  -w '--tiao--\n%{http_code}\t%{time_total}\t%{url_effective}\n' " + url).read()
                total_content = curl_content.split("--tiao--")
                content = total_content[0]
                title=re.search(r'(<title>.*?</title>)',content)
                try:
                    if title.group(1) == "":
                    	total_text=""
                    	for content_n in content.split("\n"):
                                total_text=total_text+"\n"+content_n
        	    else:
                    	total_text=title.group(1)
                except:
                    total_text=curl_content
                code_content = total_content[1]
                code = code_content.split()[0]
                time_total = code_content.split()[1]
                redirect = code_content.split()[2]
                text = total_text + "\n\n" + "总时间:" + time_total + "s" + "\t代码:" + code + "\t重定向页面:" + redirect
                handle_msg(chat_id, text)
        elif texts[0] == "/rejump" :
                os.popen("docker exec -it a647ec59bfcd  /opt/py3/bin/python3  /opt/coco/cocod restart")
                text="ok"
                handle_msg(chat_id, text)
    except:
        traceback.print_exc(file=open(log_path,'a+'))
    return "success"


def log(msg):
    log_file = open(log_path, 'a+')
    log_file.write(msg+"\n")
    log_file.flush()
    log_file.close()


def send_msg(chat_id, msg):
    data = {
        "chat_id": chat_id,
        "text": msg
    }
    requests.post('https://api.telegram.org/bot792640218:AAFouCZ80FfM21SG9VU8Hpaez4FVOMSWdhY/sendMessage', data=data)


def handle_msg(chat_id, text):
    log("char_id:"+str(chat_id))
    log("msg:"+text)
    send_msg(chat_id, text)

