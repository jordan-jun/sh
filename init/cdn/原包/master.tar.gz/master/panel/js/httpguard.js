Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};

function header() {
    document.writeln("        <div class=\'row\'>");
    document.writeln("            <div class=\'col-lg-4 col-lg-offset-4 ontopDiv\'>");
    document.writeln("                <div id=\'msg\'  hidden=true class=\'alert alert-info alert-dismissable\'>");
    document.writeln("                        <button type=\'button\' class=\'close\' data-dismiss=\'alert\' aria-hidden=\'true\'>×</button>");
    document.writeln("                        <span></span>");
    document.writeln("                </div>");
    document.writeln("            </div>");
    document.writeln("        </div>");

    document.writeln("        <header class=\'header\'>");
    document.writeln("            <a href=\'index.html\' class=\'logo\'>");
    document.writeln("                <!-- Add the class icon to your logo image or logo icon to add the margining -->");
    document.writeln("                游石CDN");
    document.writeln("            </a>");
    document.writeln("            <!-- Header Navbar: style can be found in header.less -->");
    document.writeln("            <nav class=\'navbar navbar-static-top\' role=\'navigation\'>");
    document.writeln("                <!-- Sidebar toggle button-->");
    document.writeln("                <a href=\'#\' class=\'navbar-btn sidebar-toggle\' data-toggle=\'offcanvas\' role=\'button\'>");
    document.writeln("                    <span class=\'sr-only\'>Toggle navigation</span>");
    document.writeln("                    <span class=\'icon-bar\'></span>");
    document.writeln("                    <span class=\'icon-bar\'></span>");
    document.writeln("                    <span class=\'icon-bar\'></span>");
    document.writeln("                </a>");
    document.writeln("                <div class=\'navbar-right\'>");
    document.writeln("                    <ul class=\'nav navbar-nav\'>");
    document.writeln("                        <!-- Messages: style can be found in dropdown.less-->");
    document.writeln("                        <li class=\'dropdown messages-menu\'>");
    document.writeln("                            <a href=\'#\' onclick=\'window.location.href=\"/admin/message.html\";\' class=\'dropdown-toggle\' data-toggle=\'dropdown\'>");
    document.writeln("                                <i class=\'fa fa-envelope\'></i>");
    document.writeln("                                <span id=\'msg-unread\' class=\'label label-success\'>?</span>");
    document.writeln("                            </a>");
    document.writeln("                        </li>");
    document.writeln("");    
    document.writeln("                        <li class=\'dropdown messages-menu\'>");
    document.writeln("                            <a onclick=\'logout()\' href=\'#\' class=\'dropdown-toggle\' data-toggle=\'dropdown\'>");
    document.writeln("                                <i class=\'fa fa-sign-out\'></i>");
    document.writeln("                            </a>");
    document.writeln("                        </li>");
    document.writeln("");
    document.writeln("                    </ul>");
    document.writeln("                </div>                ");
    document.writeln("            </nav>");
    document.writeln("        </header>");    
}

function nav() {
    document.writeln("                        <section class=\'sidebar\'>");
    document.writeln("                            <!-- sidebar menu: : style can be found in sidebar.less -->");
    document.writeln("                            <ul class=\'sidebar-menu\'>");
    document.writeln("                                <li>");
    document.writeln("                                    <a href=\'index.html\'>");
    document.writeln("                                        <i class=\'fa fa-dashboard\'></i> <span>面板首页</span>");
    document.writeln("                                    </a>");
    document.writeln("                                </li>");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-server\'></i>");
    document.writeln("                                        <span>节点管理</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'group.html\'><i class=\'fa fa-angle-double-right\'></i>分组</a></li>");
    document.writeln("                                        <li><a href=\'nodes.html\'><i class=\'fa fa-angle-double-right\'></i>节点</a></li>");
    document.writeln("                                    </ul>");
    document.writeln("                                </li>");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-internet-explorer\'></i>");
    document.writeln("                                        <span>网站管理</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'all-sites.html\'><i class=\'fa fa-angle-double-right\'></i>所有网站</a></li>");    
    document.writeln("                                        <li><a href=\'line-group.html\'><i class=\'fa fa-angle-double-right\'></i>线路分组</a></li>");    
    document.writeln("                                        <li><a href=\'dns-provider.html\'><i class=\'fa fa-angle-double-right\'></i>DNS配置</a></li>");
    document.writeln("                                        <li><a href=\'nginx-config.html\'><i class=\'fa fa-angle-double-right\'></i>Nginx配置</a></li>");    
    document.writeln("                                    </ul>");
    document.writeln("                                </li>                                                              ");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-list\'></i>");
    document.writeln("                                        <span>防护规则</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'rules.html\'><i class=\'fa fa-angle-double-right\'></i> 规则组</a></li>");
    document.writeln("                                        <li><a href=\'matcher.html\'><i class=\'fa fa-angle-double-right\'></i> 匹配器</a></li>");
    document.writeln("                                        <li><a href=\'filter.html\'><i class=\'fa fa-angle-double-right\'></i> 过滤器</a></li>");
    document.writeln("                                        <li><a href=\'action.html\'><i class=\'fa fa-angle-double-right\'></i> 动作</a></li>");
    document.writeln("                                        <li><a href=\'allow-spider.html\'><i class=\'fa fa-angle-double-right\'></i> 允许爬虫</a></li>");        
    document.writeln("                                        <li><a href=\'other.html\'><i class=\'fa fa-angle-double-right\'></i> 其它</a></li>");
    document.writeln("                                    </ul>");
    document.writeln("                                </li>");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-desktop\'></i>");
    document.writeln("                                        <span>监控中心</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'traffic.html\'><i class=\'fa fa-angle-double-right\'></i> 流量统计</a></li>");    
    document.writeln("                                        <li><a href=\'domain-monitor.html\'><i class=\'fa fa-angle-double-right\'></i> 域名监控</a></li>");
    document.writeln("                                        <li><a href=\'node-monitor.html\'><i class=\'fa fa-angle-double-right\'></i> 节点监控</a></li>");
    document.writeln("                                        <li><a href=\'top50-ip.html\'><i class=\'fa fa-angle-double-right\'></i> 前50(IP)</a></li>");
    document.writeln("                                        <li><a href=\'top50-url.html\'><i class=\'fa fa-angle-double-right\'></i> 前50(URL)</a></li>");
    document.writeln("                                        <li><a href=\'top50-host.html\'><i class=\'fa fa-angle-double-right\'></i> 前50(域名)</a></li>");    
    document.writeln("                                        <li><a href=\'realtime-log.html\'><i class=\'fa fa-angle-double-right\'></i> 实时日志</a></li>");        
    document.writeln("                                    </ul>");
    document.writeln("                                </li>    ");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-bell\'></i>");
    document.writeln("                                        <span>告警管理</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'triggers.html\'><i class=\'fa fa-angle-double-right\'></i> 告警配置</a></li>");    
    document.writeln("                                        <li><a href=\'trigger-event.html\'><i class=\'fa fa-angle-double-right\'></i> 告警事件</a></li>");
    document.writeln("                                        <li><a href=\'contacts.html\'><i class=\'fa fa-angle-double-right\'></i> 联系人</a></li>");
    document.writeln("                                        <li><a href=\'contact-group.html\'><i class=\'fa fa-angle-double-right\'></i> 联系人组</a></li>");      
    document.writeln("                                    </ul>");
    document.writeln("                                </li>    ");    
    document.writeln("                                <li>");
    document.writeln("                                    <a href=\'maintain.html\'>");
    document.writeln("                                        <i class=\'fa fa-wrench\'></i> <span>维护操作</span>");
    document.writeln("                                    </a>");
    document.writeln("                                </li>");
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-shopping-bag\'></i>");
    document.writeln("                                        <span>套餐管理</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'all-product.html\'><i class=\'fa fa-angle-double-right\'></i> 基础套餐</a></li>");
    document.writeln("                                        <li><a href=\'all-product-ext.html\'><i class=\'fa fa-angle-double-right\'></i> 扩展套餐</a></li>");    
    document.writeln("                                    </ul>");
    document.writeln("                                </li>    ");       
    document.writeln("                                <li class=\'treeview\'>");
    document.writeln("                                    <a href=\'#\'>");
    document.writeln("                                        <i class=\'fa fa-cog\'></i>");
    document.writeln("                                        <span>系统管理</span>");
    document.writeln("                                        <i class=\'fa fa-angle-left pull-right\'></i>");
    document.writeln("                                    </a>");
    document.writeln("                                    <ul class=\'treeview-menu\'>");
    document.writeln("                                        <li><a href=\'all-user.html\'><i class=\'fa fa-angle-double-right\'></i> 用户管理</a></li>");
    document.writeln("                                        <li><a href=\'all-task.html\'><i class=\'fa fa-angle-double-right\'></i> 任务管理</a></li>");    
    document.writeln("                                        <li><a href=\'setting.html\'><i class=\'fa fa-angle-double-right\'></i> 其它设置</a></li>");      
    document.writeln("                                    </ul>");
    document.writeln("                                </li>    ");            
    document.writeln("                            </ul>");
    document.writeln("                        </section>");
    set_nav_active();
}

function set_nav_active() {
    var pathname = window.location.pathname;
    if ($.inArray(pathname, ["/admin/index.html"]) != -1) {
        $(".sidebar-menu").children(":eq(0)").addClass("active");
    }
    else if ($.inArray(pathname, ["/admin/add-group.html","/admin/nodes.html","/admin/add-node.html","/admin/group.html"]) != -1) {
        $(".sidebar-menu").children(":eq(1)").addClass("active");
    }  
    else if ($.inArray(pathname, ["/admin/nginx-config.html", "/admin/all-sites.html","/admin/add-site.html","/admin/site.html","/admin/dns-provider.html","/admin/line-group.html","/admin/line-nodes.html","/admin/add-line-group.html","/admin/node-line.html"]) != -1) {
        $(".sidebar-menu").children(":eq(2)").addClass("active");
    } 
    else if ($.inArray(pathname, ["/admin/rules.html","/admin/rule.html","/admin/matcher.html","/admin/match.html","/admin/filter.html","/admin/action.html","/admin/other.html","/admin/auto-cc.html","/admin/allow-spider.html"]) != -1) {
        $(".sidebar-menu").children(":eq(3)").addClass("active");
    }
    else if ($.inArray(pathname, ["/admin/traffic.html", "/admin/domain-monitor.html","/admin/node-monitor.html","/admin/top50-url.html","/admin/top50-ip.html","/admin/realtime-log.html","/admin/top50-host.html"]) != -1) {
        $(".sidebar-menu").children(":eq(4)").addClass("active");
    } 
    else if ($.inArray(pathname, ["/admin/trigger.html","/admin/triggers.html", "/admin/trigger-event.html","/admin/add-contact.html","/admin/contact.html","/admin/contacts.html","/admin/contact-group.html","/admin/add-trigger.html","/admin/add-contact-group.html"]) != -1) {
        $(".sidebar-menu").children(":eq(5)").addClass("active");
    }     
    else if ($.inArray(pathname, ["/admin/maintain.html"]) != -1) {
        $(".sidebar-menu").children(":eq(6)").addClass("active");
    }  
    else if ($.inArray(pathname, ["/admin/all-product-ext.html","/admin/all-product.html","/admin/add-product.html","/admin/product.html","/admin/add-product-ext.html","/admin/product-ext.html"]) != -1) {
        $(".sidebar-menu").children(":eq(7)").addClass("active");
    } 
    else if ($.inArray(pathname, ["/admin/all-user.html","/admin/setting.html","/admin/add-user.html","/admin/user.html","/admin/all-task.html"]) != -1) {
        $(".sidebar-menu").children(":eq(8)").addClass("active");
    }         
    else if ($.inArray(pathname, ["/admin/upgrade.html"]) != -1) {
        $(".sidebar-menu").children(":eq(9)").addClass("active");
    }                                    
    (function($) {
        "use strict";

        $.fn.tree = function() {

            return this.each(function() {
                var btn = $(this).children("a").first();
                var menu = $(this).children(".treeview-menu").first();
                var isActive = $(this).hasClass('active');

                //initialize already active menus
                if (isActive) {
                    menu.show();
                    btn.children(".fa-angle-left").first().removeClass("fa-angle-left").addClass("fa-angle-down");
                }
                //Slide open or close the menu on link click
                btn.click(function(e) {
                    e.preventDefault();
                    if (isActive) {
                        //Slide up to close menu
                        menu.slideUp();
                        isActive = false;
                        btn.children(".fa-angle-down").first().removeClass("fa-angle-down").addClass("fa-angle-left");
                        btn.parent("li").removeClass("active");
                    } else {
                        //Slide down to open menu
                        menu.slideDown();
                        isActive = true;
                        btn.children(".fa-angle-left").first().removeClass("fa-angle-left").addClass("fa-angle-down");
                        btn.parent("li").addClass("active");
                    }
                });

                /* Add margins to submenu elements to give it a tree look */
                menu.find("li > a").each(function() {
                    var pad = parseInt($(this).css("margin-left")) + 10;

                    $(this).css({"margin-left": pad + "px"});
                });

            });

        };


    }(jQuery));
}

function logout() {
    $.ajax({
        url: '/logout?r=' + Math.random(),
        type: 'post',
        processData: false,
        success: function( data, textStatus, jQxhr ){
            window.location.href='/admin/login.html';
        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
    });
}

function check_login () {
    $.ajax({
        url: '/login-verify?r=' + Math.random() ,
        type: 'get',
        dataType: 'json',
        success: function( data, textStatus, jQxhr ){
            msg = data.msg
            state = data.state
            path = window.location.pathname
            if (state == "success") {
                if (path == "/admin/login.html" ) {
                    window.location.href='/admin/index.html';
                }
            }
           else {
                if (path != "/admin/login.html") {
                    window.location.href='/admin/login.html';
                }
           }
        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
    });
}

function user_check_login () {
    $.ajax({
        url: '/login-verify?r=' + Math.random() ,
        type: 'get',
        dataType: 'json',
        success: function( data, textStatus, jQxhr ){
            msg = data.msg
            state = data.state
            path = window.location.pathname
            if (state == "success") {
                if (path == "/user/login.html" ) {
                    window.location.href='/user/index.html';
                }
            }
           else {
                if (path != "/user/login.html") {
                    window.location.href='/user/login.html';
                }
           }
        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
    });
}

function getCookie(c_name)
{
    if (document.cookie.length>0)
      {
      c_start=document.cookie.indexOf(c_name + "=")
      if (c_start!=-1)
        { 
        c_start=c_start + c_name.length+1 
        c_end=document.cookie.indexOf(";",c_start)
        if (c_end==-1) c_end=document.cookie.length
        return unescape(document.cookie.substring(c_start,c_end))
        } 
      }
    return ""
}

function setCookie(c_name,value,expiredays)
{
    var exdate=new Date()
    exdate.setDate(exdate.getDate()+expiredays)
    document.cookie=c_name+ "=" +escape(value)+
    ((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
}

function getQueryString(name) { 
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
    var r = window.location.search.substr(1).match(reg); 
    if (r != null) return decodeURI(r[2]); return null; 
} 

setTimeout(get_msg_unread,5000)
function get_msg_unread () {
    $.ajax({
        url: '/get-msg-unread?r=' + Math.random() ,
        type: 'get',
        dataType: 'json',
        success: function( data, textStatus, jQxhr ){
            msg = data.msg
            count = data.count
            state = data.state
            if (state == "success") {
                if (count > 9) {
                    count = 9;
                };
                $("#msg-unread").html(count)
                var msg_str = ""
                $.each(msg, function (key, val) {
                    msg_str = msg_str + "<br>" + val
                });
                if (msg_str != "") {
                    $("#msg span").html(msg_str)
                    $("#msg").slideDown("slow");
                    setTimeout("$('#msg').slideUp(\"slow\");",4500)
                }    

                setTimeout(get_msg_unread,5000)
            }
        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
    });
}
