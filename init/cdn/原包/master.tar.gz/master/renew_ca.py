# -*- coding: utf-8 -*-

from sqlalchemy import desc
from time import sleep
from public_func import make_msg
import threading
import Queue
import json
import zlib
import json
import time
import os
import datetime
import sys
import subprocess
import re
from route import create_task

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import Config, Message, db, Site, Line_group


threadLock = threading.Lock()
SHARE_Q = Queue.Queue()  
_WORKER_THREAD_NUM = 1
_NEED_SYNC_NGINX = False


class MyThread(threading.Thread) :

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

def update_ca(id, key, crt):
    site = Site.query.filter_by(id=id).first()
    site.key = key
    site.crt = crt
    db.session.commit()
    db.session.close()

def worker() :
    global SHARE_Q
    global _NEED_SYNC_NGINX
    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        domain = data["domain"]
        site_id = data["site_id"]
        user_id = data["user_id"]
        line_group_id = data["line_group_id"]
        main_domain = domain.split()[0]
        key_path = os.path.join("/root/.acme.sh/",main_domain,main_domain + ".key")
        crt_path = os.path.join("/root/.acme.sh/",main_domain,"fullchain.cer")
        cmd_list = ["/root/.acme.sh/acme.sh","--issue","--standalone","--home","/root/.acme.sh/", "--httpport","8866","--force"]
        for i in domain.split():
            cmd_list.append("-d")
            cmd_list.append(i)

        title = u"domain {main_domain} renew ca".format(main_domain=main_domain)
        type = "renew_ca"
        res = domain
        level = "failed"
        try:
            subprocess.check_output(cmd_list,stderr=subprocess.STDOUT)
            if not os.path.exists(key_path) or not os.path.exists(crt_path):
                data = "{key_path} or {crt_path} is not found.".format(key_path=key_path,crt_path=crt_path)
                make_msg(title, data, user_id, type, res, level)
                continue

            with open(key_path,"r") as fp:
                key = fp.read()

            with open(crt_path,"r") as fp:
                crt = fp.read()
            
            update_ca(site_id, key, crt)
            level = "success"
            data = None
            make_msg(title, data, user_id, type, res, level)
            line_group = Line_group.query.filter_by(id=line_group_id).first()
            nodes = line_group.nodes
            sync_sites = []
            for node in nodes:
                node_id = node.id
                enable = node.enable
                if not enable:
                    continue

                value = json.dumps({"node_id":node_id,"site_id":site_id,"domain":domain})
                sync_sites.append(value)
                
            create_task("sync_site", domain, json.dumps(sync_sites), user_id)

            db.session.close()
            
        except subprocess.CalledProcessError as e:
            data = re.sub(r'\[.*?\]','',e.output)
            make_msg(title, data, user_id, type, res, level)

def is_pem_nearly_expire(data):
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    cert = x509.load_pem_x509_certificate(str(data), default_backend())
    now = time.time()
    expire = (cert.not_valid_after - datetime.datetime(1970, 1, 1)).total_seconds()
    return (expire - now) < 29*3600*24

def main():
    global SHARE_Q
    global _NEED_SYNC_NGINX
    threads = []
    sites = Site.query.filter( (Site.enable_https==True) & (Site.ca_type=="letsencrypt") & (Site.crt != "") & (Site.key != "") ).all()
    for site in sites:
        domain = site.domain
        crt = site.crt
        site_id = site.id
        user_id = site.user_id
        line_group_id = site.line_group_id
        if not is_pem_nearly_expire(crt):
            continue

        main_domain = domain.split()[0]
        title = u"domain {main_domain} renew ca".format(main_domain=main_domain)
        type = "renew_ca"
        res = site_id
        level = "failed"


        data = {"domain":domain,"site_id":site_id,"line_group_id":line_group_id,"user_id":user_id}
        SHARE_Q.put(data)

    for i in xrange(_WORKER_THREAD_NUM) :
        thread = MyThread(worker)
        thread.start()
        threads.append(thread)

    for thread in threads :
        thread.join()

    db.session.commit()
    db.session.close()

if __name__ == '__main__':
    main()