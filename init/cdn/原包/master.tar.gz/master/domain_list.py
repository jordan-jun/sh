# -*- coding: utf-8 -*-
import os
os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Dns_provider, Node, Config, Task
from public_func import make_msg, dnsdotcom_sign, mark_task_start, mark_task_success, mark_task_failed, mark_task_del
from sqlalchemy import desc
import app
from time import sleep
import time
import requests
import json
import ntpath
import sys
import datetime
from cloudxns.api import *
import httplib
import socket
from collections import OrderedDict

def heartbeat(name):
    heartbeat_file = os.path.join("/tmp",name + ".heartbeat")
    with open(heartbeat_file,"w") as fp:
        fp.write("")

def get_dnspod_domains(auth):
    auth = json.loads(auth)
    id = auth["id"]
    token = auth["token"]
    login_token = "{id},{token}".format(id=id, token=token)

    try:
        data = {"login_token":login_token,"format":"json"}
        headers = {"User-Agent":"python requests client/1.0.0(admin@centos.bz)"}
        url = 'https://dnsapi.cn/Domain.List'
        r = requests.post(url,data=data,timeout=10,headers=headers)
        status_code = r.status_code
        if status_code != 200:
            return False, "failed: {url} return status code: {status_code}".format(status_code=status_code,url=url)

        content = r.content

        try:
            content = json.loads(content)
        except ValueError:
            return False, "failed: {url} return a invalid json: {content}".format(content=content,url=url)

        try:
            status = content["status"]
            code = status["code"]
            message = status["message"]
        except KeyError:
            return False, u"failed: {url} return a json without status or msg, content:{content}".format(content=content,url=url)
        if int(code) != 1:
            return False, u"failed: {url} code not eq 1, message:{message}".format(message=message,url=url)

        domains = []
        for d in content["domains"]:
            id = d["id"]
            domain = d["name"]
            domains.append({"id":id,"domain":domain})

        return domains,None    

    except requests.exceptions.Timeout:
        return False, "failed: {url} timeout".format(url=url)

    except requests.exceptions.ConnectionError:
        return False, "failed: {url} timeout".format(url=url)


def get_cloudxns_domains(auth):
    try:
        auth = json.loads(auth)
        api_key = auth["api_key"]
        secret_key = auth["secret_key"]
        api = Api(api_key=api_key, secret_key=secret_key)
        result = api.domain_list()
        result = json.loads(result)
        code = result['code']
        message = result['message']
        if int(code) != 1:
            return False, message

    except httplib.ResponseNotReady:
        return False, "timeout"

    except socket.error:
        return False, "ConnectionError"

    domains = []
    for d in result['data']:
        id = d["id"]
        domain = d["domain"][:-1]
        domains.append({"id":id,"domain":domain})

    return domains, None

def get_dnsdotcom_domains(auth):
    try:
        auth = json.loads(auth)
        api_key = auth["api_key"]
        api_secret = auth["api_secret"]
        payload = dnsdotcom_sign({}, api_key, api_secret)
        r = requests.get("https://www.dns.com/api/domain/list/",params=payload)
        result = r.content
        result = json.loads(result)
        code = result['code']
        message = result['message']
        if int(code) != 0:
            return False, message

    except httplib.ResponseNotReady:
        return False, "timeout"

    except socket.error:
        return False, "ConnectionError"

    domains = []
    for d in result['data']['data']:
        id = d["domainsID"]
        domain = d["domains"]
        domains.append({"id":id,"domain":domain})

    return domains, None

def get_domain_list(dns, auth):
    if dns == "dnspod":
        return get_dnspod_domains(auth)

    elif dns == "cloudxns":
        return get_cloudxns_domains(auth)

def update_domain_list(dns, domains):
    dns_provider = Dns_provider.query.filter_by(dns=dns).first()
    dns_provider.domains = domains

    Config.query.filter_by(name="get_domain_list",value=dns).delete()
    db.session.commit()
    db.session.close()


def main():
    sleep_time = 5
    # 获取get_domain_list任务
    task = Task.query.filter( (Task.type=="get_domain_list") & (Task.delflag == 0) & ( Task.state != "success") ).first()
    if task is None:
        db.session.close()
        return sleep_time

    dns = task.value
    id = task.id
    # 开始
    mark_task_start(id, 1)

    title = u"get {dns} domain list".format(dns=dns)
    user_id = 1
    type = "domain_list"
    res = dns
    level = "failed"

    dns_provider = Dns_provider.query.filter_by(dns=dns).first()
    auth = dns_provider.auth        
    domain_list, err = get_domain_list(dns, auth)
    if err is None:
        domain_list_json = json.dumps(domain_list)
        update_domain_list(dns, domain_list_json)
        data = domain_list_json
        level = "success"
        make_msg(title, data, user_id, type, res, level)
        mark_task_success(id, data)
    else:
        sleep_time = 60
        data = "{err}\nretry after {sleep_time}s.".format(err=err,sleep_time=sleep_time)
        make_msg(title, data, user_id, type, res, level)
        mark_task_failed(id, data)

    db.session.close()
    return sleep_time
    

if __name__ == '__main__':
    main()