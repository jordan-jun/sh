## 配置环境
### 安装mysql
```
MYSQL_PASS=root
cat <<MYSQL_PRESEED | debconf-set-selections
mysql-server-5.5 mysql-server/root_password password $MYSQL_PASS
mysql-server-5.5 mysql-server/root_password_again password $MYSQL_PASS
mysql-server-5.5 mysql-server/start_on_boot boolean true
MYSQL_PRESEED
apt-get -y install mysql-server
```
### 创建数据库
```
mysql -uroot -proot -e "CREATE DATABASE guard CHARSET=UTF8;"
```
### 安装依赖
```
apt-get -y install python-pip gcc python-dev libmysqlclient-dev git
```
### 安装python模块
```
pip install MySQL-python
pip install Flask==0.12.2
pip install requests
pip install flask_sqlalchemy==2.2
pip install timeout_decorator
pip install pycrypto
pip install supervisor

cd /tmp
git clone https://github.com/Supervisor/meld3
cd meld3
python setup.py install
```
