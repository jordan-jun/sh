# -*- coding: utf-8 -*-

import threading
import Queue
import requests
import json
import time
import re
import ntpath
import sys
import os
import item_func
from sqlalchemy import desc
import datetime
from email.mime.text import MIMEText
from email.header import Header
import smtplib
from sqlalchemy import desc
from public_func import make_msg

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Trigger_config, Trigger_event, Config, Contact_group

SHARE_Q = Queue.Queue()  
_WORKER_THREAD_NUM = 10

class MyThread(threading.Thread):

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

def send_mail(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data):
    if smtp_ip is None or smtp_port is None or smtp_user is None or smtp_pwd is None:
        return u"smtp未配置或配置不完整"

    if smtp_ip == "" or smtp_port == "" or smtp_user == "" or smtp_pwd == "":
        return u"smtp未配置或配置不完整"

    emails = []
    groups = Contact_group.query.filter(Contact_group.id.in_(contact_group)).all()
    for group in groups:
        res = group.contacts
        for r in res:
            emails.append(r.email)

    msg = MIMEText(data, 'plain', 'utf-8')
    msg['From'] = smtp_user
    msg['To'] = ";".join(emails)
    msg['Subject'] = Header(title, 'utf-8').encode()

    try:
        if smtp_ssl == "1":
            server = smtplib.SMTP_SSL(smtp_ip, int(smtp_port))
        else:
            server = smtplib.SMTP(smtp_ip, int(smtp_port))

        server.set_debuglevel(1)
        server.login(smtp_user, smtp_pwd)
        server.sendmail(smtp_user, emails, msg.as_string())
        server.quit()
    except smtplib.SMTPAuthenticationError:
        return "Authentication failure"
    except smtplib.SMTPConnectError:
        return "SMTPConnectError"

    db.session.close()

def send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id):
    err = None
    if contact_group != "":
        err = send_mail(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data)

    if send_to_msg_center:
        type = item
        level = None
        make_msg(title, data, user_id, type, res, level)

    return err

def worker() :
    global SHARE_Q
    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        item = data.item
        period = data.period
        func = data.func
        op = data.op
        value = data.value
        tid = data.id
        user_id = data.user_id
        continue_times = data.continue_times
        silent = data.silent
        recover_notify = data.recover_notify
        contact_group = data.contact_group
        tname = data.name
        send_to_msg_center = data.send_to_msg_center

        item_re = re.match(r"(.*?)\.(.*?)\[(.*)\]",item).groups()
        class_name = item_re[0]
        method_name = item_re[1]
        args = item_re[2]
        triggers = getattr(getattr(item_func,class_name),method_name)(user_id, period, func, op, value, args)
        now = datetime.datetime.now()
        for trigger in triggers:
            print item
            print trigger
            cond = trigger[0]
            res = trigger[1]
            val = trigger[2]

            event = Trigger_event.query.filter( (Trigger_event.trigger_id == tid) & (Trigger_event.res == res) & (Trigger_event.state == 1) ).order_by(desc(Trigger_event.id)).first()
            smtp_config = Config.query.filter( (Config.name == "smtp_ip") |  (Config.name == "smtp_ssl") |  (Config.name == "smtp_port") |  (Config.name == "smtp_user") |  (Config.name == "smtp_pwd")).all()
            smtp_ip = None
            smtp_ssl = None
            smtp_port = None
            smtp_user = None
            smtp_pwd = None
            if smtp_config is not None:
                for c in smtp_config:
                    if c.name == "smtp_ip":
                        smtp_ip = c.value
                    elif c.name == "smtp_ssl":
                        smtp_ssl = c.value
                    elif c.name == "smtp_port":
                        smtp_port = c.value
                    elif c.name == "smtp_user":
                        smtp_user = c.value
                    elif c.name == "smtp_pwd":
                        smtp_pwd = c.value

            title = u'【告警】{tname} 资源：{res}'.format(tname=tname,res=res)
            data = u"item: {item}\n value: {val}".format(item=item, val=val)    
            level = "failed"
            if cond is True:
                if event is None:
                    notify = False
                    err = None         
                    notify_at = None           
                    if 1 >= continue_times:
                        notify = True
                        notify_at = now
                     
                        err = send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id)

                    tevent = Trigger_event(user_id, now, None, notify_at, tid, res, 1, 1, notify, err, val)
                    db.session.add(tevent)
                    db.session.commit()
                else:
                    times = event.times
                    notify = event.notify
                    notify_at = event.notify_at

                    if notify:
                        if (now - notify_at).total_seconds() >= silent:
                            err = send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id)
                            if err is not None:
                                event.notify = False

                            event.notify_at = now    
                            event.err = err

                        event.current_val = val
                        event.times = times + 1
                        db.session.commit()

                    else:
                        if times >= continue_times:                          
                            err = send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id)
                            if err is not None:
                                event.notify = False
                            else:
                                event.notify = True 

                            event.notify_at = now
                            event.err = err


                        event.current_val = val
                        event.times = times + 1
                        db.session.commit()

            else:
                if cond is False and event is not None:
                    event.recover_at = now
                    event.state = 2
                    if recover_notify:
                        title = u'【恢复】{tname} 资源：{res}'.format(tname=tname,res=res)
                        err = send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id)
                        event.err = err
                        if err is not None:
                            event.notify = False
                        else:
                            event.notify = True                

                    event.current_val = val
                    db.session.commit()

                # 如果不发恢复通知，那就发通知，不记录
                if cond is None:
                    title = u'【通知】{tname} 资源：{res}'.format(tname=tname,res=res)
                    err = send_notify(smtp_ip, smtp_ssl, smtp_port, smtp_user, smtp_pwd, contact_group, title, data, item, res, send_to_msg_center, user_id)
        db.session.close()           

def main():
    global SHARE_Q
    threads = []
    res = Trigger_config.query.filter_by(state=True).all()
    for i in res :
        SHARE_Q.put(i)

    db.session.close()
    for i in xrange(_WORKER_THREAD_NUM) :
        thread = MyThread(worker)
        thread.start()
        threads.append(thread)

    for thread in threads :
        thread.join()    

    
if __name__ == '__main__':
    main()        
