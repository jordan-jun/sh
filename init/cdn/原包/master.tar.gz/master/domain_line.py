# -*- coding: utf-8 -*-
import os
os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Node, Line_group, Dns_provider, Task
from public_func import make_msg, mark_task_start, mark_task_success, mark_task_failed, mark_task_del, mark_task_done_one
from sqlalchemy import desc
import app
from time import sleep
import time
import requests
import json
import ntpath
import sys
import datetime
from cloudxns.api import *
import httplib
import socket
from collections import OrderedDict

def heartbeat(name):
    heartbeat_file = os.path.join("/tmp",name + ".heartbeat")
    with open(heartbeat_file,"w") as fp:
        fp.write("")

def get_dnspod_user_grade(token):
    try:
        data = {"login_token":token,"format":"json"}
        headers = {"User-Agent":"python requests client/1.0.0(admin@centos.bz)"}
        r = requests.post("https://dnsapi.cn/User.Detail",data=data,timeout=10,headers=headers)
        status_code = r.status_code
        if status_code != 200:
            return False, "failed: https://dnsapi.cn/User.Detail return status code: {status_code}".format(status_code=status_code)

        content = r.content
        try:
            content = json.loads(content)
        except ValueError:
            return False, "failed: https://dnsapi.cn/User.Detail return a invalid json: {content}".format(content=content)

        try:
            status = content["status"]
            code = status["code"]
            message = status["message"]
        except KeyError:
            return False, u"failed: https://dnsapi.cn/User.Detail return a json without status or msg, content:{content}".format(content=content)
        if int(code) != 1:
            return False, u"failed: https://dnsapi.cn/User.Detail code not eq 1, message:{message}".format(message=message)


        info = content["info"]
        user_grade = info["user"]["user_grade"]

        return user_grade, None

    except requests.exceptions.Timeout:
        return False, "failed: https://dnsapi.cn/User.Detail timeout"

    except requests.exceptions.ConnectionError:
        return False, "failed: https://dnsapi.cn/User.Detail timeout"

def get_dnspod_lines(auth, domain):
    auth = json.loads(auth)
    id = auth["id"]
    token = auth["token"]
    login_token = "{id},{token}".format(id=id, token=token)
    user_grade, err = get_dnspod_user_grade(login_token)
    if not user_grade:
        return False,"get dnspod user grade fail,err:" + err

    try:
        data = {"login_token":login_token,"format":"json","domain_grade":user_grade,"domain":domain}
        headers = {"User-Agent":"python requests client/1.0.0(admin@centos.bz)"}
        r = requests.post("https://dnsapi.cn/Record.Line",data=data,timeout=10,headers=headers)
        status_code = r.status_code
        if status_code != 200:
            return False, "failed: https://dnsapi.cn/Record.Line return status code: {status_code}".format(status_code=status_code)

        content = r.content

        try:
            content = json.loads(content,object_pairs_hook=OrderedDict)
        except ValueError:
            return False, "failed: https://dnsapi.cn/Record.Line return a invalid json: {content}".format(content=content)

        try:
            status = content["status"]
            code = status["code"]
            message = status["message"]
        except KeyError:
            return False, u"failed: https://dnsapi.cn/Record.Line return a json without status or msg, content:{content}".format(content=content)
        if int(code) != 1:
            return False, u"failed: https://dnsapi.cn/Record.Line code not eq 1, message:{message}".format(message=message)


        line_ids = content["line_ids"]
        return line_ids, None

    except requests.exceptions.Timeout:
        return False, "failed: https://dnsapi.cn/Record.Line timeout"

    except requests.exceptions.ConnectionError:
        return False, "failed: https://dnsapi.cn/Record.Line timeout"


def get_cloudxns_lines(auth):
    try:
        auth = json.loads(auth)
        api_key = auth["api_key"]
        secret_key = auth["secret_key"]
        api = Api(api_key=api_key, secret_key=secret_key)
        result = api.line_list()
        result = json.loads(result)
        code = result['code']
        message = result['message']
        if int(code) != 1:
            return False, message

    except httplib.ResponseNotReady:
        return False, "timeout"

    except socket.error:
        return False, "ConnectionError"

    return result['data'], None

def get_lines(dns, auth, domain):
    if dns == "dnspod":
        return get_dnspod_lines(auth,domain)

    elif dns == "cloudxns":
        return get_cloudxns_lines(auth)


def update_line_group(id, lines):
    line_group = Line_group.query.filter_by(id=id).first()
    line_group.lines = lines
    db.session.commit()
    db.session.close()

def main():
    sleep_time = 5
    task = Task.query.filter( (Task.type=="domain_line") & (Task.delflag == 0) & ( Task.state != "success") ).first()
    if task is None:
        db.session.close()
        return sleep_time

    task_id = task.id
    value = task.value
    # 标记开始执行
    mark_task_start(task_id, 1)

    value = json.loads(value)
    dns = value["dns"]
    auth = value["auth"]
    domain = value["domain"]
    line_group_id = value["id"]
    if (auth == "") or (auth == None):
        mark_task_failed(task_id,u"未填写DNS接口凭证")
        return 60

    auth_json = json.loads(auth)
    for k in auth_json:
        if auth_json[k] == "":
            auth_empty = True
            break
    else:
        auth_empty = False
    
    if auth_empty:
        mark_task_failed(task_id,u"未填写DNS接口凭证")
        return 60

    title = u"get {domain} lines".format(domain=domain)
    user_id = 1
    type = "domain_line"
    res = domain
    level = "failed"

    lines, err = get_lines(dns, auth, domain)
    if err is not None:
        data = err
        make_msg(title, data, user_id, type, res, level)
        mark_task_failed(task_id,err)
        return 60

    update_line_group(line_group_id, json.dumps(lines))
    data = None
    level = "success"
    make_msg(title, data, user_id, type, res, level)
    mark_task_success(task_id,None)

    db.session.close()
    return sleep_time
    

if __name__ == '__main__':
    main()