export HTTPGUARD_SETTINGS=/opt/httpguard/agent/config.py
export FLASK_APP=run.py
export FLASK_DEBUG=1
flask run -h 0.0.0.0 -p 5000  --with-threads
