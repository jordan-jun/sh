# -*- coding: utf-8 -*-

import sys
import os
import datetime
from dateutil.relativedelta import relativedelta
from sqlalchemy import desc
import time

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Site, Access_log, Message, Node, Monitor_history

class access_log(object):
    """docstring for access_log"""
    def __init__(self, arg):
        super(access_log, self).__init__()
        self.arg = arg

    @staticmethod
    def status_code(user_id, period, func, op, value, args):
        value = int(value)
        domains, code = args.split(",")
        if domains == "all":
            sites = Site.query.filter_by(user_id=user_id)
            domain_to_check = []
            for site in sites:
                domain_to_check = domain_to_check + site.domain.split()
        else:
            domain_to_check = domains.split("|")


        time_ago = datetime.datetime.now() + relativedelta(seconds=-period)
        res_return = []
        for domain in domain_to_check:
            code_sum = Access_log.query.filter( (Access_log.created_at >= time_ago) & (Access_log.host == domain) & (Access_log.status == code)).count()
            cond = False
            if op == ">" and code_sum > value:
                cond = True
            elif op == ">=" and code_sum >= value:
                cond = True
            elif op == "<" and code_sum < value:
                cond = True
            elif op == "<=" and code_sum <= value:
                cond = True
            elif op == "=" and code_sum == value:
                cond = True
            elif op == "!=" and code_sum != value:
                cond = True

            res_return.append((cond, domain, code_sum))

        db.session.close()
        return res_return

class system(object):
    """docstring for system"""
    def __init__(self, arg):
        super(system, self).__init__()
        self.arg = arg

    @staticmethod
    def msg(user_id, period, func, op, value, args):
        time_ago = datetime.datetime.now() + relativedelta(seconds=-62)
        msg_type, msg_level = args.split(",")
        messages = Message.query.filter( (Message.created_at >=time_ago ) & (Message.type == msg_type)).order_by(desc(Message.created_at)).all()

        res_return = []
        for msg in messages:
            res = msg.res
            data = msg.data
            level = msg.level
            if msg_level == "success":
                if level == "success":
                    cond = None
                else:
                    continue

            elif msg_level == "failed":
                if level == "failed":
                    cond = True
                elif level == "success": 
                    cond = False

            res_return.append((cond, res, data))

        db.session.close()
        return res_return

    @staticmethod
    def auto_cc_state(user_id, period, func, op, value, args):
        domains, cc_state = args.split(",")
        if domains == "all":
            sites = Site.query.filter_by(user_id=user_id)
            domain_to_check = []
            for site in sites:
                domain_to_check = domain_to_check + site.domain.split()
        else:
            domain_to_check = domains.split("|")


        time_ago = time.time() - 180
        res_return = []
        nodes = Node.query.all()
        for node in nodes:
            node_id = node.id
            node_name = node.name
            node_ip = node.ip
            enable = node.enable
            if not enable:
                continue

            for domain in domain_to_check:
                key = "auto_cc_state[{domain}]".format(domain=domain)
                monitor_history = Monitor_history.query.filter( (Monitor_history.node_id==node_id) & (Monitor_history.item==key) & (Monitor_history.clock > time_ago ) ).order_by(desc(Monitor_history.id)).limit(2)
                if monitor_history.count() == 2:
                    current = monitor_history[0].value
                    last = monitor_history[1].value
                    if current != last:
                        if current == "on":
                            state = u"节点 {node_name} 域名 {domain} 已自动切换到指定的规则组".format(node_name=node_name,domain=domain)
                        else:
                            state = u"节点 {node_name} 域名 {domain} 已恢复到默认的规则组".format(node_name=node_name,domain=domain)

                        if current != cc_state:
                            continue

                        cond = None
                        res_return.append((cond, domain, state))

        db.session.close()
        return res_return

    