# -*- coding: utf-8 -*-

import time
import sys
import os
import datetime
from sqlalchemy import desc,asc,func
from sqlalchemy.sql import select
from dateutil.relativedelta import relativedelta
import json

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import app, Site, db, Domain_traffic, User,Product, user_product_ext, Product_ext, Message, Line_group, Config
from route import get_user_traffic_used, get_user_traffic_limit
from public_func import make_msg

def create_task(name, value):
    task = Config.query.filter_by(name=name, value=value).first()
    if task is None:
        db.session.add(Config(name, value))
        db.session.commit()

    db.session.close()
    
def close_site(user_id):
    # 关闭网站
    sites = Site.query.filter_by(user_id=user_id).all()
    for site in sites:
        site.enable = False

    db.session.commit()

    # 删除网站配置
    sites = Site.query.filter_by(user_id=user_id).all()
    for site in sites:
        line_group_id = site.line_group_id
        site_id = site.id
        domain = site.domain

        # 添加删除任务
        line_group = Line_group.query.filter_by(id=line_group_id).first()
        nodes = line_group.nodes
        for node in nodes:
            node_id = node.id
            enable = node.enable
            if not enable:
                continue

            name = "sync_site_del_{site_id}".format(site_id=site_id)
            value = json.dumps({"action":"del","node_id":node_id,"site_id":site_id,"domain":domain,"user_id":user_id})
            create_task(name, value)
    db.session.close()

def main():
    users = db.session.query(User.id, User.product_start, User.product_expire, Product.traffic).filter(User.type != 1).outerjoin(Product).filter(Product.traffic != 0).all()
    for user in users:
        user_id = user.id
        product_expire = user.product_expire
        now = datetime.datetime.now()

        # 检查套餐是否过期
        if now > product_expire:
            sites = Site.query.filter_by(user_id=user_id).all()
            all_site_close = True
            for site in sites:
                if site.enable:
                    all_site_close = False

            if not all_site_close:
                make_msg(u"您的套餐已过期,将关闭您帐号下的所有网站.", '', True, user_id)
                close_site(user_id)

        # 检查流量是否超限
        traffic_limit = get_user_traffic_limit(user_id)
        traffic_used = get_user_traffic_used(user_id)

        if traffic_used > traffic_limit:
            sites = Site.query.filter_by(user_id=user_id).all()
            all_site_close = True
            for site in sites:
                if site.enable:
                    all_site_close = False

            if not all_site_close:
                make_msg(u"您当月的使用的流量为{traffic_used}GB,限额为{traffic_limit}GB,已超限,将关闭所有网站.".format(
                        traffic_used=traffic_used,traffic_limit=traffic_limit), '', True, user_id)
                close_site(user_id)

    db.session.close()
if __name__ == '__main__':
    main()
