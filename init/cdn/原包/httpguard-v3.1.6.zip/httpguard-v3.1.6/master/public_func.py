# -*- coding: utf-8 -*-

import time
import os
import datetime
from sqlalchemy import desc
import hashlib

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Message, Node, Task

def make_msg(title, data, user_id, type, res, level):
    if level != None:
        title = "【"+level+"】" + title
    now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    message = Message.query.filter( (Message.user_id == user_id) & (Message.type == type) & (Message.level == level) & (Message.res == res) ).order_by(desc(Message.id)).first()
    if message is not None and message.level == "failed" and level == "failed":
        message.created_at = now
        message.read = 0
        message.title = title
        message.data = data
        db.session.commit()
        return

    message = Message(title, data, now, user_id, type, res, level)
    db.session.add(message)
    db.session.commit()
    db.session.close()

def dnsdotcom_sign(parms, api_key, api_secret):
    timestamp = int(time.time())
    parms["apiKey"] = api_key
    parms["timestamp"] = str(timestamp)
    parms_list = []
    for k in sorted(parms):
        parms_list.append(k+"="+parms[k])

    parms_str = "&".join(parms_list)+api_secret
    md5 = hashlib.md5()
    md5.update(parms_str)
    hash = md5.hexdigest()
    parms['hash'] = hash
    return parms

def mark_task_start(id, total):
    task = Task.query.filter_by(id=id).first()
    task.start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    task.total = total
    task.complete = 0
    task.state = "running"
    db.session.commit()
    db.session.close()

def mark_task_success(id, ret):
    task = Task.query.filter_by(id=id).first()
    task.end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    task.complete = task.total
    task.state = "success"
    task.ret = ret
    db.session.commit()
    db.session.close()    

def mark_task_failed(id, ret):
    task = Task.query.filter_by(id=id).first()
    task.end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    task.state = "failed"
    task.ret = ret
    db.session.commit()
    db.session.close()        

def mark_task_del(id, ret):
    task = Task.query.filter_by(id=id).first()
    task.end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    task.state = "failed"
    task.delflag = 1
    task.ret = ret
    db.session.commit()
    db.session.close()       

def mark_task_done_one(id):
    task = Task.query.filter_by(id=id).first()
    task.complete = task.complete + 1
    db.session.commit()
    db.session.close()   


