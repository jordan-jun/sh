# -*- coding: utf-8 -*-

import time
import ntpath
import sys
import os

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import app, Monitor_history, db, Access_log

def main():
    now = time.time()
    retain_days = app.config["MONITOR_RETAIN_DAYS"]
    before_day = now - 86400*retain_days
    Monitor_history.query.filter((Monitor_history.clock <= before_day)).delete()

    db.session.commit()
    db.session.close()

    # 删除一天前的日志
    one_day_ago = time.time() - 43200
    one_day_ago = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(one_day_ago))
    Access_log.query.filter(Access_log.created_at <= one_day_ago ).delete()
    db.session.commit()
    db.session.close()


if __name__ == '__main__':
    main()