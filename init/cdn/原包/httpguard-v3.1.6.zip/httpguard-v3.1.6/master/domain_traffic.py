# -*- coding: utf-8 -*-

import time
import sys
import os
import datetime
from sqlalchemy import desc,asc,func

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import app, Site, db, Access_log, Domain_traffic

def main():
    now = int(time.time())
    now_5_int = now - now % 300
    domains = []
    sites = Site.query.all()
    for site in sites:
        domain = site.domain
        domains = domains + domain.split()

    for domain in domains:
        domain_traffic = Domain_traffic.query.filter_by(domain=domain).order_by(desc(Domain_traffic.created_at)).limit(1).first()
        if domain_traffic is None:
            access_log = db.session.query(func.sum(Access_log.byte_sent).label("byte_sent_sum")).filter( 
                (Access_log.created_at >= time.strftime('%Y-%m-%d %H:%M',time.localtime(now_5_int - 300))) & 
                (Access_log.created_at <= time.strftime('%Y-%m-%d %H:%M',time.localtime(now_5_int))) &
                (Access_log.host == domain) ).limit(1).first()

            bytes_sum = access_log[0]
            if bytes_sum is None:
                continue

            domain_traffic_insert = Domain_traffic(domain, time.strftime('%Y-%m-%d %H:%M',time.localtime(now_5_int)), bytes_sum)
            db.session.add(domain_traffic_insert)
            db.session.commit()

        else:
            created_at = int((domain_traffic.created_at - datetime.datetime(1970, 1, 1)).total_seconds() - 28800)
            if created_at == now_5_int:
                continue

            # 最大回溯统计一天的
            if created_at < now_5_int - 86400:
                created_at = now_5_int - 86400

            for t in range(created_at + 300, now_5_int + 300, 300):
                access_log = db.session.query(func.sum(Access_log.byte_sent).label("byte_sent_sum")).filter( 
                    (Access_log.created_at >= time.strftime('%Y-%m-%d %H:%M',time.localtime(t - 300))) & 
                    (Access_log.created_at <= time.strftime('%Y-%m-%d %H:%M',time.localtime(t))) &
                    (Access_log.host == domain) ).limit(1).first()

                bytes_sum = access_log[0]
                if bytes_sum is None:
                    continue

                domain_traffic_insert = Domain_traffic(domain, time.strftime('%Y-%m-%d %H:%M',time.localtime(t)), bytes_sum)
                db.session.add(domain_traffic_insert)
                db.session.commit()

    db.session.close()

if __name__ == '__main__':
    main()
