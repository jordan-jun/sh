# -*- coding: utf-8 -*-

from app import *
from dateutil.relativedelta import relativedelta
from inspect import getargspec
import dns.resolver
import OpenSSL
import threading
import Queue
import time

TASK_TYPE_NAME = {"clean_site_cache": u"刷新全站缓存", "clear_site_certain_cache": u"刷新指定缓存","clean_site_whitelist": u"清空网站白名单","clean_site_blacklist": u"清空网站黑名单","get_domain_list": u"获取DNS服务商域名列表",
                "update_dns_record": u"更新域名记录","sync_nginx_conf": u"同步nginx.conf文件","sync_config_json": u"同步config.json文件","upgrade": u"软件升级","sync_site": u"同步网站配置",
                "del_site":u"删除网站配置","sync_node_site":u"同步节点网站","domain_line":u"获取DNS线路","issue_ca":u"签发Let's Encrypt","renew_ca":u"续签Let's Encrypt"}

def create_task(type, res, value, user_id):
    task = Task.query.filter( (Task.type==type) & (Task.value==value) & (Task.state != "success") & (Task.delflag != 1)).first()
    if task is None:
        name = TASK_TYPE_NAME[type]
        create_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
        start_time = None
        end_time = None
        total = 0
        complete = 0
        state = "pending"
        delflag = 0
        ret = ""
        task_add = Task(user_id, name, type, res, value, create_time, start_time, end_time, total, complete, state, delflag, ret)
        db.session.add(task_add)
        db.session.commit()

def is_logged():
    auth = request.cookies.get('auth')
    if auth is None:
        return False    

    try:
        auth = base64.b64decode(auth)
    except TypeError:
        return False

    aes_obj = AESCipher(app.config["KEY"])
    auth = aes_obj.decrypt(auth)
    auth = json.loads(auth)

    # 是否过期
    expire = auth["expire"]
    if time.time() > expire:
        return False

    # 是否是超级管理员
    type = auth['type']
    if type == 1:
        return auth

    # /login-verify放行
    if request.path == "/login-verify":
        return auth

    # 是否有权限
    role_id = auth['role']
    statement = select([priv_role]).where((priv_role.c.role_id == role_id))
    role_paths = db.session.execute(statement)
    paths = [ role_path.priv_path for role_path in role_paths]
    if request.path not in paths:
        return False 

    return auth

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth = is_logged()
        if auth is False:
            return jsonify(state="failed",msg=u"凭证失效或无权限") 

        return f(auth)
        
    return decorated_function

@app.route('/login-verify', methods=['GET'])
def login_verfiy():
    auth = is_logged()
    if auth:
        now = time.time()
        auth['expire'] = now + 3600
        auth = json.dumps(auth)
        aes_obj = AESCipher(app.config["KEY"])
        auth = aes_obj.encrypt(auth)
        auth = base64.b64encode(auth)
        res = Response(json.dumps({"state":"success","msg":None}))
        res.set_cookie(key='auth', value=auth)
        return res

    else:
        return jsonify(state="failed",msg=u"凭证失效或无权限")  

@app.route('/logout', methods=['POST'])
def logout():
    res = Response('delete cookies')
    res.set_cookie('auth', '', expires=0)
    return res

@app.route('/login', methods=['POST'])
def login():
    content = request.get_json(silent=True,force=True)
    name = content["user"]
    password = content["password"]
    type = content["type"]
    user = User.query.filter( ( (User.name == name) | (User.email == name)) & (User.password == password) & (User.type == type) ).first()
    if user is None:
        return jsonify(state="failed",msg=u"用户或密码不正确!")  

    # 是否已禁用
    if not user.enable:
        return jsonify(state="failed",msg=u"此账号已被禁用!")  

    id = user.id
    type = user.type
    role = user.role

    now = time.time()
    auth = {"expire": now + 3600,"id":id, "type":type, "role":role}
    auth = json.dumps(auth)
    aes_obj = AESCipher(app.config["KEY"])
    auth = aes_obj.encrypt(auth)
    auth = base64.b64encode(auth)
    res = Response(json.dumps({"state":"success","msg":None}))
    res.set_cookie(key='auth', value=auth)
    return res

def check_domain_exist_when_add(domains, line_group_id):
    # 当前线路组
    sites = Site.query.filter_by(line_group_id=line_group_id)
    domain_arr_tmp = []
    for site in sites:
        domain_arr_tmp = domain_arr_tmp + site.domain.split()

    for domain in domains.split():
        if domain in domain_arr_tmp:
            return True, u"当前线路组已存在域名:" + domain

    # 除当前线路组的所有线路组
    current_domain = domains.split()
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    current_nodes = line_group.nodes.all()

    sites = Site.query.filter(Site.line_group_id != line_group_id)
    for site in sites:
        site_line_group_id = site.line_group_id
        domain_intersect = list(set(site.domain.split()) & set(current_domain))
        if len(domain_intersect) != 0:
            line_group = Line_group.query.filter_by(id=site_line_group_id).first()
            nodes = line_group.nodes.all()
            name = line_group.name
            if len(set(current_nodes) & set(nodes)) != 0:
                return True, u"线路组{name}已存在域名{domain}".format(name=name,domain=",".join(domain_intersect))

    return False, None

def check_domain_exist_when_edit(domains, line_group_id, site_id):
    # 当前线路组
    sites = Site.query.filter( (Site.line_group_id==line_group_id) & (Site.id != site_id) )
    domain_arr_tmp = []
    for site in sites:
        domain_arr_tmp = domain_arr_tmp + site.domain.split()

    for domain in domains.split():
        if domain in domain_arr_tmp:
            return True, u"当前线路组已存在域名:" + domain

    # 除当前线路组的所有线路组
    current_domain = domains.split()
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    current_nodes = line_group.nodes.all()

    sites = Site.query.filter( (Site.line_group_id != line_group_id) & (Site.id != site_id) )
    for site in sites:
        site_line_group_id = site.line_group_id
        domain_intersect = list(set(site.domain.split()) & set(current_domain))
        if len(domain_intersect) != 0:
            line_group = Line_group.query.filter_by(id=site_line_group_id).first()
            nodes = line_group.nodes.all()
            name = line_group.name
            if len(set(current_nodes) & set(nodes)) != 0:
                return True, u"线路组{name}已存在域名{domain}".format(name=name,domain=",".join(domain_intersect))

    return False, None

def update_config_json(val, key1, key2=""):
    with open("/opt/httpguard/master/conf/httpguard_config.json","r") as fp:
        config_data = fp.read()

    config_data = json.loads(config_data)
    if type(val) == type(''):
        val = json.loads(val)

    if key2 == "":
        config_data[key1] = val
    else:
        if not config_data.has_key(key1):
            config_data[key1] = {}

        for i in key2:
            config_data[key1][i] = val

    config_data = json.dumps(config_data,indent=4)      
    with open("/opt/httpguard/master/conf/httpguard_config.json","w") as fp:
        fp.write(config_data)

    create_task("sync_config_json","", "",1)    

def remove_config_json(key1, key2=""):
    with open("/opt/httpguard/master/conf/httpguard_config.json","r") as fp:
        config_data = fp.read()

    config_data = json.loads(config_data)
    if key2 == "":
        del config_data[key1]
    else:
        if not config_data.has_key(key1):
            return

        for i in key2:
            if config_data[key1].has_key(i):
                del config_data[key1][i]

    config_data = json.dumps(config_data,indent=4)      
    with open("/opt/httpguard/master/conf/httpguard_config.json","w") as fp:
        fp.write(config_data)

    create_task("sync_config_json","", "",1)

def check_user_product(user_id):
    user = User.query.filter_by(id=user_id).first()
    if user is None:
        return False, u"当前用户不存在"

    product_expire = user.product_expire
    product_base = user.product_base
    if product_base is None:
        return False, u"当前用户没有开通任何套餐"

    now = datetime.datetime.now()
    remain = product_expire - now
    if remain.total_seconds() < 0:
        return False, u"当前用户套餐已过期"

    product = Product.query.filter_by(id=product_base).first()
    if product is None:
        return False, u"找不到套餐{id}".format(id=product_base)    

    return product, None

def check_line_group(user_id, line_group_id, product):
    line_group_id_base = product.line_group.split(",")
    line_group_id_ext = []
    # line_group的扩展套餐
    statement = select([user_product_ext]).where((user_product_ext.c.user_id == user_id) )
    products = db.session.execute(statement)
    if products.rowcount != 0:
        for p in products:
            product_ext_id = p['product_ext_id']
            product_ext = Product_ext.query.filter_by(id=product_ext_id).first()
            if product_ext.type == "line_group":
                line_group_id_ext = line_group_id_ext + product_ext.value.split(",")    

    line_group_ids = line_group_id_base + line_group_id_ext
    if line_group_id not in line_group_ids:
        return False, u"没有添加此线路组的权限"

    return True, None

def get_user_domain_limit(user_id):
    # 基础套餐
    product = db.session.query(User.id, Product.domain, Product.subdomain).filter( User.id == user_id ).outerjoin(Product).first()
    top_domain_base_limit = product.domain
    domain_base_limit = product.subdomain

    # 扩展套餐
    statement = select([user_product_ext]).where((user_product_ext.c.user_id == user_id) )
    products = db.session.execute(statement)
    top_domain_ext_limit = 0
    domain_ext_limit = 0
    if products.rowcount != 0:
        for p in products:
            product_ext_id = p['product_ext_id']
            product_ext = Product_ext.query.filter_by(id=product_ext_id).first()
            if product_ext.type == "domain":
                amount = p['amount']
                top_domain_ext_limit, domain_ext_limit = product_ext.value.split(",")
                break

    if top_domain_base_limit == 0:
        top_domain_limit = 0
    else:    
        top_domain_limit = int(top_domain_base_limit) + int(top_domain_ext_limit)

    if domain_base_limit == 0:
        domain_limit = 0
    else:    
        domain_limit = int(domain_base_limit) + int(domain_ext_limit)

    return top_domain_limit, domain_limit  

def get_user_domain_amount(user_id, domain=None, site_id=None):
    top_domain = []
    two_dot_suffix = ["com.cn","com.hk","net.cn","org.cn"]
    res = Site.query.filter_by(user_id=user_id)
    if site_id:
        sites = res.filter(Site.id != site_id).all()
    else:
        sites = res.all()

    domains = []
    if domain:
        domains = [domain]        

    for site in sites:
        domains = domains + site.domain.split()

    for d in domains:
        two_suffix = ".".join(d.split(".")[-2:])
        if two_suffix in two_dot_suffix:
            three_suffix = ".".join(d.split(".")[-3:])
            if three_suffix not in top_domain:
                top_domain.append(three_suffix)
        
            continue
        else:
            if two_suffix not in top_domain:
                top_domain.append(two_suffix)


    top_domain_amount = len(top_domain)
    domain_amount = len(domains)
    return top_domain_amount, domain_amount

def get_user_traffic_used(user_id):
    user = User.query.filter_by(id=user_id).first()
    product_start = user.product_start
    now = datetime.datetime.now()

    sites = Site.query.filter_by(user_id=user_id).all()
    domains = []
    for site in sites:
        domains = domains + site.domain.split()

    current_year_month = now.strftime("%Y-%m")
    product_start_day = product_start.strftime("-%d %H:%M:%S")
    current_product_start = datetime.datetime.strptime(current_year_month + product_start_day, "%Y-%m-%d %H:%M:%S")
    if current_product_start > now:
        product_cal_start = current_product_start + relativedelta(months=-1)
    else:
        product_cal_start = current_product_start

    traffic = db.session.query(func.sum(Domain_traffic.bytes)).filter( (Domain_traffic.created_at >= str(product_cal_start)) & (Domain_traffic.created_at < str(now)) ).filter(
        Domain_traffic.domain.in_((domains))).first()
    traffic = traffic[0]
    if traffic is None:
        traffic = 0
    traffic_used = round(float() / 1024.0 / 1024.0 / 1024.0 ,2) 
    return traffic_used


def get_user_traffic_limit(user_id):
    product = db.session.query(User.product_base, Product.traffic).filter(User.id == user_id).outerjoin(Product).first()
    traffic_limit = product.traffic

    if traffic_limit != 0:
        statement = select([user_product_ext]).where((user_product_ext.c.user_id == user_id) )
        products = db.session.execute(statement)
        if products.rowcount != 0:
            for p in products:
                product_ext_id = p['product_ext_id']
                amount = p['amount']
                product_ext = Product_ext.query.filter_by(id=product_ext_id).first()
                if product_ext.type == "traffic":
                    traffic_limit = traffic_limit + float(product_ext.value) * int(amount)

    return traffic_limit

def check_domain_amount(user_id, domain=None, site_id=None):
    top_domain_amount, domain_amount = get_user_domain_amount(user_id, domain, site_id)
    top_domain_limit, domain_limit = get_user_domain_limit(user_id)

    # 检查一级域名数是否超过限制
    if top_domain_limit != 0 and int(top_domain_amount) > top_domain_limit:
        return False, u'当前一级域名限制为{top_domain_limit},您已超过限制.'.format(top_domain_limit=top_domain_limit)

    # 检查域名数是否超限制
    if domain_limit != 0 and int(domain_amount) > domain_limit:
        return False, u'当前域名数限制为{domain_limit},您已超过限制'.format(domain_limit=domain_limit)

    return True, None

def is_domain_resolvable(domain):
    my_resolver = dns.resolver.Resolver()
    my_resolver.nameservers = ['119.29.29.29','8.8.8.8']
    try:
        ans = my_resolver.query(domain, 'A')
    except dns.resolver.NoAnswer:
        return False, u"未收到dns服务器回应,请稍后重试."
    except dns.resolver.NXDOMAIN:
        return False, u"找不到{domain}回源域名解析记录,请更换回源域名,或者稍后重试".format(domain=domain)
    except:
        return False, u"解析异常,请稍后重试"

    # for i in ans.response.answer: 
    #     for j in i.items: 
    #         print j.address

    return True, None    

def is_domain_valid(domain):
    for d in domain.split():
        d_split = d.split(".")
        domain_subbfix = d_split[-1]
        if len(d_split) < 2:
            return False,u"{d}不是有效的域名".format(d=d)

        if not re.match(r"^[a-z]{2,}$",domain_subbfix):
            return False,u"{d}不是有效的域名".format(d=d)

        for d_s in d_split[0:-1]:
            if not re.match(r"^[a-z0-9][-a-z0-9]*$", d_s):
                return False,u"{d}不是有效的域名".format(d=d)

    return True, None

def is_ip_valid(ip):
    ip_split = ip.split(".")
    if len(ip_split) != 4:
        return False

    ip_split1 = ip_split[0]
    ip_split2 = ip_split[1]
    ip_split3 = ip_split[2]
    ip_split4 = ip_split[3]

    if not re.match(r"^[0-9]+$",ip_split1) or ip_split1 == "127" or ip_split1 == "0" or int(ip_split1) >= 255:
        return False

    if not re.match(r"^[0-9]+$",ip_split2) or ip_split2 == "0" or int(ip_split2) >= 255:
        return False 

    if not re.match(r"^[0-9]+$",ip_split3) or ip_split3 == "0" or int(ip_split3) >= 255:
        return False 

    if not re.match(r"^[0-9]+$",ip_split4) or ip_split4 == "0" or int(ip_split4) >= 255:
        return False

    return True    

def is_port_valid(port):
    if not re.match(r"^[0-9]+$",port) or int(port) <= 0 or int(port) > 65535:
        return False

    return True    

def is_backend_server_valid(server):
    if not is_ip_valid(server) and not is_domain_valid(server)[0]:
        return False, u"源服务器{server}无效".format(server=server)
    # 如果是域名,需要检查是否可解析
    if not is_ip_valid(server):
        ret, err = is_domain_resolvable(server)
        if not ret:
            return False, err

    return True, None 

def is_number(number):
    if not re.match(r"^[0-9]+$",number):
        return False
    
    return True

def is_key_match_cert(key, cert):
    try:
        pkey_obj = OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, key)
        cert_obj = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, cert)
    except OpenSSL.crypto.Error:
        return False

    ctx = OpenSSL.SSL.Context(OpenSSL.SSL.TLSv1_METHOD)
    ctx.use_privatekey(pkey_obj)
    ctx.use_certificate(cert_obj)
    try:
        ctx.check_privatekey()
    except OpenSSL.crypto.Error:
        return False

    return True    

@app.route('/site/add', methods=['POST'])
@login_required
def add_site_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    line_group_id = content["line_group_id"]
    domain = content["domain"]
    upstream_ip = content["upstream_ip"]
    http_port = content["http_port"]
    enable_https = content["enable_https"]
    https_port = content["https_port"]
    http_back_to_source = content["http_back_to_source"]
    force_https = content["force_https"]
    ca_type = content["ca_type"]
    crt = content["crt"]
    key = content["key"]
    proxy_cache = content["proxy_cache"]
    error404 = content["error404"]
    error50x = content["error50x"]
    cc_rule = content["cc_rule"]
    auto_cc_rule = content["auto_cc_rule"]
    allow_spider = content["allow_spider"]
    hotlink = content["hotlink"]
    ca_need_renew = False
    hsts = content["hsts"]
    enable_http2 = content["enable_http2"]
    map_data = content['map_data']
    rewrite_data = content['rewrite_data']
    proxy_connect_timeout = content['proxy_connect_timeout']
    proxy_send_timeout = content['proxy_send_timeout']
    proxy_read_timeout = content['proxy_read_timeout']
    upstreams = content['upstreams']
    proxy_next_upstream = content['proxy_next_upstream']
    acl_rule = content['acl_rule']
    proxy_ssl_protocols = content['proxy_ssl_protocols']

    map_data_json = json.dumps(map_data)
    proxy_cache_json = json.dumps(proxy_cache)
    rewrite_data = json.dumps(rewrite_data)
    upstreams_json = json.dumps(upstreams)
    enable = True
    # 域名转换为小写
    domain = domain.lower()

    if acl_rule != "":
        acl_rule = json.dumps(acl_rule)

    if auto_cc_rule != "":
        auto_cc_rule = json.dumps(auto_cc_rule)

    if line_group_id == "" or line_group_id == None:
        return jsonify(state="failed",msg=u"line_group_id不能为空")

    if domain == "":
        return jsonify(state="failed",msg=u"域名不能为空")

    if http_port == "":
        return jsonify(state="failed",msg=u"后端http端口不能为空")

    if proxy_ssl_protocols == "":
        return jsonify(state="failed",msg=u"proxy_ssl_protocols不能为空")

    if enable_https == True:
        if https_port == "":
            return jsonify(state="failed",msg=u"后端https端口不能为空")

        if ca_type == "custom":
            if crt == "":
                return jsonify(state="failed",msg=u"证书不能为空")

            if key == "":
                return jsonify(state="failed",msg=u"私钥不能为空")

    # 检查域名有效性
    ret, err = is_domain_valid(domain)
    if not ret:
        return jsonify(state="failed",msg=err)

    # 检查超时
    if not is_number(proxy_connect_timeout):
        return jsonify(state="failed",msg=u"{proxy_connect_timeout} proxy_connect_timeout无效".format(proxy_connect_timeout=proxy_connect_timeout))

    if not is_number(proxy_send_timeout):
        return jsonify(state="failed",msg=u"{proxy_send_timeout} proxy_send_timeout无效".format(proxy_send_timeout=proxy_send_timeout))

    if not is_number(proxy_read_timeout):
        return jsonify(state="failed",msg=u"{proxy_read_timeout} proxy_read_timeout无效".format(proxy_read_timeout=proxy_read_timeout))


    # 验证源服务器
    if not upstream_ip and not upstreams:
        return jsonify(state="failed",msg=u"源服务器不能为空")

    if upstream_ip == "":
        fail_timeout = upstreams["fail_timeout"]
        if not is_number(fail_timeout):
            return jsonify(state="failed",msg=u"{fail_timeout}fail_timeout无效".format(fail_timeout=fail_timeout))

        max_fails = upstreams["max_fails"]
        if not is_number(max_fails):
            return jsonify(state="failed",msg=u"{max_fails}max_fails无效".format(max_fails=max_fails))

        for pnu in proxy_next_upstream.split():
            if pnu not in ["error","timeout","invalid_header","http_500","http_502","http_503","http_504","http_403","http_404","http_429","non_idempotent","off"]:
                return jsonify(state="failed",msg=u"{pnu} proxy_next_upstream无效".format(pnu=pnu))

        upstream_data = upstreams["upstream_data"]
        for up in upstream_data:
            upstream_backend = up["upstream_backend"]
            upstream_weight = up["upstream_weight"]
            # 验证源服务器
            ret, err = is_backend_server_valid(upstream_backend)
            if not ret:
                return jsonify(state="failed",msg=err)

            # 验证权重
            if not is_number(upstream_weight) or int(upstream_weight) <= 0:
                return jsonify(state="failed",msg=u"{upstream_weight}权重无效".format(upstream_weight=upstream_weight))

    else:
        ret, err = is_backend_server_valid(upstream_ip)
        if not ret:
            return jsonify(state="failed",msg=err)

    # 检查回源端口
    if not is_port_valid(http_port):
        return jsonify(state="failed",msg=u"http回源端口{http_port}无效".format(http_port=http_port))


    # 检查https
    if enable_https == True:
        # https回源端口
        if not is_port_valid(https_port):
            return jsonify(state="failed",msg=u"https回源端口{https_port}无效".format(https_port=https_port))

        # proxy ssl协议
        for p in proxy_ssl_protocols.split():
            if p not in ["SSLv2","SSLv3","TLSv1","TLSv1.1","TLSv1.2","TLSv1.3"]:
                return jsonify(state="failed",msg=u"proxy ssl协议{p}无效".format(p=p))

        # 手动输入的协议
        if ca_type == "custom":
            if not is_key_match_cert(key, crt):
                return jsonify(state="failed",msg=u"私钥与证书不匹配")

    # 检查map变量
    available_val = ["$arg_","$args","$binary_remote_addr","$body_bytes_sent","$bytes_sent","$connection","$connection_requests","$content_length","$content_type","$cookie_","$document_root","$document_uri","$host",
                    "$hostname","$http_","$https","$is_args","$limit_rate","$msec","$nginx_version","$pid","$pipe","$proxy_protocol_addr","$query_string","$realpath_root","$remote_addr","$remote_port","$remote_user",
                    "$request","$request_body","$request_body_file","$request_completion","$request_filename","$request_length","$request_method","$request_time","$request_uri","$scheme","$sent_http_","$server_addr",
                    "$server_name","$server_port","$server_protocol","$status","$time_iso8601","$time_local","$uri"]

    map_val = []
    for i in map_data:
        val_string = i["val_string"]
        val_name = i["val_name"]
        val_match = i["val_match"]
        map_val.append(val_name)

        for a in available_val:
            if a.endswith("_"):
                if val_string.startswith(a):
                    break
            else:
                if val_string == a:
                    break
        else:
            return jsonify(state="failed",msg=u"待匹配字符串{val_string}无效".format(val_string=val_string))


        if not val_name.startswith("$"):
            return jsonify(state="failed",msg=u"变量名{val_name}无效".format(val_name=val_name))

        if not re.match(r"^[^ ]+\s+[^ ]+$", val_match):
            return jsonify(state="failed",msg=u"匹配值和结果值格式不对")

    # 检查缓存配置
    available_val = available_val + map_val
    valid_ignore_headers = ["X-Accel-Expires","Expires","Cache-Control","Set-Cookie","Vary","X-Accel-Redirect","X-Accel-Limit-Rate","X-Accel-Buffering","X-Accel-Charset"]
    for i in proxy_cache:
        cache_key = i["cache_key"]
        expire = i["expire"]
        ignore_headers = i["ignore_headers"]
        nocache = i["nocache"]

        # 检查cache_key
        for j in cache_key.split():
            val_in_j = re.findall(r"\$[^\$]+",j)
            if len(val_in_j) == 0:
                return jsonify(state="failed",msg=u"缓存key中的{j}变量无效".format(j=j))

            for k in val_in_j:
                for a in available_val:
                    if a.endswith("_"):
                        if k.startswith(a):
                            break
                    else:
                        if k == a:
                            break
                else:
                    return jsonify(state="failed",msg=u"缓存key中的{k}变量无效".format(k=k))

        # 检查expire
        if not is_number(re.sub(r"[mhd]$","",expire)):
            return jsonify(state="failed",msg=u"{expire}过期时间格式无效".format(expire=expire))

        # 检查ignore_headers
        if ignore_headers != "":
            for i in ignore_headers.split():
                if not i in valid_ignore_headers:
                    return jsonify(state="failed",msg=u"忽略响应头{i}无效".format(i=i))

        # 检查nocache
        if nocache != "":
            for j in nocache.split():
                val_in_j = re.findall(r"\$[^\$]+",j)
                if len(val_in_j) == 0:
                    return jsonify(state="failed",msg=u"拒绝缓存中的{j}变量无效".format(j=j))            

                for k in val_in_j:
                    for a in available_val:
                        if a.endswith("_"):
                            if k.startswith(a):
                                break
                        else:
                            if k == a:
                                break
                    else:
                        return jsonify(state="failed",msg=u"拒绝缓存中的{k}变量无效".format(k=k))            

    # 检查line_group,域名数量
    if type != 1:
        # 检查套餐
        product, err = check_user_product(user_id)
        if not product:
            return jsonify(state="failed",msg=err)

        # line_group
        ok, err = check_line_group(user_id, line_group_id, product)
        if not ok:
            return jsonify(state="failed",msg=err)

        # 域名
        ok, err = check_domain_amount(user_id, domain)
        if not ok:
            return jsonify(state="failed",msg=err)

        # 检查流量
        traffic_limit = get_user_traffic_limit(user_id)
        if traffic_limit != 0:
            traffic_used = get_user_traffic_used(user_id)
            if traffic_used > traffic_limit:
                return jsonify(state="failed",msg=u"您的可用流量为0，无法添加网站.") 

    exist, info = check_domain_exist_when_add(domain, line_group_id)
    if exist:
        return jsonify(state="failed",msg=info)

    site = Site(user_id, line_group_id,domain, upstream_ip, http_port, enable_https, https_port, http_back_to_source, force_https, ca_type, 
                crt, key, proxy_cache_json, error404, error50x, cc_rule, auto_cc_rule, allow_spider, hotlink, ca_need_renew, hsts,map_data_json,rewrite_data, enable_http2,
                proxy_connect_timeout, proxy_send_timeout, proxy_read_timeout, proxy_next_upstream, upstreams_json, acl_rule, proxy_ssl_protocols, enable)
    try:
        db.session.add(site)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    site_id = site.id
    # 添加同步任务
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    nodes = line_group.nodes
    sync_sites = []
    for node in nodes:
        node_id = node.id
        enable = node.enable
        if not enable:
            continue

        value = json.dumps({"node_id":node_id,"site_id":site_id,"domain":domain})
        sync_sites.append(value)
        
    create_task("sync_site",domain, json.dumps(sync_sites), user_id)

    # 更新config.json
    if acl_rule != "":
        update_config_json(acl_rule,"acl_rule",[site_id])

    if auto_cc_rule != "":
        update_config_json(auto_cc_rule,"auto_cc_rule",domain.split())


    if enable_https and ca_type == "letsencrypt":
        # 添加签发证书任务
        create_task("issue_ca",domain, json.dumps({"site_id":site_id,"domain":domain,"line_group_id":line_group_id}),user_id)
        crt = ''
        key = ''
        ca_need_renew = True

    return jsonify(state="success",msg=None)

@app.route('/site', methods=['GET'])
@login_required
def get_site_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    id = request.args.get('id')
    site = Site.query.filter_by(id=id).first()
    if type != 1 and site.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限查看此网站')

    return jsonify(state="success",msg=site.to_json_full())

@app.route('/site/update', methods=['POST'])
@login_required
def update_site_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    id = content["id"]
    domain = content["domain"]
    line_group_id = content["line_group_id"]
    upstream_ip = content["upstream_ip"]
    http_port = content["http_port"]
    enable_https = content["enable_https"]
    https_port = content["https_port"]
    http_back_to_source = content["http_back_to_source"]
    force_https = content["force_https"]
    ca_type = content["ca_type"]
    crt = content["crt"]
    key = content["key"]
    proxy_cache = content["proxy_cache"]
    map_data = content['map_data']
    rewrite_data = content['rewrite_data']
    error404 = content["error404"]
    error50x = content["error50x"]
    cc_rule = content["cc_rule"]
    auto_cc_rule = content["auto_cc_rule"]
    allow_spider = content["allow_spider"]
    hotlink = content["hotlink"]
    ca_need_renew = False
    hsts = content["hsts"]
    enable_http2 = content["enable_http2"]
    proxy_connect_timeout = content['proxy_connect_timeout']
    proxy_send_timeout = content['proxy_send_timeout']
    proxy_read_timeout = content['proxy_read_timeout']
    upstreams = content['upstreams']
    proxy_next_upstream = content['proxy_next_upstream']
    acl_rule = content['acl_rule']
    proxy_ssl_protocols = content['proxy_ssl_protocols']

    map_data_json = json.dumps(map_data)
    proxy_cache_json = json.dumps(proxy_cache)
    rewrite_data = json.dumps(rewrite_data)
    upstreams_json = json.dumps(upstreams)
    if acl_rule != "":
        acl_rule = json.dumps(acl_rule)

    if auto_cc_rule != "":
        auto_cc_rule = json.dumps(auto_cc_rule)

    # 域名转换为小写
    domain = domain.lower()

    if domain == "":
        return jsonify(state="failed",msg=u"域名不能为空")

    if http_port == "":
        return jsonify(state="failed",msg=u"后端http端口不能为空")

    if proxy_ssl_protocols == "":
        return jsonify(state="failed",msg=u"proxy_ssl_protocols不能为空")    

    if enable_https == True:
        if https_port == "":
            return jsonify(state="failed",msg=u"后端https端口不能为空")

        if ca_type == "custom":
            if crt == "":
                return jsonify(state="failed",msg=u"证书不能为空")

            if key == "":
                return jsonify(state="failed",msg=u"私钥不能为空")

    # 检查域名有效性
    ret, err = is_domain_valid(domain)
    if not ret:
        return jsonify(state="failed",msg=err)

    # 检查超时
    if not is_number(proxy_connect_timeout):
        return jsonify(state="failed",msg=u"{proxy_connect_timeout} proxy_connect_timeout无效".format(proxy_connect_timeout=proxy_connect_timeout))

    if not is_number(proxy_send_timeout):
        return jsonify(state="failed",msg=u"{proxy_send_timeout} proxy_send_timeout无效".format(proxy_send_timeout=proxy_send_timeout))

    if not is_number(proxy_read_timeout):
        return jsonify(state="failed",msg=u"{proxy_read_timeout} proxy_read_timeout无效".format(proxy_read_timeout=proxy_read_timeout))


    # 验证源服务器
    if not upstream_ip and not upstreams:
        return jsonify(state="failed",msg=u"源服务器不能为空")

    if upstream_ip == "":
        fail_timeout = upstreams["fail_timeout"]
        if not is_number(fail_timeout):
            return jsonify(state="failed",msg=u"{fail_timeout}fail_timeout无效".format(fail_timeout=fail_timeout))

        max_fails = upstreams["max_fails"]
        if not is_number(max_fails):
            return jsonify(state="failed",msg=u"{max_fails}max_fails无效".format(max_fails=max_fails))

        for pnu in proxy_next_upstream.split():
            if pnu not in ["error","timeout","invalid_header","http_500","http_502","http_503","http_504","http_403","http_404","http_429","non_idempotent","off"]:
                return jsonify(state="failed",msg=u"{pnu} proxy_next_upstream无效".format(pnu=pnu))

        upstream_data = upstreams["upstream_data"]
        for up in upstream_data:
            upstream_backend = up["upstream_backend"]
            upstream_weight = up["upstream_weight"]
            # 验证源服务器
            ret, err = is_backend_server_valid(upstream_backend)
            if not ret:
                return jsonify(state="failed",msg=err)

            # 验证权重
            if not is_number(upstream_weight) or int(upstream_weight) <= 0:
                return jsonify(state="failed",msg=u"{upstream_weight}权重无效".format(upstream_weight=upstream_weight))

    else:
        ret, err = is_backend_server_valid(upstream_ip)
        if not ret:
            return jsonify(state="failed",msg=err)

    # 检查回源端口
    if not is_port_valid(http_port):
        return jsonify(state="failed",msg=u"http回源端口{http_port}无效".format(http_port=http_port))


    # 检查https
    if enable_https == True:
        # https回源端口
        if not is_port_valid(https_port):
            return jsonify(state="failed",msg=u"https回源端口{https_port}无效".format(https_port=https_port))

        # proxy ssl协议
        for p in proxy_ssl_protocols.split():
            if p not in ["SSLv2","SSLv3","TLSv1","TLSv1.1","TLSv1.2","TLSv1.3"]:
                return jsonify(state="failed",msg=u"proxy ssl协议{p}无效".format(p=p))

        # 手动输入的协议
        if ca_type == "custom":
            if not is_key_match_cert(key, crt):
                return jsonify(state="failed",msg=u"私钥与证书不匹配")

    # 检查map变量
    available_val = ["$arg_","$args","$binary_remote_addr","$body_bytes_sent","$bytes_sent","$connection","$connection_requests","$content_length","$content_type","$cookie_","$document_root","$document_uri","$host",
                    "$hostname","$http_","$https","$is_args","$limit_rate","$msec","$nginx_version","$pid","$pipe","$proxy_protocol_addr","$query_string","$realpath_root","$remote_addr","$remote_port","$remote_user",
                    "$request","$request_body","$request_body_file","$request_completion","$request_filename","$request_length","$request_method","$request_time","$request_uri","$scheme","$sent_http_","$server_addr",
                    "$server_name","$server_port","$server_protocol","$status","$time_iso8601","$time_local","$uri"]

    map_val = []
    for i in map_data:
        val_string = i["val_string"]
        val_name = i["val_name"]
        val_match = i["val_match"]
        map_val.append(val_name)

        for a in available_val:
            if a.endswith("_"):
                if val_string.startswith(a):
                    break
            else:
                if val_string == a:
                    break
        else:
            return jsonify(state="failed",msg=u"待匹配字符串{val_string}无效".format(val_string=val_string))


        if not val_name.startswith("$"):
            return jsonify(state="failed",msg=u"变量名{val_name}无效".format(val_name=val_name))

        if not re.match(r"^[^ ]+\s+[^ ]+$", val_match):
            return jsonify(state="failed",msg=u"匹配值和结果值格式不对")

    # 检查缓存配置
    available_val = available_val + map_val
    valid_ignore_headers = ["X-Accel-Expires","Expires","Cache-Control","Set-Cookie","Vary","X-Accel-Redirect","X-Accel-Limit-Rate","X-Accel-Buffering","X-Accel-Charset"]
    for i in proxy_cache:
        cache_key = i["cache_key"]
        expire = i["expire"]
        ignore_headers = i["ignore_headers"]
        nocache = i["nocache"]

        # 检查cache_key
        for j in cache_key.split():
            val_in_j = re.findall(r"\$[^\$]+",j)
            if len(val_in_j) == 0:
                return jsonify(state="failed",msg=u"缓存key中的{j}变量无效".format(j=j))

            for k in val_in_j:
                for a in available_val:
                    if a.endswith("_"):
                        if k.startswith(a):
                            break
                    else:
                        if k == a:
                            break
                else:
                    return jsonify(state="failed",msg=u"缓存key中的{k}变量无效".format(k=k))

        # 检查expire
        if not is_number(re.sub(r"[mhd]$","",expire)):
            return jsonify(state="failed",msg=u"{expire}过期时间格式无效".format(expire=expire))

        # 检查ignore_headers
        if ignore_headers != "":
            for i in ignore_headers.split():
                if not i in valid_ignore_headers:
                    return jsonify(state="failed",msg=u"忽略响应头{i}无效".format(i=i))

        # 检查nocache
        if nocache != "":
            for j in nocache.split():
                val_in_j = re.findall(r"\$[^\$]+",j)
                if len(val_in_j) == 0:
                    return jsonify(state="failed",msg=u"拒绝缓存中的{j}变量无效".format(j=j))            

                for k in val_in_j:
                    for a in available_val:
                        if a.endswith("_"):
                            if k.startswith(a):
                                break
                        else:
                            if k == a:
                                break
                    else:
                        return jsonify(state="failed",msg=u"拒绝缓存中的{k}变量无效".format(k=k))        

    # 检查line_group,域名数量
    if type != 1:
        # 检查套餐
        product, err = check_user_product(user_id)
        if not product:
            return jsonify(state="failed",msg=err)

        # line_group
        ok, err = check_line_group(user_id, line_group_id, product)
        if not ok:
            return jsonify(state="failed",msg=err)

        # 域名
        ok, err = check_domain_amount(user_id, domain, id)
        if not ok:
            return jsonify(state="failed",msg=err)

    exist, info = check_domain_exist_when_edit(domain, line_group_id, id)
    if exist:
        return jsonify(state="failed",msg=info)

    site = Site.query.filter_by(id=id).first()
    line_group_id_from_db = site.line_group_id
    acl_rule_from_db = site.acl_rule
    auto_cc_rule_from_db = site.auto_cc_rule
    site_enable_from_db = site.enable
    cc_rule_from_db = site.cc_rule
    domain_from_db = site.domain

    # 检查权限
    if type != 1 and site.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限编辑此网站')

    # 当防御规则切换时,清除网站白名单
    if cc_rule != cc_rule_from_db:
        create_task("clean_site_whitelist",domain, json.dumps({"domains":domain, "site_id":id,"line_group_id":line_group_id}), user_id)

    # 当为超级管理员为，才考虑enable的值
    if type == 1:
        site_enable = content["enable"]
    else:
        site_enable = site_enable_from_db


    # 无更改时
    if site_enable == site_enable_from_db:
        # 网站处于开启状态时,才同步，否则不创建同步任务
        if site_enable is True:
            # line_group没有更改时
            if int(line_group_id) == int(line_group_id_from_db):
                # 添加同步任务
                line_group = Line_group.query.filter_by(id=line_group_id).first()
                nodes = line_group.nodes
                sync_sites = []
                for node in nodes:
                    node_id = node.id
                    enable = node.enable
                    if not enable:
                        continue            
                    value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
                    sync_sites.append(value)

                create_task("sync_site", domain, json.dumps(sync_sites), user_id)

            # line_group有更改
            else:
                # 添加删除任务
                line_group = Line_group.query.filter_by(id=line_group_id_from_db).first()
                nodes = line_group.nodes
                del_sites = []
                for node in nodes:
                    node_id = node.id
                    enable = node.enable
                    if not enable:
                        continue       
                             
                    value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
                    del_sites.append(value)

                create_task("del_site",domain, json.dumps(del_sites), user_id)

                # 添加同步任务
                line_group = Line_group.query.filter_by(id=line_group_id).first()
                nodes = line_group.nodes
                sync_sites = []
                for node in nodes:
                    node_id = node.id
                    enable = node.enable
                    if not enable:
                        continue

                    value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
                    sync_sites.append(value)

                create_task("sync_site", domain, json.dumps(sync_sites), user_id)        
    # 状态变更时
    else:
        if site_enable is True:
            # 添加同步任务
            line_group = Line_group.query.filter_by(id=line_group_id).first()
            nodes = line_group.nodes
            sync_sites = []
            for node in nodes:
                node_id = node.id
                enable = node.enable
                if not enable:
                    continue

                value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
                sync_sites.append(value)

            create_task("sync_site", domain, json.dumps(sync_sites), user_id)
        else:
            # 添加删除任务
            line_group = Line_group.query.filter_by(id=line_group_id_from_db).first()
            nodes = line_group.nodes
            del_sites = []
            for node in nodes:
                node_id = node.id
                enable = node.enable
                if not enable:
                    continue       
                         
                value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
                del_sites.append(value)

            create_task("del_site",domain,  json.dumps(del_sites), user_id)                               

    domain_from_db = site.domain
    ca_type_from_db = site.ca_type
    if enable_https and ca_type == "letsencrypt" and domain_from_db != domain:
        create_task("issue_ca",domain, json.dumps({"site_id":id,"domain":domain,"line_group_id":line_group_id}),user_id)
        ca_need_renew = True

    if enable_https and ca_type == "letsencrypt" and ca_type_from_db != "letsencrypt":
        create_task("issue_ca",domain, json.dumps({"site_id":id,"domain":domain,"line_group_id":line_group_id}),user_id)
        ca_need_renew = True

    site.domain = domain
    site.upstream_ip = upstream_ip
    site.http_port = http_port
    site.enable_https = enable_https
    site.https_port = https_port
    site.http_back_to_source = http_back_to_source
    site.force_https = force_https
    site.ca_type = ca_type
    site.crt = crt
    site.key = key
    site.proxy_cache = proxy_cache_json
    site.error404 = error404
    site.error50x = error50x
    site.cc_rule = cc_rule
    site.auto_cc_rule = auto_cc_rule
    site.allow_spider = allow_spider
    site.hotlink = hotlink
    site.ca_need_renew = ca_need_renew
    site.hsts = hsts
    site.enable_http2 = enable_http2
    site.map_data = map_data_json
    site.rewrite_data = rewrite_data
    site.line_group_id = line_group_id
    site.proxy_connect_timeout = proxy_connect_timeout
    site.proxy_send_timeout = proxy_send_timeout
    site.proxy_read_timeout = proxy_read_timeout
    site.proxy_next_upstream = proxy_next_upstream
    site.upstreams = upstreams_json
    site.acl_rule = acl_rule
    site.proxy_ssl_protocols = proxy_ssl_protocols
    # 只有超级管理员才可以控制关闭与开启
    if type == 1:
        site.enable = site_enable

    try:
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    # 更新config.json
    if acl_rule != "":
        update_config_json(acl_rule,"acl_rule",[id])

    if auto_cc_rule != "":
        update_config_json(auto_cc_rule,"auto_cc_rule",domain.split())

    # 删除config.json
    if acl_rule_from_db != "" and acl_rule == "":
        remove_config_json("acl_rule",[id])

    if auto_cc_rule_from_db != None and auto_cc_rule_from_db != "" and auto_cc_rule == "":
        remove_config_json("auto_cc_rule",domain.split())

    removed_domain = list(set(domain_from_db.split()) - set(domain.split()))
    if len(removed_domain) != 0:
        remove_config_json("auto_cc_rule",removed_domain)

    return jsonify(state="success",msg=None)

@app.route('/dns-domains', methods=['GET'])
@login_required
def list_dns_domains_handler(auth):
    dns_providers = Dns_provider.query.all()
    return jsonify(state="success",msg={ dns_provider.dns:dns_provider.domains for dns_provider in dns_providers } )

@app.route('/sites', methods=['GET'])
@login_required
def list_all_site_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    line_group_id = request.args.get('line_group_id')

    if int(line_group_id) == 0 or line_group_id == "" or line_group_id == None:
        res =  db.session.query(Site.id, Site.domain,Site.upstream_ip, Site.enable_https, Site.ca_type, Site.cc_rule , Site.auto_cc_rule ,Site.enable, Line_group.hostname, 
                                Line_group.domain , Line_group.name, Line_group.dns, Line_group.id.label("line_group_id"), User.name.label("user_name"), User.id.label("user_id")).outerjoin(Line_group).outerjoin(User)
    else:
        res =  db.session.query(Site.id, Site.domain,Site.upstream_ip, Site.enable_https, Site.ca_type,Site.cc_rule , Site.auto_cc_rule , Site.enable, Line_group.hostname, 
                                Line_group.domain , Line_group.name, Line_group.dns, Line_group.id.label("line_group_id"),User.name.label("user_name"), User.id.label("user_id")).outerjoin(Line_group).filter(Line_group.id == line_group_id).outerjoin(User)

    if type == 1:
        res = res.all()
    else:
        res = res.filter(User.id == user_id).all()

    return jsonify(state="success",msg=[{"id":r.id,"user_name":r.user_name, "site_domain":r[1],"upstream_ip":r.upstream_ip,"enable_https":r.enable_https,"enable":r.enable, "ca_type":r.ca_type,"cc_rule":r.cc_rule,
                                        "hostname":r.hostname,"domain":r.domain,"name":r.name,"dns":r.dns,"auto_cc_rule":r.auto_cc_rule,"line_group_id":r.line_group_id} for r in res])


@app.route('/all-domain-traffic', methods=['GET'])
@login_required
def list_all_domain_traffic_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    # 输出该用户下的所有域名流量
    user = User.query.filter_by(id=user_id).first()
    product_start = user.product_start

    sites = Site.query.filter_by(user_id=user_id).all()
    domains = []
    for site in sites:
        domains = domains + site.domain.split()
    now = datetime.datetime.now()
    current_year_month = now.strftime("%Y-%m")
    product_start_day = product_start.strftime("-%d %H:%M:%S")
    current_product_start = datetime.datetime.strptime(current_year_month + product_start_day, "%Y-%m-%d %H:%M:%S")
    if current_product_start > now:
        product_cal_start = current_product_start + relativedelta(months=-1)
    else:
        product_cal_start = current_product_start

    domain_traffic = db.session.query(func.sum(Domain_traffic.bytes).label('sum'), Domain_traffic.domain).filter( (Domain_traffic.created_at >= str(product_cal_start)) & (Domain_traffic.created_at < str(now)) ).filter(
                Domain_traffic.domain.in_((domains))).group_by(Domain_traffic.domain).all()
    
    traffic = {}
    for t in domain_traffic:
        traffic[t.domain] = int(t.sum)

    return jsonify(state="success",msg=traffic)

@app.route('/site/delete', methods=['POST'])
@login_required
def del_site_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    id = content["id"]
    site = Site.query.filter_by(id=id).first()
    if site is None:
        return jsonify(state="failed",msg=u"网站不存在")

    # 检查权限
    if type != 1 and site.user_id != user_id:
        return jsonify(state="failed",msg=u"无权限删除此网站")

    domain = site.domain
    acl_rule = site.acl_rule
    auto_cc_rule = site.auto_cc_rule
    line_group_id = site.line_group_id
    Site.query.filter_by(id=id).delete()
    db.session.commit()

    # 添加删除任务
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    nodes = line_group.nodes
    del_sites = []
    for node in nodes:
        node_id = node.id
        enable = node.enable
        if not enable:
            continue

        value = json.dumps({"node_id":node_id,"site_id":id,"domain":domain})
        del_sites.append(value)

    create_task("del_site",domain, json.dumps(del_sites), user_id)

    if acl_rule != "":
        remove_config_json("acl_rule",[id])

    if auto_cc_rule != "":
        remove_config_json("auto_cc_rule",domain.split())

    return jsonify(state="success",msg=u"网站删除成功.")

@app.route('/line-group/add', methods=['POST'])
@login_required
def add_lgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    hostname = content["hostname"]
    dns = content["dns"]
    domain = content["domain"]
    domain_id = content["domain_id"]
    ttl = content["ttl"]
    if dns == None:
        hostname = ""
        ttl = None

    if dns != None and (domain == "" or hostname == "" or ttl == ""):
        return jsonify(state="failed",msg=u"域名、主机名或TTL不能为空")

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")

    group = Line_group(name, description, dns, hostname, domain, domain_id, ttl)
    try:
        db.session.add(group)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    # 创建任务
    if dns != None:
        dns_provider = Dns_provider.query.filter_by(dns=dns).first()
        auth = dns_provider.auth
        id = group.id
        task_value = {"dns":dns,"id":id,"domain":domain,"auth":auth}
        task_value = json.dumps(task_value)

        create_task("domain_line",domain, task_value,1)

    return jsonify(state="success",msg=None)

def get_perm_line_group(product, user_id):
    line_group_id_base = product.line_group.split(",")
    line_group_id_ext = []
    # line_group的扩展套餐
    statement = select([user_product_ext]).where((user_product_ext.c.user_id == user_id) )
    products = db.session.execute(statement)
    if products.rowcount != 0:
        for p in products:
            product_ext_id = p['product_ext_id']
            product_ext = Product_ext.query.filter_by(id=product_ext_id).first()
            if product_ext.type == "line_group":
                line_group_id_ext = line_group_id_ext + product_ext.value.split(",")

    line_group_id = line_group_id_base + line_group_id_ext      

    line_groups = db.session.query(Line_group).filter(Line_group.id.in_((line_group_id))).all()
    return line_groups

@app.route('/line-groups', methods=['GET'])
@login_required
def list_lgroup_handler(auth): 
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    if type == 1:
        groups = Line_group.query.all()
        return jsonify(state="success",msg=[group.to_json() for group in groups])

    # 检查套餐
    product, err = check_user_product(user_id)
    if not product:
        return jsonify(state="failed",msg=err)

    line_groups = get_perm_line_group(product, user_id)

    return jsonify(state="success",msg=[line_group.to_json() for line_group in line_groups])

@app.route('/line-groups-for-monitor', methods=['GET'])
@login_required
def list_lgroup_monitor_handler(auth): 
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    if type == 1:
        groups = Line_group.query.all()
        return jsonify(state="success",msg=[ {"id":group.id,"name":group.name,"nodes": [ {"id":n.id,"name":n.name} for n in group.nodes.all() ],
                                        "sites":[ { "id":d.id,"domains":d.domain.split() } for d in group.sites.all()] } for group in groups])

    # 检查套餐
    product, err = check_user_product(user_id)
    if not product:
        return jsonify(state="failed",msg=err)

    groups = get_perm_line_group(product, user_id)
    return jsonify(state="success",msg=[ {"id":group.id,"name":group.name,"nodes": [ {"id":n.id,"name":n.name} for n in group.nodes.all() ],
                                        "sites":[ { "id":d.id,"domains":d.domain.split() } for d in group.sites.filter(Site.user_id == user_id).all()] } for group in groups])

@app.route('/line-group/delete', methods=['POST'])
@login_required
def del_lgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    Line_group.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/line-group/update', methods=['POST'])
@login_required
def update_lgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    try:
        hostname = content["hostname"]
        domain = content["domain"]
        domain_id = content["domain_id"]
        dns = content["dns"]
        ttl = content["ttl"]
    except KeyError:
        hostname = None
        domain = None
        domain_id = None
        dns = None
        ttl = None

    if dns == None:
        hostname = None
        domain = None
        dns = None
        ttl = None
        domain_id = None

    if dns != None and (domain == "" or hostname == "" or ttl == ""):
        return jsonify(state="failed",msg=u"域名、主机名或TTL不能为空")

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")

    group = Line_group.query.filter_by(id=id).first()
    group.name = name
    group.description = description
    group.hostname = hostname
    group.dns = dns
    group.ttl = ttl
    group.domain = domain
    group.domain_id = domain_id
    db.session.commit()
    return jsonify(state="success",msg=None)

def sync_node_sites(line_group_id, node_id, user_id):
    site_ids = []
    if line_group_id:
        line_group = Line_group.query.filter_by(id=line_group_id).first()
        sites = line_group.sites
        site_ids = [ str(site.id) for site in sites]
    else:
        statement = select([group_node_line]).where((group_node_line.c.node_id == node_id))
        line_group_ids = db.session.execute(statement)

        if line_group_ids != None:
            for line_group_id in line_group_ids:
                line_group_id = line_group_id[1]    

                line_group = Line_group.query.filter_by(id=line_group_id).first()
                sites = line_group.sites
                site_ids = site_ids + [ str(site.id) for site in sites]


    if len(site_ids) != 0:
        value = json.dumps({"node_id":node_id,"site_id":"|".join(site_ids)})
        create_task("sync_node_site",node_id, value, user_id)

@app.route('/line-group-node/add', methods=['POST'])
@login_required
def add_line_group_node_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    line_group_id = content["line_group_id"]
    node_ids = content["node_id"]
    dns = content["dns"]

    if node_ids is None:
        return jsonify(state="failed",msg=u"请选择要添加的节点")

    for node_id in node_ids:
        statement = group_node_line.insert().values(node_id=node_id, line_group_id=line_group_id)
        db.session.execute(statement)

    db.session.commit()

    # 添加同步任务
    for node_id in node_ids:
        sync_node_sites(line_group_id, node_id, user_id)

    return jsonify(state="success",msg=None)

@app.route('/line-group-nodes', methods=['GET'])
@login_required
def get_line_group_node_handler(auth):
    line_group_id = request.args.get('line_group_id')
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    nodes = line_group.nodes
    dns = line_group.dns
    return jsonify(state="success",nodes=[node.to_json() for node in nodes],dns=dns)

@app.route('/line-group-node/delete', methods=['POST'])
@login_required
def delete_line_group_node_handler(auth):
    user_id = auth['id']

    content = request.get_json(silent=True,force=True)
    line_group_id = content["line_group_id"]
    node_id = content["node_id"]

    # 检查除了这个节点,其它是否还有默认线路,如果没有,不允许删除
    statement = select([line]).where((line.c.line_group_id == line_group_id) & (line.c.node_id != node_id) )
    lines = db.session.execute(statement)
    if lines.rowcount != 0:
        for l in lines:
            line_id = l['line_id']
            if str(line_id) == str(0) or str(line_id) == str(1):
                break
        else:
            return jsonify(state="failed",msg=u'仅当前节点有默认线路,无法删除节点.')

    statement = group_node_line.delete().where( (group_node_line.c.line_group_id == line_group_id) & (group_node_line.c.node_id == node_id) )
    db.session.execute(statement)

    statement = select([line]).where((line.c.line_group_id == line_group_id) & (line.c.node_id == node_id) )
    lines = db.session.execute(statement)
    retain = False

    res =  db.session.query(Line_group.dns, Line_group.domain, Line_group.domain_id, Line_group.hostname, Line_group.ttl, Dns_provider.auth).filter(Line_group.id == line_group_id).outerjoin(
                            Dns_provider).first() 

    dns = res.dns
    auth = res.auth
    domain_id = res.domain_id
    domain = res.domain
    hostname = res.hostname
    ttl = res.ttl

    for l in lines:
        record_id = l['record_id']
        line_id = l['line_id']
        if record_id is None:
            return jsonify(state="failed",msg=u'您当前删除的线路还在等待添加,稍等.')

        if (str(line_id) == "0" or str(line_id) == "1") and retain is False:
            retain = True
            data_retain = json.dumps({"action":"del","line_group_id":line_group_id,"record_id":record_id,"dns":dns,"auth":auth,"domain_id":domain_id,"domain":domain,"hostname":hostname,"ttl":ttl})
            continue

        data = json.dumps({"action":"del","line_group_id":line_group_id,"record_id":record_id,"dns":dns,"auth":auth,"domain_id":domain_id,"domain":domain,"hostname":hostname,"ttl":ttl})
        create_task("update_dns_record", hostname + "." + domain, data,1)

    if retain is True:
        create_task("update_dns_record", hostname + "." + domain, data_retain,1)

    statement = line.delete().where( (line.c.node_id==node_id) & (line.c.line_group_id == line_group_id) )
    db.session.execute(statement)
    db.session.commit()

    # 添加删除任务
    line_group = Line_group.query.filter_by(id=line_group_id).first()
    sites = line_group.sites
    site_ids = [ str(site.id) for site in sites]
    if len(site_ids) != 0:
        value = json.dumps({"node_id":node_id,"site_id":"|".join(site_ids)})
        create_task("del_site",node_id, value, user_id)

    return jsonify(state="success",msg=None)

@app.route('/node-line/add', methods=['POST'])
@login_required
def add_node_line_handler(auth):
    content = request.get_json(silent=True,force=True)
    line_group_id = content["line_group_id"]
    node_id = content["node_id"]
    dns = content["dns"]
    ip = content["ip"]
    line_id = content["line_id"]
    line_name = content["line_name"]

    # 检查当此line group的line表记录为空且当lines不为空时,确保lines中有默认线路
    if dns == "dnspod":
        default_line_id = 0

    elif dns == "cloudxns":
        default_line_id = 1
            
    statement = select([line]).where(line.c.line_group_id == line_group_id )
    count = db.session.execute(statement).rowcount
    if count == 0:
        if str(line_id) != str(default_line_id):
            return jsonify(state="failed",msg=u'缺少默认线路')


    statement = line.insert().values(line_group_id=line_group_id,dns=dns, node_id=node_id, ip=ip, line_id=line_id,line_name=line_name,record_id=None)
    ret = db.session.execute(statement)
    db.session.commit()
    id = ret.lastrowid

    res =  db.session.query(Line_group.dns, Line_group.domain, Line_group.domain_id, Line_group.hostname, Line_group.ttl, Dns_provider.auth).filter(Line_group.id == line_group_id).outerjoin(
                            Dns_provider).first() 

    dns = res.dns
    auth = res.auth
    domain_id = res.domain_id
    domain = res.domain
    hostname = res.hostname
    ttl = res.ttl

    data = json.dumps({"action":"add","id":id, "line_group_id":line_group_id,"line_id":line_id,"ip":ip,"node_id":node_id,"dns":dns,"auth":auth,"domain_id":domain_id,"domain":domain,"hostname":hostname,"ttl":ttl})
    create_task("update_dns_record", hostname + "." + domain, data,1)    
    return jsonify(state="success",msg=None)

@app.route('/node-lines', methods=['GET'])
@login_required
def get_node_lines_handler(auth):
    line_group_id = request.args.get('line_group_id')
    node_id = request.args.get('node_id')

    statement = select([line]).where((line.c.line_group_id == line_group_id) & (line.c.node_id == node_id) )
    lines = db.session.execute(statement)

    return jsonify(state="success",msg=[dict(zip(l.keys(), l)) for l in lines])

@app.route('/node-line/delete', methods=['POST'])
@login_required
def delete_node_line_handler(auth):
    content = request.get_json(silent=True,force=True)
    dns = content["dns"]
    line_group_id = content["line_group_id"]
    node_id = content["node_id"]
    ip = content["ip"]
    line_id = content["line_id"]

    # 如果当前删除的是默认节点,就先判断是否是唯一的,如果是,禁止删除
    if dns == "dnspod":
        default_line_id = 0

    elif dns == "cloudxns":
        default_line_id = 1

    if str(line_id) == str(default_line_id):
        statement = select([line]).where((line.c.dns == dns) & (line.c.line_group_id == line_group_id) & (line.c.line_id != line_id) )
        lines = db.session.execute(statement)
        if lines.rowcount != 0:
            for l in lines:
                if str(l['line_id']) == str(default_line_id):
                    break
            else:
                return jsonify(state="failed",msg=u'当前线路为仅有的默认线路,无法删除.')

    statement = select([line]).where((line.c.dns == dns) & (line.c.line_group_id == line_group_id) & (line.c.node_id == node_id) & (line.c.ip == ip) & (line.c.line_id == line_id) )
    ret = db.session.execute(statement).fetchone()
    record_id = ret['record_id']
    if record_id is None:
        return jsonify(state="failed",msg=u'您当前删除的线路还在等待添加,稍等.')

    res =  db.session.query(Line_group.dns, Line_group.domain, Line_group.domain_id, Line_group.hostname, Line_group.ttl, Dns_provider.auth).filter(Line_group.id == line_group_id).outerjoin(
                            Dns_provider).first() 

    dns = res.dns
    auth = res.auth
    domain_id = res.domain_id
    domain = res.domain
    hostname = res.hostname
    ttl = res.ttl

    data = json.dumps({"action":"del","line_group_id":line_group_id,"record_id":record_id,"dns":dns,"auth":auth,"domain_id":domain_id,"domain":domain,"hostname":hostname,"ttl":ttl})
    create_task("update_dns_record",hostname + "." + domain,data,1)

    statement = line.delete().where( (line.c.dns == dns) &(line.c.line_group_id == line_group_id) & (line.c.node_id == node_id)  & (line.c.ip == ip)  & (line.c.line_id == line_id))
    db.session.execute(statement)

    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/group/add', methods=['POST'])
@login_required
def add_pgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    group = Node_group(name, description)
    try:
        db.session.add(group)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/groups', methods=['GET'])
@login_required
def list_pgroup_handler(auth):  
    groups = Node_group.query.all()
    return jsonify(state="success",msg=[group.to_json() for group in groups])


@app.route('/group/delete', methods=['POST'])
@login_required
def del_pgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    Node_group.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/group/update', methods=['POST'])
@login_required
def update_pgroup_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    group = Node_group.query.filter_by(id=id).first()
    group.name = name
    group.description = description
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/nodes', methods=['GET'])
@login_required
def list_node_handler(auth):
    group_id = request.args.get('group_id')
    enable = request.args.get('enable')
    nodes = Node.query 
    if group_id or enable:
        if group_id is not None:
            nodes = nodes.filter_by(group_id=group_id)

        if enable is not None:
            enable = True if int(enable) == 1 else False
            nodes = nodes.filter_by(enable=enable)


    nodes = nodes.all()

    return jsonify(state="success",msg=[node.to_json() for node in nodes])

def add_monitor_item(node_id):
    monitor_items = ["cpu", "sysload", "memory", "tcp_conn", "nginx_cpu", "nginx_conn_active",
                 "nginx_conn_reading", "nginx_conn_writing", "nginx_conn_waiting",
                 "host_traffic","host_req","auto_cc_state"]

    for name in monitor_items:
        item = Item(node_id, name)
        db.session.add(item)

    db.session.commit()
    db.session.close() 

@app.route('/node/add', methods=['POST'])
@login_required
def add_node_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    ip = content["ip"]
    port = content["port"]
    group_id = content["group_id"]
    line_group_ids = json.loads(content["line_group_ids"])

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")

    if ip == "":
        return jsonify(state="failed",msg=u"ip不能为空")

    if port == "":
        return jsonify(state="failed",msg=u"端口不能为空")

    node_query = Node.query.filter_by(name=name).first()
    if node_query is not None:
        return jsonify(state="failed",msg=u"节点名称重名")

    node = Node(name, ip, port, True, None, group_id)
    db.session.add(node)
    db.session.commit()
    node_id = node.id

    # 添加监控项，用于监控
    add_monitor_item(node_id)

    if line_group_ids != None:
        for line_group_id in line_group_ids:
            statement = group_node_line.insert().values(node_id=node_id, line_group_id=line_group_id)
            db.session.execute(statement)
            db.session.commit()

            # 添加同步任务
        sync_node_sites(None, node_id, user_id)

    create_task("sync_config_json","","",1)
    create_task("sync_nginx_conf", "","",1) 

    return jsonify(state="success",msg=None)


@app.route('/node/delete', methods=['POST'])
@login_required
def del_node_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    # 判断是否已经在线路组了
    statement = select([group_node_line]).where((group_node_line.c.node_id == id))
    node = db.session.execute(statement)
    if node.rowcount != 0:
        return jsonify(state="failed",msg=u"该节点正在被使用无法删除！")

    Monitor_history.query.filter_by(node_id=id).delete()
    db.session.commit()

    statement = line.delete().where( (line.c.node_id == id) )
    db.session.execute(statement)

    statement = group_node_line.delete().where( (group_node_line.c.node_id == id) )
    db.session.execute(statement)

    Item.query.filter_by(node_id=id).delete()
    db.session.commit()

    Discovery_item.query.filter_by(node_id=id).delete()
    db.session.commit()

    Node.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/node/update', methods=['POST'])
@login_required
def update_node_handler(auth):
    user_id = auth['id']

    content = request.get_json(silent=True,force=True)
    node_id = content["id"]
    name = content["name"]
    ip = content["ip"]
    port = content["port"]
    enable = content["enable"]
    group_id = content["group_id"]
    if enable == "true":
        enable = True
    else:
        enable = False

    node = Node.query.filter_by(id=node_id).first()
    # 节点从禁用状态更新为可用状态时,同步config.json nginx.conf和网站    
    if node.enable == False and enable == True:
        create_task("sync_config_json","","",1)
        create_task("sync_nginx_conf", "","",1) 
        # 添加同步任务
        sync_node_sites(None, node_id, user_id)  

    node.name = name
    node.ip = ip
    node.port = port
    node.enable = enable

    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/nginx-status', methods=['GET'])
@login_required
def nginx_status(auth):
    nodeid = request.args.get('nodeid')
    node = Node.query.filter_by(id=nodeid).first()
    if node is None:
        return "no nodes"

    ip = node.ip
    port = node.port
    url = "http://{ip}:{port}/v1/nginx-status".format(ip=ip, port=port)
    try:
        r = requests.get(url,timeout=3)
    except requests.ConnectionError:
        print "ConnectionError"
        return ""

    return Response(r.content, mimetype='application/json')

@app.route('/load-status', methods=['GET'])
@login_required
def load_status(auth):
    nodeid = request.args.get('nodeid')
    node = Node.query.filter_by(id=nodeid).first()
    ip = node.ip
    port = node.port
    url = "http://{ip}:{port}/v1/load-status".format(ip=ip, port=port)
    r = requests.get(url,timeout=3)
    return Response(r.content, mimetype='application/json')

@app.route('/net-if', methods=['GET'])
@login_required
def net_if(auth):
    nodeid = request.args.get('nodeid')
    node = Node.query.filter_by(id=nodeid).first()
    ip = node.ip
    port = node.port
    url = "http://{ip}:{port}/v1/monitor?item=net_if_discovery".format(ip=ip, port=port)
    r = requests.get(url,timeout=3)
    return Response(r.content, mimetype='application/json')

@app.route('/net-if-status', methods=['GET'])
@login_required
def net_if_status(auth):
    netif = request.args.get('netif')
    nodeid = request.args.get('nodeid')
    node = Node.query.filter_by(id=nodeid).first()
    ip = node.ip
    port = node.port
    url = "http://{ip}:{port}/v1/net-status?netif={netif}".format(ip=ip, port=port,netif=netif)
    r = requests.get(url,timeout=3)
    return Response(r.content, mimetype='application/json')

@app.route('/get-config', methods=['GET'])
@login_required
def get_config(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    config_tmp = {}
    keys = request.args.get('keys')
    config_file = "conf/httpguard_config.json"

    if type != 1 and keys != "rules":
        return jsonify(state="failed",msg=u'权限不足,只能获取rules.')    

    with open(config_file) as fp:
        config = fp.read()

    config = json.loads(config)
    for key in keys.split(","):
        config_tmp[key] = config[key]

    return jsonify(state="success",msg=config_tmp)

@app.route('/save-config', methods=['POST'])
@login_required
def save_config(auth):
    content = request.get_json(silent=True,force=True)
    config_file = "conf/httpguard_config.json"

    with open(config_file,"r") as fp:
        config = fp.read()

    config = json.loads(config)  

    for k in content:
        config[k] = content[k]

    config_data = json.dumps(config, indent=4)
    with open(config_file,"w") as fp:
        fp.write(config_data)

    create_task("sync_config_json","", "",1)
    return jsonify(state="success",msg=None)

@app.route('/chart', methods=['GET'])
@login_required
def get_chart_data(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    nodeid = request.args.get('nodeid')
    key = request.args.get('key')
    param = request.args.get('param')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    width = int(request.args.get('width'))

    if type != 1:
        allow_keys = ["host_traffic", "host_req"]
        if key not in allow_keys:
            return jsonify(state="failed",msg=u'无权限查看{key}'.format(key=key))

        sites = Site.query.filter_by(user_id=user_id).all()
        domains = []
        for site in sites:
            domains = domains + site.domain.split()

        if param not in domains:
            return jsonify(state="failed",msg=u'无权限查看此域名{param}'.format(param=param))

    max_points = int(width / 30)
    start_time = int(time.mktime(datetime.datetime.strptime(start_date, "%Y-%m-%d %H:%M").timetuple()))
    end_time = int(time.mktime(datetime.datetime.strptime(end_date, "%Y-%m-%d %H:%M").timetuple()))

    minutes = (end_time - start_time) / 60
    hours = (minutes - minutes % 60) / 60
    days = (hours - hours % 24) / 24
    no_cal = False
    if days > max_points:
        step = 1440
        need_point = days
    elif hours > max_points:
        step = 60
        need_point = hours
    elif minutes > max_points:
        step = 1
        need_point = minutes
    else:
        step = 1
        need_point = minutes
        no_cal = True

    times = 0
    get_point = 0
    if not no_cal:
        while True:
            if need_point % max_points == 0:
                times = need_point / max_points
                get_point = max_points
                break

            max_points = max_points - 1
    else:
        times = 1
        get_point = need_point

    step_timestamp = times * step * 60
    timestamp_arr = []
    start_time_align = start_time
    if step != 1:
        start_time_align = start_time - (start_time % (step *60)) + step *60

    if start_time != start_time_align:
        timestamp_arr.append(start_time)

    for i in range(start_time_align,end_time,step_timestamp):
        timestamp_arr.append(i)

    timestamp_arr.append(end_time)

    if param is None or param == "":
        item = key
    else:    
        item = "{key}[{param}]".format(key=key, param=param)

    historys = Monitor_history.query.filter(and_(Monitor_history.node_id==nodeid, Monitor_history.item==item, Monitor_history.clock>=(start_time-step_timestamp), Monitor_history.clock<=end_time))

    timestamp_arr_pos = 0
    total = 0
    num = 0
    value_arr = []
    time_arr = []
    i = 0
    h = 0
    k = 0
    count = historys.count()
    day_timestamp = start_time - ( (start_time + 28800) % 86400) + 86400
    history_arr = [history.to_json() for history in historys]
    while count:
        v = history_arr[k]
        clock = int(v["clock"])
        value = float(v["value"])
        total = total + value
        num = num + 1
        timestamp = int(timestamp_arr[timestamp_arr_pos])

        # 最后一个记录
        if (k + 1) == count:
            # 如果此记录小于或等于当前timestamp，或者大于且相差小于一分钟，则计算此timestamp平均值
            if clock <=timestamp or (clock > timestamp and (clock - timestamp) < 60):
                i = i + 1
                avg = total / num
                date = time.strftime('%H:%M',time.localtime(timestamp))
                if timestamp > (day_timestamp + h*86400):
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                    h = h + 1

                # 如果是第一条记录
                if i == 1:
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

                value_arr.append([i,avg])
                time_arr.append([i,date])
                timestamp_arr_pos = timestamp_arr_pos + 1


            # 否则此记录大于且相差大于一分钟的
            else:
                i = i + 1
                # 如果此timestamp有累积，则丢弃此值计算
                if num > 1:
                    avg = (total - value) / (num -1)
                    date = time.strftime('%H:%M',time.localtime(timestamp))
                    if timestamp > (day_timestamp + h*86400):
                        date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                        h = h + 1

                    # 如果是第一条记录
                    if i == 1:
                        date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

                    value_arr.append([i,avg])
                    time_arr.append([i,date])
                    timestamp_arr_pos = timestamp_arr_pos + 1

                # 否则设置为-1
                else:
                    avg = -1
                    date = time.strftime('%H:%M',time.localtime(timestamp))
                    if timestamp > (day_timestamp + h*86400):
                        date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                        h = h + 1

                    # 如果是第一条记录
                    if i == 1:
                        date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

                    value_arr.append([i,avg])
                    time_arr.append([i,date])
                    timestamp_arr_pos = timestamp_arr_pos + 1


            avg = -1
            # 从下一个timestamp开始，设置余下的为-1
            for pos in range(timestamp_arr_pos, len(timestamp_arr)):
                i = i + 1
                timestamp = int(timestamp_arr[pos])
                date = time.strftime('%H:%M',time.localtime(timestamp))
                if timestamp > (day_timestamp + h*86400):
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                    h = h + 1
                value_arr.append([i,avg])
                time_arr.append([i,date])

            break


        # 刚好在这个timestamp结尾，正常计算
        if clock > timestamp and (clock - timestamp) < 60:
            i = i + 1
            date = time.strftime('%H:%M',time.localtime(timestamp))
            # 如果是第一条记录
            if i == 1:
                date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

            if timestamp > (day_timestamp + h*86400):
                date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                h = h + 1

            avg = total / num
            value_arr.append([i,avg])
            time_arr.append([i,date])
            timestamp_arr_pos = timestamp_arr_pos + 1
            total = 0
            num = 0

        # 这个记录超出这个timestamp，丢弃这个记录，执行计算
        elif clock > timestamp and (clock - timestamp) >= 60:
            i = i + 1
            # 如果此timestamp有累积，则丢弃此值计算
            if num > 1:
                avg = (total - value) / (num -1)
                date = time.strftime('%H:%M',time.localtime(timestamp))
                if timestamp > (day_timestamp + h*86400):
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                    h = h + 1

                # 如果是第一条记录
                if i == 1:
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

                value_arr.append([i,avg])
                time_arr.append([i,date])
                timestamp_arr_pos = timestamp_arr_pos + 1
                total = 0
                num = 0
            # 否则设置为-1
            else:
                avg = -1
                date = time.strftime('%H:%M',time.localtime(timestamp))
                if timestamp > (day_timestamp + h*86400):
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))
                    h = h + 1

                # 如果是第一条记录
                if i == 1:
                    date = time.strftime('%Y-%m-%d %H:%M',time.localtime(timestamp))

                value_arr.append([i,avg])
                time_arr.append([i,date])
                timestamp_arr_pos = timestamp_arr_pos + 1
                total = 0
                num = 0
                continue

        k = k + 1

    return jsonify(state="success",msg={"val":value_arr,"time":time_arr})

@app.route('/get-discovery-value', methods=['GET'])
@login_required
def get_discovery_value(auth):
    key = request.args.get('key')
    nodeid = request.args.get('nodeid')
    like_str = "%{key}%".format(key=key)
    items = Discovery_item.query.filter( (Discovery_item.node_id==nodeid) & (Discovery_item.name.like(like_str)) ).all()
    val_arr = []
    for item in items:
        name = item.name
        val = re.match(r'.*\[(.*)\]',name).group(1)
        val_arr.append(val)

    return jsonify(state="success",msg=val_arr)

@app.route('/messages', methods=['GET'])
@login_required
def list_message_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    filter = request.args.get('filter')
    if filter == "unread":
        messages = Message.query.filter( (Message.read==False ) & (Message.user_id == user_id) ).order_by(desc(Message.created_at)).limit(100)
    else:    
        messages = Message.query.filter_by(user_id=user_id).order_by(desc(Message.created_at)).limit(100)

    return jsonify(state="success",msg=[message.to_json() for message in messages])

@app.route('/mark-msg-read', methods=['POST'])
@login_required
def mark_message_read_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    id = content["id"]
    if id == "all":
        db.session.query(Message).filter_by(user_id=user_id).update(dict(read=1))
        data = None
    else:
        message = Message.query.filter( (Message.id==id) & (Message.user_id == user_id) ).first()
        if message is not None:
            data = message.data
            message.read = 1

    db.session.commit()
    return jsonify(state="success",msg=data)

@app.route('/get-msg-unread', methods=['GET'])
@login_required
def get_msg_unread_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    five_second_ago = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time() - 5)) 
    messages = Message.query.filter( (Message.created_at>=five_second_ago) & (Message.user_id == user_id) )
    count = Message.query.filter( (Message.read==0) & (Message.user_id == user_id) ).count()
    return jsonify(state="success",msg = [message.title for message in messages], count=count)


threadLock = threading.Lock()
SHARE_Q = Queue.Queue()  
_WORKER_THREAD_NUM = 4
TASK_RET = ""

class MyThread(threading.Thread) :

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

@app.route('/start-upgrade', methods=['POST'])
@login_required
def start_upgrade_handler(auth):
    config = Config("upgrade",None)
    db.session.add(config)
    db.session.commit()
    db.session.close()
    return jsonify(state="success",msg = None)

@app.route('/get-upgrade-info', methods=['GET'])
@login_required
def get_upgrade_info_handler(auth):
    try:
        with open("/tmp/master_upgrade_log_file.log","r") as fp:
            msg = fp.read()

    except IOError:
        msg = ""

    return jsonify(state="success",msg = msg)   


@app.route('/dns-providers', methods=['GET'])
@login_required
def list_dns_providers_handler(auth):
    Dns_providers = Dns_provider.query.all()
    return jsonify(state="success",msg=[dns.to_json() for dns in Dns_providers])

@app.route('/dns-provider/update', methods=['POST'])
@login_required
def update_dns_providers_handler(auth):
    content = request.get_json(silent=True,force=True)
    for provider in content:
        dns = provider["dns"]
        auth = provider["auth"]
        auth_json = json.dumps(auth)
        dns_provider = Dns_provider.query.filter_by(dns=dns).first()
        if dns_provider.auth != auth_json:
            if dns == "dnspod" and auth["id"] != "" and auth['token'] != "":
                create_task("get_domain_list",dns, dns, 1)

            if dns == "cloudxns" and auth['api_key'] != "" and auth['secret_key'] != "":
                create_task("get_domain_list",dns,dns, 1)

            if dns == "dns.com" and auth['api_key'] != "" and auth['api_secret'] != "":
                create_task("get_domain_list",dns,dns, 1)

        dns_provider.auth = auth_json
        db.session.commit()

    return jsonify(state="success",msg=None)


@app.route('/lines', methods=['GET'])
@login_required
def get_lines_handler(auth):
    id = request.args.get('id')
    line_group = Line_group.query.filter_by(id=id).first()
    lines = line_group.lines
    return jsonify(state="success",msg=lines)

@app.route('/refresh-domain-list', methods=['POST'])
@login_required
def refresh_domain_list_handler(auth):
    content = request.get_json(silent=True,force=True)
    dns = content["dns"]
    create_task("get_domain_list", dns, dns, 1)
    return jsonify(state="success",msg=None)

@app.route('/sync-nginx-conf', methods=['POST'])
@login_required
def sync_nginx_conf_handler(auth):
    create_task("sync_nginx_conf", "", "", 1)
    return jsonify(state="success",msg=None)

@app.route('/sync-site-conf', methods=['POST'])
@login_required
def sync_site_conf_handler(auth):
    user_id = auth["id"]
    content = request.get_json(silent=True,force=True)
    node_id = content["node_id"]
    if node_id == "":
        nodes = Node.query.filter_by(enable=True).all()
        for node in nodes:
            node_id = node.id   
            # 添加同步任务
            sync_node_sites(None, node_id, user_id)
    else:
        sync_node_sites(None, node_id, user_id)

    return jsonify(state="success",msg=None)

@app.route('/clean-site-cache', methods=['POST'])
@login_required
def clean_site_cache_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    value = content['value']
    site = json.loads(value)
    site_id = site['site_id']
    site_t = Site.query.filter_by(id=site_id).first()
    if site_t is None:
        return jsonify(state="failed",msg=u"此网站不存在")

    if user_id != site_t.user_id:
        return jsonify(state="failed",msg=u"无权限删除此网站缓存")

    create_task("clean_site_cache", site_t.domain, json.dumps(site), user_id)
    return jsonify(state="success",msg=None)

@app.route('/le/reissue', methods=['POST'])
@login_required
def le_reissue_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    id = content["id"]
    site = Site.query.filter_by(id=id).first()
    create_task("issue_ca",site.domain, json.dumps({"site_id":site.id,"domain":site.domain,"line_group_id":site.line_group_id}),user_id)
    return jsonify(state="success",msg=None)

@app.route('/top50ip', methods=['GET'])
@login_required
def top50ip_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    nodeid = request.args.get('nodeid')
    host = request.args.get('host')
    start = request.args.get('start')
    end = request.args.get('end')
    content_type = request.args.get('content_type')

    if type != 1:
        sites = Site.query.filter_by(user_id=user_id).all()
        domains = []
        for site in sites:
            domains = domains + site.domain.split()

        if host != "" and host not in domains:
            return jsonify(state="failed",msg=u'无权限查看此域名{host}'.format(host=host))

    log = db.session.query(Access_log.ip, func.count(1).label("count"),func.sum(Access_log.byte_sent) ).filter( (Access_log.created_at >= start) & (Access_log.created_at <= end)  )
    if nodeid != "" and nodeid != None:
        log = log.filter(Access_log.nodeid==nodeid)

    if host != "" and host != None:
        log = log.filter(Access_log.host==host)
    else:
        if type != 1:
            log = log.filter(Access_log.host.in_((domains)))

    if content_type != "" and content_type != None:
        like_str = "%{content_type}%".format(content_type=content_type)
        log = log.filter(Access_log.content_type.like(like_str) )
        
    res = log.group_by(Access_log.ip).order_by(desc('count')).limit(50).all()
    db.session.close()
    return jsonify(state="success",msg=[{"ip":r[0],"count":r[1],"byte_sent_sum":int(r[2])} for r in res])

@app.route('/top50url', methods=['GET'])
@login_required
def top50url_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    nodeid = request.args.get('nodeid')
    host = request.args.get('host')
    start = request.args.get('start')
    end = request.args.get('end')
    content_type = request.args.get('content_type')

    if type != 1:
        sites = Site.query.filter_by(user_id=user_id).all()
        domains = []
        for site in sites:
            domains = domains + site.domain.split()

        if host != "" and host not in domains:
            return jsonify(state="failed",msg=u'无权限查看此域名{host}'.format(host=host))

    log = db.session.query(Access_log.uri,func.concat( Access_log.scheme,"://",Access_log.host,Access_log.uri).label("url"), func.count(1).label("count"),func.sum(Access_log.byte_sent).label("byte_sent_sum") ).filter( (Access_log.created_at >= start) & (Access_log.created_at <= end)  )
    if nodeid != "" and nodeid != None:
        log = log.filter(Access_log.nodeid==nodeid)

    if host != "" and host != None:
        log = log.filter(Access_log.host==host)
    else:
        if type != 1:
            log = log.filter(Access_log.host.in_((domains)))

    if content_type != "" and content_type != None:
        like_str = "%{content_type}%".format(content_type=content_type)
        log = log.filter(Access_log.content_type.like(like_str) )

    res = log.group_by(Access_log.scheme, Access_log.host, Access_log.uri).order_by(desc('count')).limit(50).all()
    db.session.close()
    return jsonify(state="success",msg=[{"uri":r.uri, "url":r.url,"count":r.count,"byte_sent_sum":int(r.byte_sent_sum)} for r in res])

@app.route('/top50host', methods=['GET'])
@login_required
def top50host_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    nodeid = request.args.get('nodeid')
    start = request.args.get('start')
    end = request.args.get('end')
    content_type = request.args.get('content_type')

    log = db.session.query(Access_log.host, func.count(1).label("count"),func.sum(Access_log.byte_sent).label("byte_sent_sum") ).filter( (Access_log.created_at >= start) & (Access_log.created_at <= end)  )
    if nodeid != "" and nodeid != None:
        log = log.filter(Access_log.nodeid==nodeid)

    if type != 1:
        sites = Site.query.filter_by(user_id=user_id).all()
        domains = []
        for site in sites:
            domains = domains + site.domain.split()

        log = log.filter(Access_log.host.in_((domains)))

    if content_type != "" and content_type != None:
        like_str = "%{content_type}%".format(content_type=content_type)
        log = log.filter(Access_log.content_type.like(like_str) )

    res = log.group_by(Access_log.host).order_by(desc('count')).limit(50).all()
    db.session.close()
    return jsonify(state="success",msg=[{"host":r.host,"count":r.count,"byte_sent_sum":int(r.byte_sent_sum)} for r in res])

@app.route('/realtime-log', methods=['GET'])
@login_required
def realtime_log_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    nodeid = request.args.get('nodeid')
    host = request.args.get('host')
    start = request.args.get('start')
    end = request.args.get('end')
    uri = request.args.get('uri')
    ip = request.args.get('ip')
    content_type = request.args.get('content_type')

    if type != 1:
        sites = Site.query.filter_by(user_id=user_id).all()
        domains = []
        for site in sites:
            domains = domains + site.domain.split()

        if host != "" and host not in domains:
            return jsonify(state="failed",msg=u'无权限查看此域名{host}'.format(host=host))

    log = db.session.query(func.max(Access_log.created_at).label("created_at"), func.count(1).label("count"),Access_log.ip, func.concat(Access_log.method," ",Access_log.scheme,"://",Access_log.host,Access_log.uri," ",
                            Access_log.protocol).label("request"),Access_log.status, func.sum(Access_log.byte_sent).label("byte_sent_sum"), Access_log.referer,Access_log.user_agent ).filter(
                             (Access_log.created_at >= start) & (Access_log.created_at <= end)  )
    if nodeid != "" and nodeid != None:
        log = log.filter(Access_log.nodeid==nodeid)

    if host != "" and host != None:
        log = log.filter(Access_log.host==host)
    else:
        if type != 1:
            log = log.filter(Access_log.host.in_((domains)))

    if uri != "" and uri != None:
        like_str = "%{uri}%".format(uri=uri)
        log = log.filter(Access_log.uri.like(like_str) )

    if ip != "" and ip != None:
        like_str = "%{ip}%".format(ip=ip)
        log = log.filter(Access_log.ip.like(like_str) )

    if content_type != "" and content_type != None:
        like_str = "%{content_type}%".format(content_type=content_type)
        log = log.filter(Access_log.content_type.like(like_str) )

    res = log.group_by(Access_log.ip, Access_log.scheme, Access_log.host, Access_log.uri).order_by(desc('created_at')).limit(50).all()
    db.session.close()
    return jsonify(state="success",msg=[{"created_at":str(r.created_at),"count":r.count,"ip":r.ip, "request":r.request, "byte_sent_sum":int(r.byte_sent_sum), "referer":r.referer, "user_agent":r.user_agent,"status":r.status} for r in res])

@app.route('/product/add', methods=['POST'])
@login_required
def product_add(auth):
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    traffic = content["traffic"]
    domain = content["domain"]
    subdomain = content["subdomain"]
    line_group = content["line_group"]
    month_price = content["month_price"]
    quarter_price = content["quarter_price"]
    year_price = content["year_price"]
    enable = content["enable"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if line_group == "":
        return jsonify(state="failed",msg=u"线路组不能为空")

    product = Product(name, description, traffic, domain, subdomain, line_group, month_price, quarter_price, year_price, enable)
    try:
        db.session.add(product)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/product/save', methods=['POST'])
@login_required
def product_save(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    traffic = content["traffic"]
    domain = content["domain"]
    subdomain = content["subdomain"]
    line_group = content["line_group"]
    month_price = content["month_price"]
    quarter_price = content["quarter_price"]
    year_price = content["year_price"]
    enable = content["enable"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if line_group == "":
        return jsonify(state="failed",msg=u"线路组不能为空")

    product = Product.query.filter_by(id=id).first()

    product.name = name
    product.description = description
    product.traffic = traffic
    product.domain = domain
    product.subdomain = subdomain
    product.line_group = line_group
    product.price_month = month_price
    product.price_quarter = quarter_price
    product.price_year = year_price
    product.enable = enable

    try:
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/products', methods=['GET'])
@login_required
def list_product_handler(auth):
    products = Product.query.all()

    return jsonify(state="success",msg=[product.to_json() for product in products])

@app.route('/product/delete', methods=['POST'])
@login_required
def del_product_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    Product.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/product', methods=['GET'])
@login_required
def get_product_handler(auth):
    id = request.args.get('id')
    product = Product.query.filter_by(id=id).first()
    return jsonify(state="success",msg=product.to_json())


@app.route('/product-ext/add', methods=['POST'])
@login_required
def product_ext_add(auth):
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    type = content["type"]
    value = content["value"]
    month_price = content["month_price"]
    quarter_price = content["quarter_price"]
    year_price = content["year_price"]
    enable = content["enable"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if value == "":
        return jsonify(state="failed",msg=u"值不能为空")

    product_ext = Product_ext(name, description, type, value, month_price, quarter_price, year_price, enable)
    try:
        db.session.add(product_ext)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/product-ext/save', methods=['POST'])
@login_required
def product_ext_save(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    type = content["type"]
    value = content["value"]
    month_price = content["month_price"]
    quarter_price = content["quarter_price"]
    year_price = content["year_price"]
    enable = content["enable"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if value == "":
        return jsonify(state="failed",msg=u"值不能为空")

    product_ext = Product_ext.query.filter_by(id=id).first()

    product_ext.name = name
    product_ext.description = description
    product_ext.type = type
    product_ext.value = value
    product_ext.price_month = month_price
    product_ext.price_quarter = quarter_price
    product_ext.price_year = year_price
    product_ext.enable = enable

    try:
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/products-ext', methods=['GET'])
@login_required
def list_product_ext_handler(auth):
    products_ext = Product_ext.query.all()

    return jsonify(state="success",msg=[product.to_json() for product in products_ext])

@app.route('/product-ext/delete', methods=['POST'])
@login_required
def del_product_ext_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    Product_ext.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/product-ext', methods=['GET'])
@login_required
def get_product_ext_handler(auth):
    id = request.args.get('id')
    product_ext = Product_ext.query.filter_by(id=id).first()
    return jsonify(state="success",msg=product_ext.to_json())

@app.route('/get-version-info', methods=['GET'])
@login_required
def get_version_info_handler(auth):
    current_ver = app.config["VERSION_NAME"]
    current_num = app.config["VERSION_NUM"]
    try:
        r = requests.get(app.config["LATEST_VERSION_URL"]+"?version="+str(current_num))
        content = r.content
        data = json.loads(content)
        state = data['state']
        msg = data['msg'] 
        if state == "success":
            if len(msg) == 0:
                latest_version = current_ver
            else:
                latest_version = msg[len(msg) - 1]["version_name"]
            return jsonify(state="success",current_ver=current_ver,latest_version=latest_version)
        else:
            return jsonify(state="failed",msg=msg)
    except requests.exceptions.Timeout:
        return jsonify(state="failed",msg = u"获取最新版本超时")
    except requests.exceptions.ConnectionError:
        return jsonify(state="failed",msg = u"获取最新版本超时")
    except ValueError:
        return jsonify(state="failed",msg = u"接口异常,返回非json:{content}".format(content=content))

@app.route('/user/add', methods=['POST'])
@login_required
def add_user(auth):
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    email = content["email"]
    description = content["description"]
    type = content["type"]
    password = content["password"]
    enable = content["enable"]
    product_base = content["product_base"]
    product_expire = content["product_expire"]
    balance = content["balance"]

    if name == "":
        return jsonify(state="failed",msg=u"用户名不能为空")
    if email == "":
        return jsonify(state="failed",msg=u"email不能为空")
    if password == "":
        return jsonify(state="failed",msg=u"密码不能为空")
    if balance == "":
        return jsonify(state="failed",msg=u"余额不能为空")

    if type == "2":
        role = 1
    else:
        role = None

    if product_base == "null":
        product_base = None
        product_expire = None
        product_start = None

    else:    
        now = datetime.datetime.now()
        product_expire = (now + relativedelta(months=+int(product_expire))).strftime("%Y-%m-%d %H:%M:%S")
        product_start = now.strftime("%Y-%m-%d %H:%M:%S")

    user = User(name, email, description, type, role, password, enable, product_base, product_expire, product_start, balance)
    try:
        db.session.add(user)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/users', methods=['GET'])
@login_required
def list_user_handler(auth):
    users = User.query.all()

    return jsonify(state="success",msg=[user.to_json() for user in users])

@app.route('/user/delete', methods=['POST'])
@login_required
def del_user_handler(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    User.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/user', methods=['GET'])
@login_required
def get_user_handler(auth):
    id = request.args.get('id')
    user = User.query.filter_by(id=id).first()
    return jsonify(state="success",msg=user.to_json())

@app.route('/user/update', methods=['POST'])
@login_required
def update_user(auth):
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    email = content["email"]
    description = content["description"]
    type = content["type"]
    password = content["password"]
    product_base = content["product_base"]
    renew = content["renew"]
    product_expire = content["product_expire"]
    balance = content["balance"]
    enable = content["enable"]

    if name == "":
        return jsonify(state="failed",msg=u"用户名不能为空")
    if email == "":
        return jsonify(state="failed",msg=u"email不能为空")
    if balance == "":
        return jsonify(state="failed",msg=u"余额不能为空")

    if type == "2":
        role = 1
    else:
        role = None

    user = User.query.filter_by(id=id).first()
    product_base_from_db = user.product_base
    product_expire_from_db = user.product_expire
    user.name = name
    user.email = email
    user.description = description
    user.type = type
    if password != "":
        user.password = password

    if product_base_from_db is None:
        if product_base != "null":
            now = datetime.datetime.now()
            product_expire = (now + relativedelta(months=+int(product_expire))).strftime("%Y-%m-%d %H:%M:%S")
            product_start = now.strftime("%Y-%m-%d %H:%M:%S")
            user.product_base = product_base
            user.product_expire = product_expire
            user.product_start = product_start

    else:    
        user.product_base = product_base
        user.product_expire = (product_expire_from_db + relativedelta(months=+int(renew))).strftime("%Y-%m-%d %H:%M:%S")


    user.balance = balance
    user.enable = enable    
    
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/setting/update', methods=['POST'])
@login_required
def setting_update(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    for name in content:
        value = content[name]
        config = Config.query.filter_by(name=name).first()
        if name == "ngx_client_max_body_size":
            ngx_client_max_body_size_old = config.value

        if name == "ngx_cache_dir":
            ngx_cache_dir_old = config.value

        if name == "ngx_cache_size":
            ngx_cache_size_old = config.value

        if config is None:
            config_add = Config(name, value)
            db.session.add(config_add)
            db.session.commit()
        else:
            config.value = value
            db.session.commit()

    # 如果client_max_body_size有变化，同步nginx.conf
    try:
        ngx_client_max_body_size = content["ngx_client_max_body_size"]        
        if ngx_client_max_body_size_old != ngx_client_max_body_size:
            create_task("sync_nginx_conf", "", "",1)

    except KeyError:
        pass

    # 检测缓存配置是否更改，如果有变动，同步全量网站
    try:
        ngx_cache_dir = content["ngx_cache_dir"]
        ngx_cache_size = content["ngx_cache_size"]

        if (ngx_cache_dir != ngx_cache_dir_old) or (ngx_cache_size != ngx_cache_size_old):
            nodes = Node.query.filter_by(enable=True).all()
            for node in nodes:
                node_id = node.id   
                sync_node_sites(None, node_id, user_id)

    except KeyError:
        pass

    return jsonify(state="success",msg=None)


@app.route('/settings', methods=['GET'])
@login_required
def get_settings(auth):
    names = request.args.get('names')
    ret = {}
    for name in names.split(","):
        config = Config.query.filter_by(name=name).first()
        if config is None:
            value = None
            if name == "register_enable":
                value = True

            if name == "register_balance":
                value = 0    
        else:
            value = config.value
            if name == "register_enable" or name == "smtp_ssl":
                if value == "1":
                    value = True
                else:
                    value = False    

        ret[name] = value

    return jsonify(state="success",msg=ret)

@app.route('/traffic', methods=['GET'])
@login_required
def get_traffic(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    by = request.args.get('by')
    domain = request.args.get('domain')
    site_domain = request.args.get('site')
    user = request.args.get('user')
    scale = request.args.get('scale')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    if by == "domain":
        domain_query = [domain]
    elif by == "site":
        domain_query = site_domain.split()
    elif by == "user":
        if type != 1:
            return jsonify(state="failed",msg=u'权限不足')

        domain_query = []
        sites = Site.query.filter_by(user_id=user).all()
        for site in sites:
            domain_query = domain_query + site.domain.split()

    elif by == "all":
        domain_query = []
        if type == 1:
            sites = Site.query.all()
        else:
            sites = Site.query.filter_by(user_id=user_id).all()

        for site in sites:
            domain_query = domain_query + site.domain.split()

    if scale == "day":
        end_date = (datetime.datetime.strptime(end_date, "%Y-%m-%d") + relativedelta(days=+1)).strftime("%Y-%m-%d")
    else:
        start_date = start_date + "-01"
        end_date = (datetime.datetime.strptime(end_date, "%Y-%m") + relativedelta(months=+1)).strftime("%Y-%m") + "-01"

    traffic = db.session.query(Domain_traffic).filter(Domain_traffic.domain.in_((domain_query))).filter( (Domain_traffic.created_at >= start_date) & (Domain_traffic.created_at < end_date )).all()
    traffic_arr = [ t.to_json() for t in traffic]

    date_range = []
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    date_range.append(start_date)
    pos_date = start_date
    while pos_date < end_date:
        if scale == "day":
            pos_date = pos_date + relativedelta(days=+1)
        else:
            pos_date = pos_date + relativedelta(months=+1)  

        date_range.append(pos_date)

    k = 0
    value_arr = []
    time_arr = []
    for d in range(len(date_range) - 1):
        bytes = 0
        while k <= len(traffic_arr) - 1:
            t = traffic_arr[k]

            if date_range[d+1] <= t['created_at']:
                break
            else:
                bytes = bytes + t["bytes"]
                
            k = k + 1

        if scale == "day":
            date_str = date_range[d].strftime("%Y-%m-%d")
        else:
            date_str = date_range[d].strftime("%Y-%m")

        value_arr.append([d+1,bytes])
        time_arr.append([d+1,date_str])

    return jsonify(state="success",msg={"val":value_arr,"time":time_arr})

@app.route('/statistics', methods=['GET'])
@login_required
def get_statistics(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    # 检查套餐
    product, err = check_user_product(user_id)
    if not product:
        return jsonify(state="failed",msg=err)

    top_domain, domains = get_user_domain_amount(user_id)
    top_domain_limit, domains_limit = get_user_domain_limit(user_id)
    traffic_limit = get_user_traffic_limit(user_id)
    traffic_used = get_user_traffic_used(user_id)

    return jsonify(state="success",msg={"top_domain":top_domain, "domains":domains, "top_domain_limit":top_domain_limit, "domains_limit":domains_limit, 
                                        "traffic_limit":traffic_limit, "traffic_used":traffic_used})

@app.route('/user/register', methods=['POST'])
def register():
    config = Config.query.filter_by(name="register_enable").first()
    if config is not None:
        if config.value == "0":
            return jsonify(state="failed",msg=u"当前已关闭注册!")

    content = request.get_json(silent=True,force=True)
    name = content["name"]
    email = content["email"]
    password = content["password"]
    if name == "":
        return jsonify(state="failed",msg=u"用户名不能为空")
    if email == "":
        return jsonify(state="failed",msg=u"email不能为空")
    if password == "":
        return jsonify(state="failed",msg=u"密码不能为空")

    description = ''
    type = 2
    role = 1
    enable = 1
    product_base = None
    product_expire = None
    product_start = None
    balance = 0

    config = Config.query.filter_by(name="register_product").first()
    if config is not None:
        product_base = config.value
        if product_base == "null":
            product_base = None

        product_expire = Config.query.filter_by(name="register_product_expire").first().value

        now = datetime.datetime.now()
        product_expire = (now + relativedelta(months=+int(product_expire))).strftime("%Y-%m-%d %H:%M:%S")
        product_start = now.strftime("%Y-%m-%d %H:%M:%S")


    config = Config.query.filter_by(name="register_balance").first()
    if config is not None:
        balance = config.value

    user = User(name, email, description, type, role, password, enable, product_base, product_expire, product_start, balance)
    try:
        db.session.add(user)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/triggers', methods=['GET'])
@login_required
def get_triggers_handler(auth):
    user_id = auth['id']
    triggers = Trigger_config.query.filter_by(user_id=user_id).all()
    return jsonify(state="success",msg=[trigger.to_json() for trigger in triggers])

@app.route('/contact-groups', methods=['GET'])
@login_required
def get_contact_group_handler(auth):
    user_id = auth['id']
    contact_groups = Contact_group.query.filter_by(user_id=user_id).all()
    return jsonify(state="success",msg=[contact_group.to_json() for contact_group in contact_groups])

@app.route('/contact-group/add', methods=['POST'])
@login_required
def add_contact_group_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    group = Contact_group(user_id, name, description)
    try:
        db.session.add(group)
        db.session.commit()
    except exc.IntegrityError as e:
        return jsonify(state="failed",msg=e[0])

    return jsonify(state="success",msg=None)

@app.route('/contact-group/delete', methods=['POST'])
@login_required
def del_contact_group_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    cg = Contact_group.query.filter_by(id=id).first()
    if cg.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限删除')

    Contact_group.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/contact-group/update', methods=['POST'])
@login_required
def update_contact_group_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]

    cg = Contact_group.query.filter_by(id=id).first()
    if cg.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限更新')

    group = Contact_group.query.filter_by(id=id).first()
    group.name = name
    group.description = description
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/contacts', methods=['GET'])
@login_required
def get_contacts_handler(auth):
    user_id = auth['id']
    group_id = request.args.get('group_id')

    if group_id == "0":
        res = Alarm_contact.query.filter_by(user_id=user_id).all()
    else:
        group = Contact_group.query.filter( (Contact_group.id == group_id) & (Contact_group.user_id == user_id) ).first()
        res = group.contacts

    return jsonify(state="success",msg=[{"id":r.id,"name":r.name, "description":r.description, "group_name":[ g.name for g in r.contact_groups], "email":r.email,"state":r.state} for r in res])

@app.route('/contact', methods=['GET'])
@login_required
def get_contact_handler(auth):
    user_id = auth['id']
    id = request.args.get('id')
    r = Alarm_contact.query.filter( (Alarm_contact.id==id) & (Alarm_contact.user_id == user_id) ).first()
    return jsonify(state="success",msg={"name":r.name, "description":r.description, "email":r.email,"state":r.state, "group_id":[ g.id for g in r.contact_groups]} )

@app.route('/contact/update', methods=['POST'])
@login_required
def update_contact_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    email = content["email"]
    group_ids = json.loads(content["group_ids"])
    state = content["state"]  
    if group_ids is None:
        return jsonify(state="failed",msg=u"联系人组不能为空")

    ac = Alarm_contact.query.filter_by(id=id).first()
    if ac.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限更新')

    contact = Alarm_contact.query.filter_by(id=id).first()
    contact.name = name
    contact.description = description
    contact.email = email
    contact.state = state

    contact.contact_groups = []
    for group_id in group_ids:
        group = Contact_group.query.filter(Contact_group.id == group_id).first()
        contact.contact_groups.append(group)

    db.session.add(contact)
    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/contact/delete', methods=['POST'])
@login_required
def del_contact_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]

    ac = Alarm_contact.query.filter_by(id=id).first()
    if ac.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限删除')

    contact = Alarm_contact.query.filter(Alarm_contact.id == id).first()
    contact_groups = Contact_group.query.join(contact_group_rel).join(Alarm_contact).filter(Alarm_contact.id==id).all()

    for g in contact_groups:
        contact.contact_groups.remove(g)

    db.session.delete(contact)
    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/contact/add', methods=['POST'])
@login_required
def add_contact_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    email = content["email"]
    group_ids = json.loads(content["group_ids"])
    state = content["state"]  
    if group_ids is None:
        return jsonify(state="failed",msg=u"联系人组不能为空")

    contact = Alarm_contact(user_id, name, description, email, state)

    for group_id in group_ids:
        group = Contact_group.query.filter(Contact_group.id == group_id).first()
        contact.contact_groups.append(group)

    db.session.add(contact)
    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/trigger/add', methods=['POST'])
@login_required
def add_trigger_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    name = content["name"]
    description = content["description"]
    item = content["item"]
    period = content["period"]
    func = content["func"]
    op = content["op"]
    value = content["value"]
    continue_times = content["continue_times"]
    state = content["state"]
    silent = content["silent"]
    recover_notify = content["recover_notify"]
    contact_group = content["contact_group"]
    send_to_msg_center = content["send_to_msg_center"]
    notify_way = content["notify_way"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if value == "":
        return jsonify(state="failed",msg=u"阈值不能为空")

    if "send_email" in notify_way.split(","):
        if contact_group == "":
            return jsonify(state="failed",msg=u"通知联系组不能为空")
                        
    trigger = Trigger_config(user_id, name, description, item, period, func, op, value, continue_times, state, silent, recover_notify, contact_group, send_to_msg_center)
    db.session.add(trigger)
    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/trigger/update', methods=['POST'])
@login_required
def update_trigger_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    name = content["name"]
    description = content["description"]
    item = content["item"]
    period = content["period"]
    func = content["func"]
    op = content["op"]
    value = content["value"]
    continue_times = content["continue_times"]
    state = content["state"]
    silent = content["silent"]
    recover_notify = content["recover_notify"]
    contact_group = content["contact_group"]
    send_to_msg_center = content["send_to_msg_center"]
    notify_way = content["notify_way"]

    if name == "":
        return jsonify(state="failed",msg=u"名称不能为空")
    if value == "":
        return jsonify(state="failed",msg=u"阈值不能为空")

    if "send_email" in notify_way.split(","):
        if contact_group == "":
            return jsonify(state="failed",msg=u"通知联系组不能为空")

    trigger = Trigger_config.query.filter_by(id=id).first()
    trigger.name = name
    trigger.description = description
    trigger.item = item
    trigger.period = period
    trigger.func = func
    trigger.op = op
    trigger.value = value
    trigger.continue_times = continue_times
    trigger.state = state
    trigger.silent = silent
    trigger.recover_notify = recover_notify
    trigger.contact_group = contact_group

    db.session.commit()

    return jsonify(state="success",msg=None)

@app.route('/trigger/delete', methods=['POST'])
@login_required
def del_trigger_handler(auth):
    user_id = auth['id']
    content = request.get_json(silent=True,force=True)
    id = content["id"]
    tc = Trigger_config.query.filter_by(id=id).first()
    if tc.user_id != user_id:
        return jsonify(state="failed",msg=u'无权限删除')

    Trigger_event.query.filter_by(trigger_id=id).delete()
    Trigger_config.query.filter_by(id=id).delete()
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/trigger', methods=['GET'])
@login_required
def get_trigger_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    id = request.args.get('id')
    trigger = Trigger_config.query.filter( (Trigger_config.id==id) & (Trigger_config.user_id == user_id) ).first()
    return jsonify(state="success",msg=trigger.to_json())

@app.route('/trigger-event', methods=['GET'])
@login_required
def get_trigger_event_handler(auth):
    user_id = auth['id']
    state = request.args.get('state')
    if state == "all":
        events = db.session.query(Trigger_event.id, Trigger_event.created_at, Trigger_event.recover_at, Trigger_event.notify_at, Trigger_event.res, Trigger_event.state, Trigger_event.notify, 
                    Trigger_event.err,Trigger_config.name,Trigger_event.trigger_id,Trigger_event.current_val, Trigger_event.times).filter( Trigger_event.trigger_id == Trigger_config.id ).outerjoin(Trigger_config).filter(Trigger_event.user_id==user_id).order_by(desc(Trigger_event.id)).limit(100)
    else:
        events = db.session.query(Trigger_event.id, Trigger_event.created_at, Trigger_event.recover_at, Trigger_event.notify_at, Trigger_event.res, Trigger_event.state, Trigger_event.notify, 
                    Trigger_event.err,Trigger_config.name,Trigger_event.trigger_id,Trigger_event.current_val, Trigger_event.times).filter( Trigger_event.trigger_id == Trigger_config.id ).outerjoin(Trigger_config).filter( (Trigger_event.state == 1) & (Trigger_event.user_id==user_id) ).order_by(desc(Trigger_event.id)).limit(100)  

    return jsonify(state="success",msg=[{"id":r.id, "created_at":str(r.created_at), "recover_at":str(r.recover_at), "notify_at":str(r.notify_at),"res":r.res, "state":r.state, "notify":r.notify,
                                        "err":r.err,"name":r.name,"trigger_id":r.trigger_id,"current_val":r.current_val,"times":r.times} for r in events])

@app.route('/clean-site-whitelist', methods=['POST'])
@login_required
def clean_site_whitelist_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    value = content['value']
    site = json.loads(value)
    site_id = site['site_id']
    site_t = Site.query.filter_by(id=site_id).first()
    if site_t is None:
        return jsonify(state="failed",msg=u"此网站不存在")

    if user_id != site_t.user_id:
        return jsonify(state="failed",msg=u"无权限删除此网站白名单")

    create_task("clean_site_whitelist", site_t.domain, json.dumps(site), user_id)
    return jsonify(state="success",msg=None)

@app.route('/clean-site-blacklist', methods=['POST'])
@login_required
def clean_site_blacklist_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    value = content['value']
    site = json.loads(value)
    site_id = site['site_id']
    site_t = Site.query.filter_by(id=site_id).first()
    if site_t is None:
        return jsonify(state="failed",msg=u"此网站不存在")

    if user_id != site_t.user_id:
        return jsonify(state="failed",msg=u"无权限删除此网站黑名单")

    create_task("clean_site_blacklist", site_t.domain, json.dumps(site), user_id)
    return jsonify(state="success",msg=None)

@app.route('/site/clear-certain-cache', methods=['POST'])
@login_required
def clean_certain_cache_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    site_id = content['site_id']

    site_t = Site.query.filter_by(id=site_id).first()
    if site_t is None:
        return jsonify(state="failed",msg=u"此网站不存在")

    if user_id != site_t.user_id:
        return jsonify(state="failed",msg=u"无权限删除此网站缓存")

    create_task("clear_site_certain_cache", site_t.domain, json.dumps(content), user_id)
    return jsonify(state="success",msg=None)


RESTART_NGINX_RET=""
def restart_nginx_worker() :
    global SHARE_Q
    global RESTART_NGINX_RET
    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        ip = data["ip"]
        port = data["port"]


        url = "http://{ip}:{port}/v1/restart-nginx".format(ip=ip, port=port)
        try:
            r = requests.post(url, data="",timeout=10)
            status_code = r.status_code
            if status_code != 200:
                with threadLock:
                    RESTART_NGINX_RET = "{RESTART_NGINX_RET}\nfailed: node {ip}:{port} restart-nginx return status_code:{status_code}".format(RESTART_NGINX_RET=RESTART_NGINX_RET, ip=ip, port=port, status_code=status_code)
                    continue

            content = r.content
            content = json.loads(content)
            state = content["state"]
            msg = content["msg"]
            if state == "success":
                with threadLock:
                    RESTART_NGINX_RET = u"{RESTART_NGINX_RET}\nsuccess: node {ip}:{port} restart-nginx success.".format(ip=ip, port=port, RESTART_NGINX_RET=RESTART_NGINX_RET)
                    continue
            else:
                with threadLock:
                    RESTART_NGINX_RET = u"{RESTART_NGINX_RET}\nfailed: node {ip}:{port} restart-nginx return err:{msg}.".format(ip=ip, port=port,msg=msg, RESTART_NGINX_RET=RESTART_NGINX_RET)
                    continue

        except requests.exceptions.Timeout:
            with threadLock:
                RESTART_NGINX_RET = u"{RESTART_NGINX_RET}\nfailed: node {ip}:{port} restart-nginx timeout.".format(ip=ip, port=port, RESTART_NGINX_RET=RESTART_NGINX_RET)
                continue

        except requests.exceptions.ConnectionError:
            with threadLock:
                RESTART_NGINX_RET = u"{RESTART_NGINX_RET}\nfailed: node {ip}:{port} restart-nginx timeout.".format(ip=ip, port=port, RESTART_NGINX_RET=RESTART_NGINX_RET)
                continue

@app.route('/restart-nginx', methods=['POST'])
@login_required
def restart_nginx(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']
    global RESTART_NGINX_RET

    try:
        if type != 1:
            return jsonify(state="failed",msg=u"无权限")

        global SHARE_Q
        threads = []
        nodes = Node.query.filter_by(enable=True).all()
        for node in nodes:
            data = {"ip":node.ip,"port":node.port}
            SHARE_Q.put(data)

        for i in xrange(_WORKER_THREAD_NUM) :
            thread = MyThread(restart_nginx_worker)
            thread.start()
            threads.append(thread)

        for thread in threads :
            thread.join()

        return jsonify(state="success",msg=RESTART_NGINX_RET)
    finally:
        RESTART_NGINX_RET = ""    

@app.route('/tasks', methods=['GET'])
@login_required
def list_tasks_handler(auth):  
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    if type != 1:
        return jsonify(state="failed",msg=u"无权限")

    state = request.args.get('state')
    if state == "all":
        tasks = Task.query.order_by(desc(Task.create_time)).limit(1000)
    elif state == "not":
        tasks = Task.query.filter( (Task.delflag == 0) & (Task.state != "success") ).order_by(desc(Task.create_time)).limit(1000)
    else:
        tasks = Task.query.filter( (Task.delflag == 1) ).order_by(desc(Task.create_time)).limit(1000)


    return jsonify(state="success",msg=[task.to_json() for task in tasks])

@app.route('/task/cancel', methods=['POST'])
@login_required
def task_cancel_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    content = request.get_json(silent=True,force=True)
    task_id = content['id']

    task = Task.query.filter_by(id=task_id).first()
    if task is None:
        return jsonify(state="failed",msg=u"此任务不存在")

    if type != 1:
        return jsonify(state="failed",msg=u"无权限")

    task.delflag = 1
    db.session.commit()
    return jsonify(state="success",msg=None)

@app.route('/task', methods=['GET'])
@login_required
def task_handler(auth):
    type = auth['type']
    user_id = auth['id']
    role_id = auth['role']

    task_id = request.args.get('id')

    task = Task.query.filter_by(id=task_id).first()
    if task is None:
        return jsonify(state="failed",msg=u"此任务不存在")

    if type != 1:
        return jsonify(state="failed",msg=u"无权限")

    return jsonify(state="success",msg=task.to_full_json())


@app.route('/', methods=['GET'])
def root_admin_home():
    return redirect("/admin/index.html", code=302)

@app.route('/admin/', methods=['GET'])
def admin_home():
    return redirect("/admin/index.html", code=302)

@app.route('/user/', methods=['GET'])
def user_home():
    return redirect("/user/index.html", code=302)

@app.route('/<path:path>', methods=['GET'])
def send_html_handler(path):
    return send_from_directory('panel', path) 



