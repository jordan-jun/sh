-- Copyright (C) Maohai Zhu (admin@centos.bz).

local rewrite = require "resty/rewrite"
local log = ngx.log
local ERR = ngx.ERR

local ok, err = pcall(rewrite.run)
if not ok then
    log(ERR, "rewrite.run error:",err)
end

