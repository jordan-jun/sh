-- Copyright (C) Maohai Zhu (admin@centos.bz).

local logger_socket = require "resty.logger_socket" 
local config = require "resty.config" 
local log = ngx.log
local ERR = ngx.ERR
local concat = table.concat
local ngx_var = ngx.var
local get_headers = ngx.req.get_headers

local function get_client_ip(remote_ip, ip_from_header)
    local client_ip = remote_ip
    if not (ip_from_header == "") and ip_from_header then
        client_ip = type(ip_from_header) == "table" and ip_from_header[1] or ip_from_header
    end

    return client_ip
end

local function send_log(msg)
    local remote_ip = ngx_var.remote_addr
    local headers = get_headers()
    local ip_from_header = headers.ip_from_header
    local realip = get_client_ip(remote_ip, ip_from_header)
    local level = config.log_level
    local data = concat({"[-] [httpguard] [",level,"] [",realip,"] ",msg,"\n"})
    if not logger_socket.initted() then
        local ok, err = logger_socket.init{
            host = config.log.host,
            port = config.log.port,
            flush_limit = config.log.flush_limit,
            drop_limit = config.log.drop_limit,
            periodic_flush = config.log.periodic_flush,
            pool_size = 100,
            sock_type = "udp"
        }
        if not ok then
            log(ERR, "failed to initialize the logger_socket: ",err)
            return
        end
    end
    local bytes, err = logger_socket.log(data)
    if err then
        log(ERR, "failed to log message: ", err)
        return
    end
end

local function debug(...)
    local level = config.log_level
    if level == "debug" then
        local msg = concat({...})
        local debug_ip = config.debug_ip
        local remote_ip = ngx_var.remote_addr
        local headers = get_headers()
        local ip_from_header = headers.ip_from_header
        local realip = get_client_ip(remote_ip, ip_from_header)
        if (debug_ip == realip) or (not debug_ip) or debug_ip == "" then
            send_log(msg)
        end    
    end
end

local function info(...)
    local level = config.log_level
    if level == "debug" or level == "info" then
        local msg = concat({...})
        send_log(msg)
    end
end

local function warning(...)
    local level = config.log_level
    if level == "debug" or level == "info" or level == "warning" then
        local msg = concat({...})  
        send_log(msg)
    end
end

local function error(...)
    local level = config.log_level
    if level == "debug" or level == "info" or level == "warning" or level == "error" then
        local msg = concat({...})
        send_log(msg)
    end
end
return {
    debug = debug,
    info = info,
    warning = warning,
    error = error
}
