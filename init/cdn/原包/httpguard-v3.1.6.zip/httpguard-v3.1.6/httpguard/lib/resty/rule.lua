-- Copyright (C) Maohai Zhu (admin@centos.bz).

local util = require "resty.util"
local config = require "resty.config"
local action = require "resty.action"
local filter = require "resty.filter"
local logger = require "resty.logger"

local table_concat = table.concat
local ngx_var = ngx.var
local get_headers = ngx.req.get_headers
local dict = ngx.shared.guard
local get_uri_args = ngx.req.get_uri_args
local re_find = ngx.re.find
local string_reverse = string.reverse
local string_sub = string.sub
local string_find = string.find
local ngx_time = ngx.time
local ngx_md5 = ngx.md5
local ngx_redirect = ngx.redirect
local ngx_header = ngx.header
local table_getn = table.getn
local ipairs = ipairs
local ngx_req = ngx.req
local table_insert = table.insert
local ac = require "ahocorasick"

-- 临时白名单
local function is_in_tmp_white_ip_list(ip, site_id)
    local white_key = table_concat({site_id,"-",ip, "white"})
    return dict:get(white_key)
end

-- 永久白名单
local function is_in_resident_white_ip_list(white_ip_list, ip)
    return util.is_in_table(ip, white_ip_list)
end

-- 比较值
local function test_val(cond, val, op)
    if not val then
        return false
    end
        
    if op == "=" then
        return (cond == val)
    elseif op == "!=" then
        return (cond ~= val)

    elseif op == "~" then
        return ( re_find(val, cond, "jio") ~= nil)    
    elseif op == "!~" then
        return ( re_find(val, cond, "jio") == nil)    

    elseif op == "contain" then
        return ( string_find(val, cond, 1, true) ~= nil) 
    elseif op == "!contain" then
        return ( string_find(val, cond, 1, true) == nil)      

    elseif op == "AC" then
        local acinst = ac.create(cond)
        return ( ac.match(acinst, val) ~= nil) 
    elseif op == "!AC" then
        local acinst = ac.create(cond)
        return ( ac.match(acinst, val) == nil) 

    end

    return false
end

-- 匹配请求
local function match_request(cur_matcher, client_ip, req_uri, uri, user_agent, referer, host, scheme)
    -- 获取匹配器里各字段的值
    local matcher_ip = cur_matcher.ip
    local matcher_host = cur_matcher.host
    local matcher_req_uri = cur_matcher.req_uri
    local matcher_uri = cur_matcher.uri
    local matcher_useragent = cur_matcher.user_agent
    local matcher_referer = cur_matcher.referer
    local matcher_content_type = cur_matcher.content_type


    -- 定义匹配变量,布尔
    local ip_match = true
    local host_match = true
    local req_uri_match = true
    local uri_match = true
    local user_agent_match = true
    local referer_match = true
    local content_type_match = true


    -- 匹配content_type
    if matcher_content_type then
        local url = table_concat({scheme,"://",host,uri})
        content_type = dict:get(url) or ""
        content_type_match = test_val(matcher_content_type.value, content_type, matcher_content_type.operator)
    end    

    -- 匹配IP
    if matcher_ip then ip_match = test_val(matcher_ip.value, client_ip, matcher_ip.operator) end

    -- 匹配host
    if matcher_host then host_match = test_val(matcher_host.value, host, matcher_host.operator)  end

    -- 匹配req_uri(带参数)
    if matcher_req_uri then uri_match = test_val(matcher_req_uri.value, req_uri, matcher_req_uri.operator) end

    -- 匹配uri(不带参数)
    if matcher_uri then uri_match = test_val(matcher_uri.value, uri, matcher_uri.operator) end

    -- 匹配useragent
    if matcher_useragent then user_agent_match = test_val(matcher_useragent.value,user_agent, matcher_useragent.operator) end

    -- 匹配来源
    if matcher_referer then referer_match = test_val(matcher_referer.value, referer, matcher_referer.operator) end

    return (ip_match and host_match and uri_match and user_agent_match and referer_match and content_type_match)
end

-- 执行动作
local function excute_action(cur_action, client_ip, action_name, filter_name1, filter_name2, site_id)
    local black_key1 = table_concat({site_id,"-",client_ip,"-",filter_name1,"black"})
    local black_key2 = table_concat({site_id,"-",client_ip,"-",filter_name2,"black"})
    if dict:get(black_key2) or util.is_in_table(client_ip, config.other.black_ip_list) or (filter_name1 == "") or (dict:get(black_key1) and filter_name2 == "") then   
        local action_type = cur_action.type
        -- iptables动作
        if action_type == "iptables" then
            action.iptables(client_ip)

        -- 返回码
        elseif action_type == "exit_code" then
            action.exit_code(cur_action.code)
        end        
    end    
end

-- 过滤请求
local function filter_request(cur_filter, client_ip, guardret, filter_name, uri, req_uri, guard, args, site_id)
    local block_time = config.temp_blacklist_block_time
    local white_time = config.temp_whitelist_time

    local filter_type = cur_filter.type
    -- 请求速率过滤
    if filter_type == "req_rate" then
        filter.challenge_verify(client_ip, cur_filter.within_seconds, cur_filter.max_challenge, block_time, filter_name, site_id)
        filter.challenge_verify_uri(client_ip, cur_filter.within_seconds, cur_filter.max_per_uri, block_time, filter_name, req_uri, site_id)

    -- 自动验证浏览器 (要求支持cookie)
    elseif filter_type == "browser_verify_auto" then
        local max_challenge = cur_filter.max_challenge
        local cookie_str = filter.browser_auto(client_ip, cur_filter.within_seconds, max_challenge, block_time, white_time, guardret, guard, filter_name, config.filter, site_id)
        if cookie_str then
            ngx_header['Set-Cookie'] = {table_concat({"guard=",cookie_str,"; path=/"})}
            util.echo_html_gz(config.other.browser_verify_auto_html)      
        else
            return
        end    

    -- 302验证
    elseif filter_type == "302_challenge" then
        local redirect_uri = filter.challenge_302(client_ip, cur_filter.within_seconds, cur_filter.max_challenge, block_time, white_time, filter_name, config.filter, req_uri, args, site_id)
        if redirect_uri then
            return ngx_redirect(redirect_uri)
        else 
            return
        end    

    -- 滑动验证 (要求支持cookie)
    elseif filter_type == "slide" then 
        local max_challenge = cur_filter.max_challenge
        local cookie_str = filter.slide(client_ip, cur_filter.within_seconds, max_challenge, block_time, white_time, guardret, filter_name, config.filter, site_id)
        if cookie_str then
            ngx_header['Set-Cookie'] = {table_concat({"guard=",cookie_str,"; path=/"})}
            util.echo_html_gz(config.other.slide_html)      
        else
            return
        end    

    -- 验证码过滤 
    elseif filter_type == "captcha" then
        local max_challenge = cur_filter.max_challenge
        filter.challenge_verify(client_ip, cur_filter.within_seconds, max_challenge, block_time, filter_name, site_id) 
        util.echo_html(config.other.captcha_html)
    end
end

-- 二次过滤
local function filter_request2(client_ip, filter_name1,filter_name2, cur_filter2,guardret, uri, req_uri, guard, args, site_id)
    local black_key1 = table_concat({site_id,"-",client_ip,"-" ,filter_name1, "black"})
    if dict:get(black_key1) then
        filter_request(cur_filter2, client_ip, guardret, filter_name2, uri, req_uri, guard, args, site_id)
    end
end

local function get_cur_rule(host, rule_name)
    -- 获取默认规则
    local default_rule_name = config.rules.default
    local defult_rule = config.rules[default_rule_name]

    -- 自动开启
    local auto_rule_key = table_concat({host,"-auto_rule"})
    local auto_rule = dict:get(auto_rule_key)
    if auto_rule then
        return config.rules[auto_rule]
    end

    -- 看是否设置有规则,如果没有，使用默认的
    local rule
    if rule_name then
        rule = config.rules[rule_name] or defult_rule
    else
        rule = defult_rule
    end
    return rule
end

local function apply_rule(rules, client_ip, req_uri, uri, user_agent, referer, host, guardret, guard, scheme, args, is_spider, site_id)
    for _, v in ipairs(rules) do
        if not v.state then
            goto continue
        end

        local matcher_name = v.matcher
        local action_name = v.action
        local filter_name1 = v.filter1
        local filter_name2 = v.filter2
        local cur_matcher = config.matcher[matcher_name]
        local cur_action = config.action[action_name]
        local cur_filter1 = config.filter[filter_name1]
        local cur_filter2 = config.filter[filter_name2]

        -- 匹配
        if match_request(cur_matcher, client_ip, req_uri, uri, user_agent, referer, host, scheme) then
            -- 执行动作
            excute_action(cur_action, client_ip, action_name, filter_name1, filter_name2, site_id)

            -- 经过一次动作后,证明没在黑名单，可以放行
            if is_spider then
                return
            end    

            -- 执行二次过滤
            filter_request2(client_ip, filter_name1,filter_name2, cur_filter2,guardret, uri, req_uri, guard, args, site_id)
            -- 执行首次过滤
            filter_request(cur_filter1, client_ip, guardret, filter_name1, uri, req_uri, guard, args, site_id)
            return
        end

        ::continue::
    end
end

local function run()

    -- 获取客户端IP
    local remote_ip = ngx_var.remote_addr
    local headers = get_headers()    
    ngx.ctx.headers = headers
    local client_ip = util.get_client_ip(remote_ip, headers[config.ip_header_name])
    ngx_var.client_ip = client_ip
    ngx.ctx.client_ip = client_ip

    -- site_id和rule_name
    local rule_name = ngx_var.rule_name
    ngx.ctx.rule_name = rule_name
    local site_id = ngx_var.site_id
    ngx.ctx.site_id = site_id

    -- 获取user_agent,referer,host,uri
    local user_agent = headers.user_agent
    local referer = headers.referer
    local host = ngx.ctx.host
    local req_uri = ngx_var.request_uri 
    ngx.ctx.req_uri = req_uri
    local uri = ngx.ctx.uri 
    local allow_spider = ngx_var.allow_spider
    local guardret = ngx_var["cookie_guardret"]
    local guard = ngx_var["cookie_guard"]
    local scheme = ngx.ctx.scheme

    local args = get_uri_args()

    -- 内部请求不限制
    local is_internal = ngx_req.is_internal()
    if is_internal then
        return
    end    

    -- 清空301计数(rewrite.lua)
    local challenge_key = table_concat({client_ip,"301"})
    if dict:get(challenge_key) then
        dict:delete(challenge_key)
    end

    -- 检查是否在永久白名单
    if is_in_resident_white_ip_list(config.other.white_ip_list, client_ip) then
        logger.debug(client_ip, " in resident white ip list.")
        return "in resident white ip list"
    end
    
    -- 检查是否在临时白名单
    if is_in_tmp_white_ip_list(client_ip, site_id) then
        logger.debug(client_ip, " in tmp white ip list.")
        local tmp_whiltelist_rulename = config.rules.tmp_whitelist_rules
        if tmp_whiltelist_rulename == nil then
            return
        end
        local rules = config.rules[tmp_whiltelist_rulename]
        if rules == nil then
            return
        end
        apply_rule(rules, client_ip, req_uri, uri, user_agent, referer, host, guardret, guard, scheme, args, is_spider, site_id)
        return "in tmp white ip list"
    end

    -- 是否开启允许爬虫,如百度,谷歌等
    local is_spider = false
    if (allow_spider == "True") and user_agent then
        for _,v in pairs(config.allow_spider) do
            if string_find(user_agent, v.name, 1, true) then
                local spider_key = table.concat({client_ip,"spider"})
                if not dict:get(spider_key) then
                    dict:lpush("spider-to-be-check", table.concat({client_ip,"-",site_id}))
                    dict:add(spider_key,true)
                end
                is_spider = true
                break
            end
        end    
    end

    -- 获取当前规则列表
    local rules = get_cur_rule(host, rule_name)

    -- 应用规则
    apply_rule(rules, client_ip, req_uri, uri, user_agent, referer, host, guardret, guard, scheme, args, is_spider, site_id)
end

return {
    is_in_tmp_white_ip_list = is_in_tmp_white_ip_list,
    is_in_resident_white_ip_list = is_in_resident_white_ip_list,
    test_val = test_val,
    match_request = match_request,
    excute_action = excute_action,
    filter_request = filter_request,
    get_cur_rule = get_cur_rule,
    apply_rule = apply_rule,
    is_auth = is_auth,
    run = run
}
