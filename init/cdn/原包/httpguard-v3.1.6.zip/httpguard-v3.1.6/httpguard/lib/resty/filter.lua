-- Copyright (C) Maohai Zhu (admin@centos.bz).

local util = require "resty.util"
local logger = require "resty.logger"
local resty_md5 = require "resty.md5"
local aes = require "resty.aes"
local config_util = require "resty.config_util"
local json = require "resty.dkjson"

local dict = ngx.shared.guard
local dict_black = ngx.shared.black
local dict_white = ngx.shared.white
local ngx_time = ngx.time
local type = type
local ngx_md5 = ngx.md5
local table_concat = table.concat
local re_match = ngx.re.match
local re_gsub = ngx.re.gsub
local math_randomseed = math.randomseed
local math_random = math.random
local ngx_exit = ngx.exit
local ngx_var = ngx.var
local tonumber = tonumber
local string_sub = string.sub
local encode_base64 = ngx.encode_base64
local decode_base64 = ngx.decode_base64

-- 添加所有filter临时黑名单
local function block(ip, site_id, filter, block_time)

    for filter_name,_ in pairs(filter) do
        local black_key = table_concat({site_id,"-",ip,"-" ,filter_name, "black"})
        dict:set(black_key, true, block_time)
        -- 先检查下是否在使用get_keys，如果没有使用，才访问dict_black，防止阻塞
        if not dict:get("get_keys_black") then
            dict_black:set(black_key, true, block_time)
        end  
    end   
end

-- 临时黑名单
local function add_to_tmp_blacklist(ip, block_time, filter_name, site_id)
    local black_key = table_concat({site_id,"-",ip,"-" ,filter_name, "black"})
    dict:set(black_key, true, block_time)
    -- 先检查下是否在使用get_keys，如果没有使用，才访问dict_black，防止阻塞
    if not dict:get("get_keys_black") then
        dict_black:set(black_key, true, block_time)
    end
end

-- 添加到临时白名单
local function add_to_tmp_whitelist(ip, white_time, filter, site_id)
    local white_key = table_concat({site_id,"-",ip,"white"})
    dict:set(white_key, true, white_time)
    if not dict:get("get_keys_white") then
        dict_white:set(white_key, true, white_time)
    end    

    for filter_name,_ in pairs(filter) do
        local challenge_key = table_concat({ip,filter_name})
        local black_key = table_concat({site_id,"-",ip, "-" ,filter_name, "black"})
        dict:delete(challenge_key)
        dict:delete(black_key)
        if dict:get("get_keys_black") then
            dict_black:delete(black_key)
        end    
    end    
end

-- 验证失败时计数
local function get_challenge_count(ip, within_seconds, filter_name, site_id)
    local challenge_key = table_concat({ip,filter_name,site_id})

    -- 获取总的挑战次数
    local total_challenges = dict:incr(challenge_key, 1) or 1
    if total_challenges == 1 then
        dict:set(challenge_key, 1, within_seconds)
    end

    -- 返回总请求数
    return total_challenges
end

local function generate_key1(ip, name)
    local now = ngx_time()
    local five_minute = now - (now % 300)
    return string_sub(ngx_md5(table_concat({five_minute,ip,name})),1,8)
end

local function generate_key2(ip, name)
    local now = ngx_time()
    local ten_minute = now - (now % 600)
    return string_sub(ngx_md5(table_concat({ten_minute,ip,name})),1,8)
end

local function aes_encrypt(data, key)
    local md5 = resty_md5:new()
    md5:update(key)
    local digest = md5:final()
    local aes_iv_key = digest

    local aes_iv = aes:new(aes_iv_key, nil, aes.cipher(128,"cbc"), {iv=aes_iv_key})
    return encode_base64(aes_iv:encrypt(tostring(data)))
end

local function aes_decrypt(data, key)
    local md5 = resty_md5:new()
    md5:update(key)
    local digest = md5:final()
    local aes_iv_key = digest

    local aes_iv = aes:new(aes_iv_key, nil, aes.cipher(128,"cbc"), {iv=aes_iv_key})
    return aes_iv:decrypt(data)
end


-- 验证浏览器
local function browser_verify(guardret, aes_key, guard, ip)
    if guard == nil then
        logger.debug("cookie guard is nil")
        return false
    end    

    local random_num = string_sub(guard,9)
    -- 解密random_num
    if not random_num then
        logger.debug("no random_num")
        return false
    end
        
    random_num = decode_base64(random_num)
    if not random_num then
        logger.debug("decode_base64 random_num failed")
        return false
    end
    
    local random_num_plain = aes_decrypt(random_num, aes_key)
    if not random_num_plain then
        logger.debug("first decrypt random_num failed")
        random_num_plain = aes_decrypt(random_num, generate_key2(ip,"browser_auto"))
        if not random_num_plain then
            logger.debug("second decrypt random_num failed")
            return false
        end
    end

    -- 解密guardret
    if not guardret then
        logger.debug("no guardret")
        return false
    end
        
    guardret = decode_base64(guardret)
    if not guardret then
        logger.debug("decode_base64 guardret failed")
        return false
    end

    local guardret_plain = aes_decrypt(guardret, aes_key)
    if not guardret_plain then
        logger.debug("first decrypt guardret failed")
        guardret_plain = aes_decrypt(guardret, generate_key2(ip,"browser_auto"))
        if not guardret_plain then
            logger.debug("second decrypt guardret failed")
            return false
        end
    end

    if not (tonumber(random_num_plain) + 10 == tonumber(guardret_plain)) then
        logger.debug("random_num_plain:",random_num_plain," guardret_plain:",guardret_plain," aes_key:",aes_key)
        logger.debug("guardret_plain +10 not eq")
        return false
    end
    return true
end

-- 验证挑战次数
local function challenge_verify(ip, within_seconds, max_challenge, block_time, filter_name, site_id)
    local cur_challenge = get_challenge_count(ip, within_seconds, filter_name, site_id)
    if cur_challenge > max_challenge then
        logger.info(filter_name,":add ip ",ip, " to temp blacklist")
        add_to_tmp_blacklist(ip, block_time, filter_name, site_id)
    end
end

-- 验证挑战次数(单个uri)
local function challenge_verify_uri(ip, within_seconds, max_challenge, block_time, filter_name, req_uri, site_id)
    local cur_challenge = get_challenge_count(ip, within_seconds, req_uri, site_id)
    if cur_challenge > max_challenge then
        logger.info(filter_name,": per uri add ip ",ip, " to temp blacklist")
        add_to_tmp_blacklist(ip, block_time, filter_name, site_id)
    end
end

-- 自动验证浏览器
local function browser_auto(ip, within_seconds, max_challenge, block_time, white_time, guardret, guard, filter_name, filter, site_id)
    local aes_key = generate_key1(ip,"browser_auto")
    logger.debug("aes_key:",aes_key)

    if browser_verify(guardret, aes_key, guard, ip, site_id) then
        logger.debug("browser verify success.")
        add_to_tmp_whitelist(ip, white_time, filter, site_id)
        return nil
    end

    logger.debug("browser verify failed.")
    challenge_verify(ip, within_seconds, max_challenge, block_time, filter_name, site_id)
    math_randomseed(ngx_time())
    local random = math_random(1,100) --生成1-10000之前的随机数
    local random_base64 = aes_encrypt(random,aes_key)
    return table_concat({aes_key,random_base64})
end

local function slide_verify(data, key, ip)
    if not data then
        logger.debug("guardret is nil.")
        return false        
    end    
    
    local data_encrypt = decode_base64(data)
    if not data_encrypt then
        logger.debug("slide data decode_base64 failed.")
        return false
    end
    
    local data_plain = aes_decrypt(data_encrypt, key)
    if not data_plain then
        logger.debug("first slide data decrypt failed.")
        data_plain = aes_decrypt(data_encrypt, generate_key2(ip,"slide"))
        if not data_plain then
            logger.debug("second slide data decrypt failed.")
            return false        
        end    
    end

    local data_json = json.decode(data_plain)
    if not data_json then
        logger.debug("slide data json.decode failed or data_json is not table.")
        return false
    end

    if not (type(data_json) == "table") then
        logger.debug("slide data_json is not table.")
        return false        
    end

    local move = data_json["move"]
    local btn = data_json["btn"]
    local slider = data_json["slider"]
    local page_width = data_json["page_width"]
    local page_height = data_json["page_height"]

    local move_len = #move
    if move_len < 3 then
        logger.debug("slide move less than 3.")
        return false
    end
    
    local x1, t1
    local miny = 10000
    local maxy = 0
    local pre_time = 0
    for k,v in ipairs(move) do
        if v.timestamp < pre_time then
            pre_time = v.timestamp
            logger.debug("timestamp not right.")
            return false
        end
            
        if v.y > maxy then
            maxy = v.y
        end    

        if v.y < miny then
            miny = v.y
        end    

        if (v.x < 15) or (v.x > page_width) then
            logger.debug("x < 15 or x > page_width")
            return false
        end

        if (v.y < 0) or (v.y > page_height) then
            logger.debug("y < 0 or y > page_height")
            return false
        end

        if k == 1 then 
            x1 = v.x
            t1 = v.timestamp
        end

        if k == move_len then
            if (v.x - x1) < (slider - btn) then
                logger.debug("(v.x - x1) < (slider - btn)")
                return false
            end

            if ((slider - btn) / (v.timestamp - t1)) > 10 then
                logger.debug("too fast slide: ",(slider - btn) / (v.timestamp - t1))
                return false
            else
                return true
            end    
        else
            if v.x > (x1 + slider - btn) then
                logger.debug("v.x > (x1 + slider - btn)")
                return false
            end    
        end 
    end    
end

-- 滑动验证
local function slide(ip, within_seconds, max_challenge, block_time, white_time, guardret, filter_name, filter, site_id)
    local aes_key = generate_key1(ip,"slide")
    logger.debug("aes_key:",aes_key)
    if slide_verify(guardret, aes_key, ip) then
        logger.debug("slide verify success.")
        add_to_tmp_whitelist(ip, white_time, filter, site_id)
        return nil
    end
    logger.debug("slide verify failed.")
    challenge_verify(ip, within_seconds, max_challenge, block_time, filter_name, site_id)
    return aes_key
end

-- 302验证
local function challenge_302(ip, within_seconds, max_challenge, block_time, white_time, filter_name, filter, req_uri, args, site_id)
    local url_redirect
    local cckey = args['cckey']
    local key_gen = generate_key1(ip,"challenge_302")
    if cckey then
        if type(cckey) == "table" then
            cckey = cckey[1]
        end

        if cckey == key_gen then
            logger.debug("challenge_302 verify success.")
            add_to_tmp_whitelist(ip, white_time, filter, site_id)
            return
        end    
    end    

    logger.debug("challenge_302 verify failed.")
    challenge_verify(ip, within_seconds, max_challenge, block_time, filter_name, site_id)

    local req_uri_m = re_match(req_uri, "(.*?)\\?(.+)")
    if req_uri_m then
        local req_uri_none_args = req_uri_m[1]
        local args = req_uri_m[2]
        local args_g = re_gsub(args, "[&?]?cckey=[^&]+&?", "", "i")
        if args_g == "" then
            url_redirect = table_concat({req_uri_none_args,"?cckey=",key_gen})
        else
            url_redirect = table_concat({req_uri_none_args,"?",args_g,"&cckey=",key_gen})
        end                 
    else
        url_redirect = table_concat({req_uri,"?cckey=",key_gen})
    end
    return url_redirect
end

return {
    add_to_tmp_blacklist = add_to_tmp_blacklist,
    add_to_tmp_whitelist = add_to_tmp_whitelist,
    get_challenge_count = get_challenge_count,
    slide = slide,
    browser_auto = browser_auto,
    challenge_verify = challenge_verify,
    generate_key1 = generate_key1,
    generate_key2 = generate_key2,
    encode_base64 = encode_base64,
    decode_base64 = decode_base64,
    aes_encrypt = aes_encrypt,
    aes_decrypt = aes_decrypt,
    challenge_verify_uri = challenge_verify_uri,
    challenge_302 = challenge_302,
    block = block,
}