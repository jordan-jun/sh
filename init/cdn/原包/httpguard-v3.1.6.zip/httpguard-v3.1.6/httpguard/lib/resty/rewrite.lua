-- Copyright (C) Maohai Zhu (admin@centos.bz).

local ngx_var = ngx.var
local string_sub = string.sub
local table_concat = table.concat
local filter = require "resty.filter"
local util = require "resty.util"
local config = require "resty.config"
local action = require "resty.action"
local rule = require "resty.rule"
local get_headers = ngx.req.get_headers

local function run()
    -- 域名转向及301封锁
    local rhost = ngx_var.rhost
    local uri = ngx_var.uri
    ngx.ctx.uri = uri
    local request_uri = ngx_var.request_uri
    if rhost and not ( rhost == "") then
        local code = string_sub(rhost, -3)
        local host_with_scheme = string_sub(rhost, 0, -4)
        local url = table_concat({host_with_scheme,request_uri})
        return ngx.redirect(url, code)
    end
    
    -- http to https    
    local force_https = ngx_var.force_https
    local scheme = ngx_var.scheme
    ngx.ctx.scheme = scheme
    local host = ngx_var.host
    ngx.ctx.host = host
    local enable_https = ngx_var.enable_https
    local url = table_concat({"https://",host,request_uri})
    if (force_https == "True") and (scheme == "http") then
        return ngx.redirect(url, 301)
    end
end

return {
    run = run
}