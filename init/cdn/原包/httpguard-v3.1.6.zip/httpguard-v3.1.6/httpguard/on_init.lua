-- Copyright (C) Maohai Zhu (admin@centos.bz).

local util = require "resty/util"

util.load_captcha()