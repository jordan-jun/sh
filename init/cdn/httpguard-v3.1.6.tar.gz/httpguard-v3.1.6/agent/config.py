MASTER_IPADDR="127.0.0.1"
NGINX_LOCATION="/usr/local/openresty/nginx"
HTTPGUARD_LOCATION="/opt/httpguard/httpguard"
VERSION_NAME='v3.1.5'
VERSION_NUM=31005
LATEST_VERSION_URL="http://guard.centos.bz:8833/get-version-info"
