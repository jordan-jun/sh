## 配置环境
### python模块
```
apt install python-pip -y
pip install Flask==0.12.2
pip install requests
pip install psutil
```
### openresty
```
wget -qO - https://openresty.org/package/pubkey.gpg | sudo apt-key add -
apt-get -y install software-properties-common
add-apt-repository -y "deb http://openresty.org/package/ubuntu $(lsb_release -sc) main"
apt-get update
apt-get -y install --no-install-recommends openresty
```