# -*- coding: utf-8 -*-

from app import app
