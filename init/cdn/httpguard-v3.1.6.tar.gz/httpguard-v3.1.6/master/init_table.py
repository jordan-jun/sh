# -*- coding: utf-8 -*-

from app import db, Node_group, Dns_provider, Line_group, Config, Contact_group

import sys
reload(sys) 
sys.setdefaultencoding('utf-8')   

from sqlalchemy import text
db.create_all()

dns_provider = Dns_provider("dnspod",'')
db.session.add(dns_provider)
dns_provider = Dns_provider("cloudxns",'')
db.session.add(dns_provider)
db.session.commit()

node_group = Node_group("默认",'')
db.session.add(node_group)
db.session.commit()

line_group = Line_group("默认",'',None,None,None,None,None)
db.session.add(line_group)
db.session.commit()

# 同步config.json
sql_list = '''
INSERT INTO `priv` VALUES ('/all-domain-traffic','当前用户所有域名流量'),('/chart','查看历史监控'),('/clean-site-cache','删除网站缓存'),('/dns-domains','DNS域名'),('/dns-provider/update','更新DNS提供商'),('/dns-providers','获取DNS提供商列表'),('/get-config','获取config.json配置'),('/get-discovery-value','获取监控自动发现的值'),('/get-msg-unread','获取未读消息数量'),('/get-upgrade-info','获取升级进度'),('/get-version-info','获取版本信息'),('/group/add','添加节点组'),('/group/delete','删除节点组'),('/group/update','更新节点组'),('/groups','获取节点组列表'),('/le/reissue','重签LE证书'),('/line-group-node/add','添加线路组节点'),('/line-group-node/delete','删除线路组节点'),('/line-group-nodes','获取线路组节点列表'),('/line-group/add','添加线路组'),('/line-group/delete','删除线路组'),('/line-group/update','更新线路组'),('/line-groups','获取线路组列表'),('/line-groups-for-monitor','用于监控的line_group'),('/lines','获取线路组DNS线路'),('/load-status','负载监控'),('/mark-msg-read','标记消息已读'),('/messages','查看消息'),('/net-if','网卡列表'),('/net-if-status','网卡监控'),('/nginx-status','nginx监控'),('/node-line/add','添加节点线路'),('/node-line/delete','删除节点线路'),('/node-lines','获取节点线路列表'),('/node/add','添加节点'),('/node/delete','删除节点'),('/node/update','更新节点'),('/nodes','获取节点列表'),('/product','查看套餐'),('/product/add','添加套餐'),('/product/delete','删除套餐'),('/product/save','更新套餐'),('/products','获取套餐列表'),('/realtime-log','查看实时日志'),('/refresh-domain-list','刷新dns域名列表'),('/save-config','保存config.json配置'),('/site','查看网站'),('/site/add','添加网站'),('/site/delete','删除网站'),('/site/update','更新网站'),('/sites','获取网站列表'),('/start-upgrade','执行升级'),('/statistics','用户统计数据'),('/sync-nginx-conf','同步nginx.conf配置'),('/top50host','查看访问前10个域名'),('/top50ip','查看访问前10个IP'),('/top50url','查看访问前10个URL'),('/traffic','流量统计'),('/unlock-ip','解锁IP');
INSERT INTO `role` VALUES (1,'user','');
INSERT INTO `priv_role` VALUES (1,'/all-domain-traffic'),(1,'/chart'),(1,'/clean-site-cache'),(1,'/get-config'),(1,'/get-msg-unread'),(1,'/line-groups'),(1,'/line-groups-for-monitor'),(1,'/mark-msg-read'),(1,'/messages'),(1,'/realtime-log'),(1,'/site'),(1,'/site/add'),(1,'/site/delete'),(1,'/site/update'),(1,'/sites'),(1,'/statistics'),(1,'/top50host'),(1,'/top50ip'),(1,'/top50url'),(1,'/traffic');
INSERT INTO `user` VALUES (1,'admin','',1,NULL,'guard','',1,NULL,NULL,NULL,0);
insert into priv values ('/clean-site-whitelist','清除网站白名单');
insert into priv values ('/clean-site-blacklist','清除网站黑名单');
insert into priv_role values (1,'/clean-site-whitelist');
insert into priv_role values (1,'/clean-site-blacklist');

insert into priv values ('/triggers','告警列表');
insert into priv values ('/contact-groups','联系组列表');
insert into priv values ('/contact-group/add','添加联系组');
insert into priv values ('/contact-group/delete','删除联系组');
insert into priv values ('/contact-group/update','更新联系组');
insert into priv values ('/contacts','联系人列表');
insert into priv values ('/contact','联系人详情');
insert into priv values ('/contact/update','更新联系人');
insert into priv values ('/contact/delete','删除联系人');
insert into priv values ('/contact/add','添加联系人');
insert into priv values ('/trigger/add','告警添加');
insert into priv values ('/trigger/update','更新告警');
insert into priv values ('/trigger/delete','删除告警');
insert into priv values ('/trigger','告警详情');
insert into priv values ('/trigger-event','告警事件');


insert into priv_role values (1,'/triggers');
insert into priv_role values (1,'/contact-groups');
insert into priv_role values (1,'/contact-group/add');
insert into priv_role values (1,'/contact-group/delete');
insert into priv_role values (1,'/contact-group/update');
insert into priv_role values (1,'/contacts');
insert into priv_role values (1,'/contact');
insert into priv_role values (1,'/contact/update');
insert into priv_role values (1,'/contact/delete');
insert into priv_role values (1,'/contact/add');
insert into priv_role values (1,'/trigger/add');
insert into priv_role values (1,'/trigger/update');
insert into priv_role values (1,'/trigger/delete');
insert into priv_role values (1,'/trigger');
insert into priv_role values (1,'/trigger-event');

insert into trigger_config values (null,1,'CC规则自动切换','','system.auto_cc_state[all,on]',60,'sum','>=',0,0,1,1800,1,'',1);

insert into config values (null,'ngx_cache_dir','/data/nginx/cache');
insert into config values (null,'ngx_cache_size','1g');
insert into config values (null,'ngx_client_max_body_size','2m');

'''

for sql in sql_list.split(";"):
    if sql.strip() == "":
        continue
        
    result = db.engine.execute(text(sql))
    db.session.commit()   