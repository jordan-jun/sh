# -*- coding: utf-8 -*-

import os
import signal
import subprocess
from flask import Flask, jsonify, request,Response, send_from_directory, redirect
from functools import wraps
import time
import datetime
from shutil import copyfile
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import exc, desc, cast, String,and_,create_engine,func
from sqlalchemy.orm import column_property,sessionmaker
from sqlalchemy.sql import select
import json
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from threading import Thread
import base64
import hashlib
from Crypto import Random
from Crypto.Cipher import AES
import requests
import re
from werkzeug.serving import WSGIRequestHandler
from sqlalchemy.dialects.mysql import INTEGER
from sqlalchemy import text

from flask_sqlalchemy import SQLAlchemy as SQLAlchemyBase
from sqlalchemy.pool import NullPool

class SQLAlchemy(SQLAlchemyBase):
  def apply_driver_hacks(self, app, info, options):
    super(SQLAlchemy, self).apply_driver_hacks(app, info, options)
    options['poolclass'] = NullPool
    options.pop('pool_size', None)

WSGIRequestHandler.protocol_version = "HTTP/1.1"
app = Flask(__name__)

app.config.from_envvar('HTTPGUARD_SETTINGS', silent=False)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://{username}:{password}@{ip}:{port}/{db}?charset=utf8'.format(username=app.config['MYSQL_USER'], 
                                                                                                password=app.config['MYSQL_PASS'], 
                                                                                                ip=app.config['MYSQL_IP'],

                                                                                                port=app.config['MYSQL_PORT'],
                                                                                                db=app.config['MYSQL_DB'])
db = SQLAlchemy(app,use_native_unicode="utf8")


class AESCipher(object):

    def __init__(self, key): 
        self.bs = 32
        self.key = hashlib.sha256(key.encode()).digest()

    def encrypt(self, raw):
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(raw))

    def decrypt(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[len(s)-1:])]

class Domain_traffic(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    domain = db.Column(db.String(255), index=True)
    created_at = db.Column(db.DateTime, index=True)
    bytes = db.Column(db.BigInteger)
    __table_args__ = (
        {'mysql_collate': 'utf8_general_ci'},
        )    

    def __init__(self, domain, created_at, bytes):
        self.domain = domain
        self.created_at = created_at
        self.bytes = bytes

    def __repr__(self):
        return '<Domain_traffic %r>' % self.domain

    def to_json(self):
        return {"id":self.id, "domain":self.domain, "created_at":self.created_at,"bytes":self.bytes}

class Monitor_history(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey('node.id'))
    clock = db.Column(db.Integer,index=True)
    item = db.Column(db.String(30),index=True)
    value = db.Column(db.String(255))
    __table_args__ = (
        db.Index('ix_node_id_clock_item', 'node_id', 'clock', 'item'),
        {'mysql_collate': 'utf8_general_ci'},
        )

    def __init__(self, node_id, clock, item, value):
        self.node_id = node_id
        self.clock = clock
        self.item = item
        self.value = value

    def __repr__(self):
        return '<Monitor_history %r>' % self.item

    def to_json(self):
        return {"id":self.id, "node_id":self.node_id, "clock":self.clock,"item":self.item, "value": self.value}


line = db.Table('line',
    db.Column('id', db.Integer, primary_key=True,autoincrement=True),
    db.Column('dns', db.String(255), db.ForeignKey('dns_provider.dns'), primary_key=True),
    db.Column('line_group_id', db.Integer, db.ForeignKey('line_group.id'), primary_key=True),
    db.Column('node_id', db.Integer, db.ForeignKey('node.id'), primary_key=True),
    db.Column('ip', db.String(16), primary_key=True),
    db.Column('line_id', db.String(255), primary_key=True),
    db.Column('line_name', db.String(255)),
    db.Column('record_id', db.String(255)),
    mysql_engine='InnoDB',
    mysql_default_charset = "utf8"
)

class Dns_provider(db.Model):
    dns = db.Column(db.String(255), primary_key=True)
    auth = db.Column(db.String(255))
    domains = db.Column(db.Text)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, dns, auth):
        self.dns = dns
        self.auth = auth

    def __repr__(self):
        return '<Dns_provider %r>' % self.dns

    def to_json(self):
        return {"dns":self.dns, "auth":self.auth}


group_node_line = db.Table('group_node_line',
    db.Column('node_id', db.Integer, db.ForeignKey('node.id'), primary_key=True),
    db.Column('line_group_id', db.Integer, db.ForeignKey('line_group.id'), primary_key=True)
)

class Node_group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),unique=True)
    description = db.Column(db.String(255))

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, description):
        self.name = name
        self.description = description

    def __repr__(self):
        return '<Node_group %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "description": self.description}

class Line_group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),unique=True)
    description = db.Column(db.String(255))
    dns = db.Column(db.String(80), db.ForeignKey('dns_provider.dns'))
    hostname = db.Column(db.String(80))
    sites = db.relationship('Site', backref='_group',lazy='dynamic')
    nodes = db.relationship('Node', secondary=group_node_line, lazy='dynamic',backref=db.backref('groups', lazy=True))    
    domain = db.Column(db.String(255))
    domain_id = db.Column(db.String(255))
    lines = db.Column(db.Text) 
    ttl = db.Column(db.Integer)


    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, description, dns, hostname, domain, domain_id, ttl):
        self.name = name
        self.description = description
        self.dns = dns
        self.hostname = hostname
        self.domain = domain
        self.domain_id = domain_id
        self.ttl = ttl

    def __repr__(self):
        return '<Node_group %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "description": self.description, "dns":self.dns, "hostname":self.hostname, "domain":self.domain, "ttl":self.ttl,"domain_id":self.domain_id}

class Node(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),unique=True)
    ip = db.Column(db.String(16))
    port = db.Column(db.Integer)
    state = db.Column(db.Enum("running", "stopped", "timeout","pending","not_auth","machine_code_failed","sys_err"),default="pending")
    enable = db.Column(db.Boolean,default=True)
    port = db.Column(db.Integer)
    machine_code = db.Column(db.String(255))
    group_id = db.Column(db.Integer, db.ForeignKey('node_group.id'))
    failed_times = db.Column(db.Integer,default=True)
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, ip, port,enable,machine_code,group_id):
        self.name = name
        self.ip = ip
        self.port = port
        self.enable = enable
        self.machine_code = machine_code
        self.group_id = group_id

    def __repr__(self):
        return '<Node %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "ip":self.ip,"port":self.port,"state":self.state,"enable":self.enable,"machine_code":self.machine_code,"group_id":self.group_id}


class Site(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))  
    line_group_id = db.Column(db.Integer, db.ForeignKey('line_group.id'))    
    domain = db.Column(db.String(1000))
    upstream_ip = db.Column(db.String(255))
    http_port = db.Column(db.Integer)
    enable_https = db.Column(db.Boolean)
    https_port = db.Column(db.Integer)
    customize_https_port = db.Column(db.Integer)
    http_back_to_source = db.Column(db.Boolean, default=True)
    force_https = db.Column(db.Boolean)    
    ca_type = db.Column(db.String(80))
    crt = db.Column(db.Text)
    key = db.Column(db.Text)
    proxy_cache = db.Column(db.Text)
    map_data = db.Column(db.Text)
    rewrite_data = db.Column(db.Text)
    error404 = db.Column(db.Text)
    error50x = db.Column(db.Text)
    cc_rule = db.Column(db.String(255))
    auto_cc_rule = db.Column(db.Text, default='')
    allow_spider = db.Column(db.Boolean, default=False)
    hotlink = db.Column(db.String(255))
    ca_need_renew = db.Column(db.Boolean, default=False)
    hsts = db.Column(db.Boolean, default=False)
    enable_http2 = db.Column(db.Boolean, default=False)
    proxy_connect_timeout = db.Column(db.Integer,default=10)
    proxy_send_timeout = db.Column(db.Integer,default=10)
    proxy_read_timeout = db.Column(db.Integer,default=60)
    proxy_next_upstream = db.Column(db.String(255))
    upstreams = db.Column(db.Text)
    acl_rule = db.Column(db.Text)
    proxy_ssl_protocols = db.Column(db.String(255))
    enable = db.Column(db.Boolean)
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, line_group_id,domain, upstream_ip, http_port, enable_https, https_port, http_back_to_source, force_https, ca_type, 
                crt, key, proxy_cache, error404, error50x, cc_rule, auto_cc_rule, allow_spider, hotlink, ca_need_renew, hsts,map_data, rewrite_data,enable_http2,
                proxy_connect_timeout, proxy_send_timeout, proxy_read_timeout, proxy_next_upstream, upstreams, acl_rule, proxy_ssl_protocols, enable, customize_https_port):
        self.user_id = user_id
        self.line_group_id = line_group_id
        self.domain = domain
        self.upstream_ip = upstream_ip
        self.http_port = http_port
        self.enable_https = enable_https
        self.https_port = https_port
        self.customize_https_port = customize_https_port
        self.http_back_to_source = http_back_to_source
        self.force_https = force_https
        self.ca_type = ca_type
        self.crt = crt
        self.key = key
        self.proxy_cache = proxy_cache
        self.error404 = error404
        self.error50x = error50x
        self.cc_rule = cc_rule
        self.auto_cc_rule = auto_cc_rule
        self.allow_spider = allow_spider
        self.hotlink = hotlink
        self.ca_need_renew = ca_need_renew
        self.hsts = hsts
        self.map_data = map_data
        self.rewrite_data = rewrite_data
        self.enable_http2 = enable_http2
        self.proxy_connect_timeout = proxy_connect_timeout
        self.proxy_send_timeout = proxy_send_timeout
        self.proxy_read_timeout = proxy_read_timeout
        self.upstreams = upstreams
        self.proxy_next_upstream = proxy_next_upstream
        self.acl_rule = acl_rule
        self.proxy_ssl_protocols = proxy_ssl_protocols
        self.enable = enable

    def __repr__(self):
        return '<Site %r>' % self.domain

    def to_json(self):
        return {"id":self.id, "line_group_id":self.line_group_id, "domain":self.domain, "upstream_ip":self.upstream_ip, "http_port":self.http_port, "enable_https":self.enable_https, "https_port":self.https_port 
                , "http_back_to_source":self.http_back_to_source, "force_https":self.force_https, "ca_type":self.ca_type,"cc_rule":self.cc_rule, "auto_cc_rule":self.auto_cc_rule, "allow_spider":self.allow_spider,
                 "hotlink":self.hotlink,"hsts":self.hsts,"user_id":self.user_id,"enable":self.enable, "customize_https_port":self.customize_https_port}

    def to_json_full(self):
        return {"id":self.id, "line_group_id":self.line_group_id, "domain":self.domain, "upstream_ip":self.upstream_ip, "http_port":self.http_port, "enable_https":self.enable_https, "https_port":self.https_port 
                , "http_back_to_source":self.http_back_to_source, "force_https":self.force_https, "ca_type":self.ca_type,"crt":self.crt,"key":self.key,"proxy_cache":self.proxy_cache,"error404":self.error404,
                "error50x":self.error50x,"cc_rule":self.cc_rule, "auto_cc_rule":self.auto_cc_rule, "allow_spider":self.allow_spider,"hotlink":self.hotlink,"hsts":self.hsts,"map_data":self.map_data,
                "rewrite_data":self.rewrite_data,"enable_http2":self.enable_http2,"proxy_connect_timeout":self.proxy_connect_timeout,"proxy_send_timeout":self.proxy_send_timeout,
                "proxy_read_timeout":self.proxy_read_timeout,"upstreams":self.upstreams,"proxy_next_upstream":self.proxy_next_upstream,"acl_rule":self.acl_rule,
                "proxy_ssl_protocols":self.proxy_ssl_protocols,"user_id":self.user_id,"enable":self.enable, "customize_https_port":self.customize_https_port}

class Config(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    value = db.Column(db.Text)
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, value):
        self.name = name
        self.value = value

    def __repr__(self):
        return '<Config %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "value": self.value}

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey('node.id'))
    name = db.Column(db.String(80))
    id_name = column_property(cast(node_id,String) + "|" + name)
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, node_id, name):
        self.node_id = node_id
        self.name = name

    def __repr__(self):
        return '<Item %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "node_id": self.node_id}

class Discovery_item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey('node.id'))
    name = db.Column(db.String(80))
    id_name = column_property(cast(node_id,String) + "|" + name)
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, node_id, name):
        self.node_id = node_id
        self.name = name

    def __repr__(self):
        return '<Discovery_item %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "node_id": self.node_id}


class Message(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    title = db.Column(db.String(100))
    data = db.Column(db.Text)
    read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    type = db.Column(db.String(50))
    res = db.Column(db.String(255))
    level = db.Column(db.String(50))
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, title, data, created_at, user_id, type, res, level):
        self.title = title
        self.data = data
        self.created_at = created_at
        self.user_id = user_id
        self.type = type
        self.res = res
        self.level = level

    def __repr__(self):
        return '<Message %r>' % self.title

    def to_json(self):
        if self.created_at is not None:
            self.created_at = str(self.created_at)

        return {"id":self.id, "title":self.title,"read":self.read,"created_at":self.created_at,"type":self.type,"res":self.res,"level":self.level}

class Access_log(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    nodeid = db.Column(db.Integer,index=True)
    created_at = db.Column(db.DateTime,index=True)
    ip = db.Column(db.String(16),index=True)
    method = db.Column(db.String(10))
    scheme = db.Column(db.String(5),index=True)
    host = db.Column(db.String(50),index=True)
    uri = db.Column(db.String(255),index=True)
    protocol = db.Column(db.String(10))
    status = db.Column(db.Integer)
    byte_sent = db.Column(db.Integer)
    referer = db.Column(db.String(255))
    user_agent = db.Column(db.String(255))
    content_type = db.Column(db.String(50))
    
    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, nodeid, created_at, ip,method,scheme,host, uri, protocol,status, byte_sent,referer, user_agent, content_type):
        self.nodeid = nodeid
        self.created_at = created_at
        self.ip = ip
        self.method = method
        self.scheme = scheme
        self.host = host
        self.uri = uri
        self.protocol = protocol
        self.status = status
        self.byte_sent = byte_sent
        self.referer = referer
        self.user_agent = user_agent
        self.content_type = content_type


    def __repr__(self):
        return '<Access_log %r>' % self.ip

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))
    traffic = db.Column(db.Float) #G/月
    domain = db.Column(db.Integer) # 一级域名限制
    subdomain = db.Column(db.Integer) # 子域名限制
    line_group = db.Column(db.String(255)) #线路组限制1,2,3
    price_month = db.Column(db.Float) #元/月
    price_quarter = db.Column(db.Float) #元/季
    price_year = db.Column(db.Float) #元/年
    enable = db.Column(db.Boolean)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, description, traffic, domain, subdomain, line_group, price_month, price_quarter, price_year, enable):
        self.name = name
        self.description = description
        self.traffic = traffic
        self.domain = domain
        self.subdomain = subdomain
        self.line_group = line_group
        self.price_month = price_month
        self.price_quarter = price_quarter
        self.price_year = price_year
        self.enable = enable


    def __repr__(self):
        return '<Product %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "description":self.description,"traffic":self.traffic,"domain":self.domain,"subdomain":self.subdomain,
                    "line_group":self.line_group,"price_month":self.price_month,"price_quarter":self.price_quarter,
                    "price_year":self.price_year,"enable":self.enable}

class Product_ext(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))
    type = db.Column(db.String(255)) # 扩展套餐类型,可选为connection,line_group,domain,traffic
    value = db.Column(db.String(255))
    price_month = db.Column(db.Float) #元/月
    price_quarter = db.Column(db.Float) #元/季
    price_year = db.Column(db.Float) #元/年
    enable = db.Column(db.Boolean)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, description, type, value, price_month, price_quarter, price_year, enable):
        self.name = name
        self.description = description
        self.type = type
        self.value = value
        self.price_month = price_month
        self.price_quarter = price_quarter
        self.price_year = price_year
        self.enable = enable


    def __repr__(self):
        return '<Product %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "description":self.description,"type":self.type,"value":self.value,"price_month":self.price_month,"price_quarter":self.price_quarter,
                    "price_year":self.price_year,"enable":self.enable}

class Priv(db.Model):
    path = db.Column(db.String(255), primary_key=True)
    name = db.Column(db.String(255))

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, path, name):
        self.name = name
        self.path = path

    def __repr__(self):
        return '<Priv %r>' % self.name

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, description):
        self.name = name
        self.description = description

    def __repr__(self):
        return '<Role %r>' % self.name

priv_role = db.Table('priv_role',
    db.Column('role_id', db.Integer, db.ForeignKey('role.id'), primary_key=True),    
    db.Column('priv_path', db.String(255), db.ForeignKey('priv.path'), primary_key=True),
    mysql_engine='InnoDB',
    mysql_default_charset = "utf8"
)

user_product_ext = db.Table('user_product_ext',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),    
    db.Column('product_ext_id', db.Integer, db.ForeignKey('product_ext.id'), primary_key=True),
    db.Column('amount', db.Integer),
    mysql_engine='InnoDB',
    mysql_default_charset = "utf8"
)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255),unique=True) 
    description = db.Column(db.String(255))
    type = db.Column(db.Integer) # 0为普通用户 1为管理员
    role = db.Column(db.Integer, db.ForeignKey('role.id'))
    password = db.Column(db.String(255)) 
    email = db.Column(db.String(255),unique=True) 
    enable = db.Column(db.Boolean,default=True)
    product_base = db.Column(db.Integer, db.ForeignKey('product.id'))
    product_expire = db.Column(db.DateTime)
    product_start = db.Column(db.DateTime)
    balance = db.Column(db.Float)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, name, email, description, type, role, password, enable, product_base, product_expire, product_start, balance):
        self.name = name
        self.email = email
        self.description = description
        self.type = type
        self.role = role
        self.password = password
        self.enable = enable
        self.product_base = product_base
        self.product_expire = product_expire
        self.product_start = product_start
        self.balance = balance


    def __repr__(self):
        return '<User %r>' % self.name

    def to_json(self):
        return {"id":self.id, "name":self.name, "email":self.email,"description":self.description,"type":self.type,"role":self.role,"enable":self.enable,
                    "product_base":self.product_base,"product_expire":str(self.product_expire),"product_start":str(self.product_start),"balance":self.balance}

class Trigger_config(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(100))
    description = db.Column(db.String(255))
    item = db.Column(db.String(255))
    period = db.Column(db.Integer)
    func = db.Column(db.String(255))
    op = db.Column(db.String(10))
    value = db.Column(db.String(255))
    continue_times = db.Column(db.Integer)
    state = db.Column(db.Boolean,default=True)
    silent = db.Column(db.Integer)
    recover_notify = db.Column(db.Boolean,default=True)
    contact_group = db.Column(db.String(255))
    send_to_msg_center = db.Column(db.Boolean,default=False)
    


    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, name, description, item, period, func, op, value, continue_times, state, silent, recover_notify, contact_group, send_to_msg_center):
        self.user_id = user_id
        self.name = name
        self.description = description
        self.item = item
        self.period = period
        self.func = func
        self.op = op
        self.value = value
        self.continue_times = continue_times
        self.state = state
        self.silent = silent
        self.recover_notify = recover_notify
        self.contact_group = contact_group
        self.send_to_msg_center = send_to_msg_center

    def to_json(self):
        return {"id":self.id, "name":self.name, "description":self.description, "item":self.item,"period":self.period,"func":self.func,"op":self.op,"value":self.value,
                    "continue_times":self.continue_times, "state":self.state,"silent":self.silent,"recover_notify":self.recover_notify,"contact_group":self.contact_group,"send_to_msg_center":self.send_to_msg_center}

    def __repr__(self):
        return '<Trigger_config %r>' % self.name

class Trigger_event(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime)
    recover_at = db.Column(db.DateTime)
    notify_at = db.Column(db.DateTime)
    trigger_id = db.Column(db.Integer, db.ForeignKey('trigger_config.id'))
    res = db.Column(db.String(255)) # 报警资源
    state = db.Column(db.Integer) # 1为告警 2为恢复
    times = db.Column(db.Integer)
    notify = db.Column(db.Boolean,default=False)
    err = db.Column(db.String(255)) # 错误信息
    current_val = db.Column(db.Text) # 当前值

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, created_at, recover_at, notify_at, trigger_id, res, state, times, notify, err, current_val):
        self.user_id = user_id
        self.created_at = created_at
        self.recover_at = recover_at
        self.notify_at = notify_at
        self.trigger_id = trigger_id
        self.res = res
        self.state = state
        self.times = times
        self.notify = notify
        self.err = err
        self.current_val = current_val

    def __repr__(self):
        return '<Trigger_event %r>' % self.name

contact_group_rel = db.Table('contact_group_rel',
    db.Column('group_id', db.Integer, db.ForeignKey('contact_group.id'), primary_key=True),    
    db.Column('contact_id', db.Integer, db.ForeignKey('alarm_contact.id'), primary_key=True),
    mysql_engine='InnoDB',
    mysql_default_charset = "utf8"
)

class Contact_group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))
    contacts = db.relationship('Alarm_contact', secondary=contact_group_rel)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, name, description):
        self.user_id = user_id
        self.name = name
        self.description = description

    def to_json(self):
        return {"id":self.id, "name":self.name, "description":self.description}

    def __repr__(self):
        return '<Contact_group %r>' % self.name

class Alarm_contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(255))
    description = db.Column(db.String(255))
    email = db.Column(db.String(255))
    state = db.Column(db.Boolean,default=True)
    contact_groups = db.relationship('Contact_group', secondary=contact_group_rel)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, name, description, email, state):
        self.user_id = user_id
        self.name = name
        self.description = description
        self.email = email
        self.state = state

    def __repr__(self):
        return '<Alarm_contact %r>' % self.name

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(255))
    type = db.Column(db.String(255))
    res = db.Column(db.String(255))
    value = db.Column(db.Text)
    create_time = db.Column(db.DateTime)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    total = db.Column(db.Integer)
    complete = db.Column(db.Integer)
    state = db.Column(db.String(255))
    delflag = db.Column(db.Boolean,default=False)
    ret = db.Column(db.Text)

    __table_args__ = {'mysql_collate': 'utf8_general_ci'}

    def __init__(self, user_id, name, type, res, value, create_time, start_time, end_time, total, complete, state, delflag, ret):
        self.user_id = user_id
        self.name = name
        self.type = type
        self.res = res
        self.value = value
        self.create_time = create_time
        self.start_time = start_time
        self.end_time = end_time
        self.total = total
        self.complete = complete
        self.state = state
        self.delflag = delflag
        self.ret = ret

    def __repr__(self):
        return '<Task %r>' % self.name

    def to_json(self):
        return {"id":self.id, "user_id":self.user_id, "name":self.name,"type":self.type,"res":self.res,"create_time":str(self.create_time),"start_time":str(self.start_time),"end_time":str(self.end_time),
                "total":self.total,"complete":self.complete,"state":self.state,"delflag":self.delflag}

    def to_full_json(self):
        return {"id":self.id, "user_id":self.user_id, "name":self.name,"type":self.type,"res":self.res,"create_time":str(self.create_time),"start_time":str(self.start_time),"end_time":str(self.end_time),
                "total":self.total,"complete":self.complete,"state":self.state,"delflag":self.delflag,"value":self.value,"ret":self.ret}

if __name__ == '__main__':
    WSGIRequestHandler.protocol_version = "HTTP/1.1"
    app.run()
