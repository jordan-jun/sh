# -*- coding: utf-8 -*-

from time import sleep
import requests
import json
import ntpath
import sys
import os

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import Node, db, Discovery_item

def main():
    item_from_db = []
    item_discovery = []
    node_ignore = []

    for i in Discovery_item.query.all():
        id_name = i.id_name
        item_from_db.append(str(id_name))

    nodes = Node.query.filter_by(enable=True)
    for node in nodes:
        id = str(node.id)
        ip = node.ip
        port = node.port

        # discovery disk
        try:
            disk_url = "http://{ip}:{port}/v1/monitor?item=disk_discovery".format(ip=ip, port=port)
            r = requests.get(disk_url,timeout=3)
            body = r.content
            body =  json.loads(body)
            for mount in body["msg"]:
                key1 = "{id}|disk[{mount}]".format(id=id, mount=mount)
                key2 = "{id}|inode[{mount}]".format(id=id, mount=mount)
                item_discovery.append(key1)
                item_discovery.append(key2)

        except requests.exceptions.ConnectionError:
            node_ignore.append(id)
            continue

        except requests.exceptions.Timeout:
            node_ignore.append(id)
            continue

        # discovery net if
        try:
            net_if_url = "http://{ip}:{port}/v1/monitor?item=net_if_discovery".format(ip=ip, port=port)
            r = requests.get(net_if_url,timeout=3)
            body = r.content
            body =  json.loads(body)
            for net in body["msg"]:
                key1 = "{id}|net_recv[{net}]".format(id=id, net=net)
                key2 = "{id}|net_sent[{net}]".format(id=id, net=net)
                item_discovery.append(key1)
                item_discovery.append(key2)

        except requests.exceptions.ConnectionError:
            node_ignore.append(id)
            continue

        except requests.exceptions.Timeout:
            node_ignore.append(id)
            continue
    # add
    for i in list(set(item_discovery) - set(item_from_db)):
        id, name = i.split("|")
        item = Discovery_item(id, name)
        db.session.add(item)

    db.session.commit()

    # delete
    for i in list(set(item_from_db) - set(item_discovery)):
        id, name = i.split("|")
        if str(id) in node_ignore:
            continue

        Discovery_item.query.filter_by(node_id=id,name=name).delete()

    db.session.commit()
    db.session.close()


if __name__ == '__main__':
    main()
