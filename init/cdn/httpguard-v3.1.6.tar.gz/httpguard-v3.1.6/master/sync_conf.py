# -*- coding: utf-8 -*-
import os
os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db, Config, Node, Message, Task
from public_func import make_msg,mark_task_start, mark_task_success, mark_task_failed, mark_task_del, mark_task_done_one
from sqlalchemy import desc
from time import sleep
import threading
import Queue
import json
from jinja2 import Template
import zlib
import requests
import time
import datetime
import ntpath
import sys

threadLock = threading.Lock()
SHARE_Q = Queue.Queue()  
TASK_SUCCESS = True
_WORKER_THREAD_NUM = 4
TASK_RET = ""

class MyThread(threading.Thread) :

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

def nginx_conf_worker() :
    global SHARE_Q
    global TASK_SUCCESS
    global TASK_RET

    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        with open("/opt/httpguard/master/conf/nginx.conf.global.tpl", "r") as fp:
            nginx_conf = fp.read()
                
        ip = data["ip"]
        port = data["port"]
        id = data['id']
        task_id = data["task_id"]

        nginx_conf = nginx_conf.replace("{{nodeid}}",str(id))

        url = "http://{ip}:{port}/v1/save-nginx-conf".format(ip=ip, port=port)
        try:
            r = requests.post(url, data=nginx_conf,timeout=30)
            status_code = r.status_code
            if status_code != 200:
                with threadLock:
                    TASK_RET = "{TASK_RET}\nfailed: node {ip}:{port}\tsave-nginx-conf return status_code:{status_code}".format(TASK_RET=TASK_RET, ip=ip, port=port, status_code=status_code)
                    TASK_SUCCESS = False
                    continue

            content = r.content
            content = json.loads(content)
            state = content["state"]
            msg = content["msg"]
            if state == "success":
                with threadLock:
                    TASK_RET = u"{TASK_RET}\nsuccess: node {ip}:{port} \tsave-nginx-conf success.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                    mark_task_done_one(task_id)
                    continue
            else:
                with threadLock:
                    TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-nginx-conf return err:{msg}.".format(ip=ip, port=port,msg=msg, TASK_RET=TASK_RET)
                    TASK_SUCCESS = False
                    continue

        except requests.exceptions.Timeout:
            with threadLock:
                TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-nginx-conf timeout.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                TASK_SUCCESS = False
                continue

        except requests.exceptions.ConnectionError:
            with threadLock:
                TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-nginx-conf timeout.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                TASK_SUCCESS = False
                continue

def config_json_worker() :
    global SHARE_Q
    global TASK_SUCCESS
    global TASK_RET
    with open("/opt/httpguard/master/conf/httpguard_config.json", "r") as fp:
        nginx_conf = fp.read()

    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        ip = data["ip"]
        port = data["port"]
        task_id = data["task_id"]

        url = "http://{ip}:{port}/v1/save-config-json".format(ip=ip, port=port)
        try:
            r = requests.post(url, data=nginx_conf,timeout=30)
            status_code = r.status_code
            if status_code != 200:
                with threadLock:
                    TASK_RET = "{TASK_RET}\nfailed: node {ip}:{port}\tsave-config-json return status_code:{status_code}".format(TASK_RET=TASK_RET, ip=ip, port=port, status_code=status_code)
                    TASK_SUCCESS = False
                    continue

            content = r.content
            content = json.loads(content)
            state = content["state"]
            msg = content["msg"]
            if state == "success":
                with threadLock:
                    TASK_RET = u"{TASK_RET}\nsuccess: node {ip}:{port} \tsave-config-json success.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                    mark_task_done_one(task_id)
                    continue
            else:
                with threadLock:
                    TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-config-json return err:{msg}.".format(ip=ip, port=port,msg=msg, TASK_RET=TASK_RET)
                    TASK_SUCCESS = False
                    continue

        except requests.exceptions.Timeout:
            with threadLock:
                TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-config-json timeout.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                TASK_SUCCESS = False
                continue

        except requests.exceptions.ConnectionError:
            with threadLock:
                TASK_RET = u"{TASK_RET}\nfailed: node {ip}:{port} \tsave-config-json timeout.".format(ip=ip, port=port, TASK_RET=TASK_RET)
                TASK_SUCCESS = False
                continue

def heartbeat(name):
    heartbeat_file = os.path.join("/tmp",name + ".heartbeat")
    with open(heartbeat_file,"w") as fp:
        fp.write("")

def main():
    global SHARE_Q
    global TASK_SUCCESS
    global TASK_RET


    TASK_SUCCESS = True
    TASK_RET = ''
    sleep_time = 5
    task = Task.query.filter( ((Task.type=="sync_nginx_conf") | (Task.type=="sync_config_json"))  & (Task.delflag == 0) & ( Task.state != "success") ).first()
    if task is None:
        db.session.close()
        return sleep_time

    nodes = Node.query.filter_by(enable=True)
    name = task.type
    task_id = task.id

    title = u"sync config.json or nginx.conf"
    user_id = 1
    type = name
    res = None
    level = "failed"


    threads = []
    task_amount = 0
    for node in nodes :
        if node.failed_times >= 3:
            continue

        task_amount = task_amount + 1
        data = {"ip":node.ip,"port":node.port,"name":node.name,"id":node.id,"task_id":task_id}
        SHARE_Q.put(data)        

    # 开始
    mark_task_start(task_id, task_amount)
    # 同步config.json
    if name == "sync_config_json":
        for i in xrange(_WORKER_THREAD_NUM) :
            thread = MyThread(config_json_worker)
            thread.start()
            threads.append(thread)

        for thread in threads :
            thread.join()

        if TASK_SUCCESS:
            level = "success"
            mark_task_success(task_id, TASK_RET)
        else:
            level = "failed"
            mark_task_failed(task_id, TASK_RET)
            sleep_time = 60

        title = u"sync config.json"
        data = TASK_RET
        if data != '':
            make_msg(title, data, user_id, type, res, level)
        
    # 同步nginx.conf
    if name == "sync_nginx_conf":
        for i in xrange(_WORKER_THREAD_NUM) :
            thread = MyThread(nginx_conf_worker)
            thread.start()
            threads.append(thread)

        for thread in threads :
            thread.join()

        if TASK_SUCCESS:
            level = "success"
            mark_task_success(task_id, TASK_RET)
        else:
            level = "failed"
            mark_task_failed(task_id, TASK_RET)
            sleep_time = 60

        title = u"sync nginx.conf"
        data = TASK_RET
        if data != '':
            make_msg(title, data, user_id, type, res, level)

    db.session.close()
    return sleep_time
    

if __name__ == '__main__':
    main()