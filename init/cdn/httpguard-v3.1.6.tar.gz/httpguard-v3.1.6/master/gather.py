# -*- coding: utf-8 -*-

import threading
import Queue
import requests
import json
import time
import re
import ntpath
import sys
import os

os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import db,Item, Node, Discovery_item, Monitor_history

SHARE_Q = Queue.Queue()  
_WORKER_THREAD_NUM = 4

class MyThread(threading.Thread):

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

def worker() :
    global SHARE_Q
    while not SHARE_Q.empty():
        res = SHARE_Q.get(True, 2)
        key = res[0]
        ip = res[1]
        port = res[2]
        id = res[3]
        item, val, item2 = re.match(r'(.*)\[(.*)\]|(.*)', key).groups()
        if item is None: item = item2
        url = "http://{ip}:{port}/v1/monitor?item={item}&val={val}".format(ip=ip, port=port, item=item, val=val)
        try:
            r = requests.get(url,timeout=3)
            body = r.content
            body =  json.loads(body)
            msg = body["msg"]
            state = body["state"]
            if state == "success":
                if type(msg) == type([]):
                    for i in msg:
                        item = key + "[" + i["res"]+"]"
                        monitor_history = Monitor_history(id, int(time.time()), item, i["value"])
                        db.session.add(monitor_history)   
                else:
                    monitor_history = Monitor_history(id, int(time.time()), key, msg)
                    db.session.add(monitor_history)

                db.session.commit()
                db.session.close()

        except requests.exceptions.ConnectionError:
            print url + " timeout"
            continue

        except requests.exceptions.Timeout:
            print url + " timeout"
            continue

        except ValueError:
            print body + " not a valid json"
            continue


def main():
    global SHARE_Q
    threads = []
    res = db.session.query(Item.name,  Node.ip, Node.port, Node.id).outerjoin(Node).filter(Item.node_id == Node.id)
    for i in res :
        SHARE_Q.put(i)

    res = db.session.query(Discovery_item.name,  Node.ip, Node.port, Node.id).outerjoin(Node).filter(Discovery_item.node_id == Node.id)
    for i in res :
        SHARE_Q.put(i)

    for i in xrange(_WORKER_THREAD_NUM) :
        thread = MyThread(worker)
        thread.start()
        threads.append(thread)

    for thread in threads :
        thread.join()

    db.session.close()

if __name__ == '__main__':
    main()        