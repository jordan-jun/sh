# -*- coding: utf-8 -*-
import os
os.environ["HTTPGUARD_SETTINGS"] = "/opt/httpguard/master/conf/config.py"
from app import Config, Message, db, Site, Line_group, Task
from route import create_task
from public_func import make_msg,mark_task_start, mark_task_success, mark_task_failed, mark_task_del, mark_task_done_one
from sqlalchemy import desc
from time import sleep
import threading
import Queue
import json
import zlib
import json
import time
import datetime
import sys
import subprocess
import re

threadLock = threading.Lock()
SHARE_Q = Queue.Queue()  
_WORKER_THREAD_NUM = 1
_NEED_SYNC_NGINX = False


class MyThread(threading.Thread) :

    def __init__(self, func) :
        super(MyThread, self).__init__()
        self.func = func

    def run(self) :
        self.func()

def update_ca(id, key, crt):
    site = Site.query.filter_by(id=id).first()
    site.key = key
    site.crt = crt
    db.session.commit()
    db.session.close()

def worker() :
    global SHARE_Q
    global _NEED_SYNC_NGINX
    while not SHARE_Q.empty():
        data = SHARE_Q.get(True, 2)
        domain = data["domain"]
        site_id = data["site_id"]
        task_id = data["task_id"]
        user_id = data["user_id"]
        line_group_id = data["line_group_id"]
        main_domain = domain.split()[0]
        key_path = os.path.join("/root/.acme.sh/",main_domain,main_domain + ".key")
        crt_path = os.path.join("/root/.acme.sh/",main_domain,"fullchain.cer")
        cmd_list = ["/root/.acme.sh/acme.sh","--issue","--standalone","--home","/root/.acme.sh/", "--httpport","8866","--force"]
        for i in domain.split():
            cmd_list.append("-d")
            cmd_list.append(i)

        title = u"domain {main_domain} issue ca".format(main_domain=main_domain)
        type = "issue_ca"
        res = domain          
        level = "failed"
        try:
            subprocess.check_output(cmd_list,stderr=subprocess.STDOUT)
            if not os.path.exists(key_path) or not os.path.exists(crt_path):
                data = "{key_path} or {crt_path} is not found.".format(key_path=key_path,crt_path=crt_path)
                make_msg(title, data, user_id, type, res, level)
                mark_task_failed(task_id, data)
                time.sleep(60)
                continue

            with open(key_path,"r") as fp:
                key = fp.read()

            with open(crt_path,"r") as fp:
                crt = fp.read()
            
            update_ca(site_id, key, crt)
            data = None
            level = "success"
            make_msg(title, data, user_id, type, res, level)
            mark_task_success(task_id, data)
            line_group = Line_group.query.filter_by(id=line_group_id).first()
            nodes = line_group.nodes
            sync_sites = []
            for node in nodes:
                node_id = node.id
                enable = node.enable
                if not enable:
                    continue

                value = json.dumps({"node_id":node_id,"site_id":site_id,"domain":domain})
                sync_sites.append(value)
                
            create_task("sync_site", domain, json.dumps(sync_sites), user_id)

            db.session.commit()
            db.session.close()
        
        except subprocess.CalledProcessError as e:
            data = re.sub(r'\[.*?\]','',e.output)
            make_msg(title, data, user_id, type, res, level)
            mark_task_failed(task_id, data)
            time.sleep(60)


def heartbeat(name):
    heartbeat_file = os.path.join("/tmp",name + ".heartbeat")
    with open(heartbeat_file,"w") as fp:
        fp.write("")

def main():
    global SHARE_Q
    global _NEED_SYNC_NGINX
    sleep_time = 5
    threads = []
    task = Task.query.filter( (Task.type=="issue_ca") & (Task.delflag == 0) & ( Task.state != "success") ).first()
    if task is None:
        db.session.close()
        return sleep_time

    task_id = task.id
    value = task.value
    value = json.loads(value)
    domain = value["domain"]
    site_id = value["site_id"]
    line_group_id = value["line_group_id"]
    user_id = task.user_id

    main_domain = domain.split()[0]
    title = u"domain {main_domain} issue ca".format(main_domain=main_domain)
    type = "issue_ca"
    res = domain 
    level = "failed"

    data = {"domain":domain,"site_id":site_id,"task_id":task_id, "line_group_id":line_group_id,"user_id":user_id}
    SHARE_Q.put(data)

    for i in xrange(_WORKER_THREAD_NUM) :
        thread = MyThread(worker)
        thread.start()
        threads.append(thread)

    # 开始
    mark_task_start(task_id,1)
    for thread in threads :
        thread.join()


    db.session.commit()
    db.session.close()

if __name__ == '__main__':
    main()