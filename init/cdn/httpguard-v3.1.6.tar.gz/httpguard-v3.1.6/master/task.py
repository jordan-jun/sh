#coding=utf-8
from apscheduler.schedulers.blocking import BlockingScheduler
from datetime import datetime
import time
import os
import sys
import logging
logging.basicConfig()
from clean_site_relate import main as clean_site_relate_main
from domain_line import main as domain_line_main
from domain_list import main as domain_list_main
from domain_record import main as domain_record_main
from issue_ca import main as issue_ca_main
from sync_conf import main as sync_conf_main
from sync_site import main as sync_site_main

from check import main as check_main
from gather import main as gather_main
from clean import main as clean_main
from discovery_item import main as discovery_item_main
from domain_traffic import main as domain_traffic_main
from renew_ca import main as renew_ca_main
from user_package import main as user_package_main
from alarm import main as alarm_main
import subprocess

scheduler = BlockingScheduler()

def clean_site_relate():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute clean_site_relate...")

    second = int(clean_site_relate_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute clean_site_relate done.")

    second_current = scheduler.get_job("clean_site_relate").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('clean_site_relate', trigger='interval', seconds=second)

def domain_line():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_line...")

    second = int(domain_line_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_line done.")

    second_current = scheduler.get_job("domain_line").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('domain_line', trigger='interval', seconds=second)

def domain_list():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_list...")

    second = int(domain_list_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_list done.")

    second_current = scheduler.get_job("domain_list").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('domain_list', trigger='interval', seconds=second)

def domain_record():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_record...")

    second = int(domain_record_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_record done.")

    second_current = scheduler.get_job("domain_record").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('domain_record', trigger='interval', seconds=second)

def issue_ca():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute issue_ca...")

    issue_ca_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute issue_ca done.")

def sync_conf():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute sync_conf...")

    second = int(sync_conf_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute sync_conf done.")

    second_current = scheduler.get_job("sync_conf").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('sync_conf', trigger='interval', seconds=second)

def sync_site():
    global scheduler
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute sync_site...")

    second = int(sync_site_main())
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute sync_site done.")

    second_current = scheduler.get_job("sync_site").trigger.interval.seconds

    if second_current != second:
        scheduler.reschedule_job('sync_site', trigger='interval', seconds=second)

def check():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute check...")

    check_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute check done.")

# def gather():
#     print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute gather...")

#     gather_main()
#     print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute gather done")

def clean():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute clean...")

    clean_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute clean done.")

def discovery_item():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute discovery_item...")

    discovery_item_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute discovery_item done.")

def domain_traffic():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_traffic...")

    domain_traffic_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute domain_traffic done.")

def renew_ca():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute renew_ca...")

    renew_ca_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute renew_ca done.")

def user_package():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute user_package...")

    user_package_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute user_package done.")

def alarm():
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute alarm...")

    alarm_main()
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " excute alarm done.")

def main():
    scheduler.add_job(clean_site_relate,'interval', seconds=5 ,id="clean_site_relate")
    scheduler.add_job(domain_line,'interval', seconds=5 ,id="domain_line")
    scheduler.add_job(domain_list,'interval', seconds=5 ,id="domain_list")
    scheduler.add_job(domain_record,'interval', seconds=5 ,id="domain_record")
    scheduler.add_job(issue_ca,'interval', seconds=5 ,id="issue_ca")
    scheduler.add_job(sync_conf,'interval', seconds=5 ,id="sync_conf")
    scheduler.add_job(sync_site,'interval', seconds=5 ,id="sync_site")

    scheduler.add_job(check,'interval', seconds=60 ,id="check")
    #scheduler.add_job(gather,'interval', seconds=60 ,id="gather")
    scheduler.add_job(clean,'interval', seconds=300 ,id="clean")
    scheduler.add_job(discovery_item,'interval', seconds=300 ,id="discovery_item")
    scheduler.add_job(domain_traffic,'interval', seconds=300 ,id="domain_traffic")
    scheduler.add_job(renew_ca,'interval', seconds=1800 ,id="renew_ca")
    scheduler.add_job(user_package,'interval', seconds=300 ,id="user_package")
    scheduler.add_job(alarm,'interval', seconds=60 ,id="alarm")

    scheduler.start()


if __name__ == '__main__':
    main()      