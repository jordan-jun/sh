export HTTPGUARD_SETTINGS=/opt/httpguard/master/conf/config.py
export FLASK_APP="/opt/httpguard/master/run.py"
export FLASK_DEBUG=1
flask run -h 0.0.0.0 -p 88 --with-threads
