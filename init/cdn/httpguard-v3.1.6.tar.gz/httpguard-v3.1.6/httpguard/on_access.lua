-- Copyright (C) Maohai Zhu (admin@centos.bz).
local rule = require "resty.rule"
local acl_rule = require "resty.acl_rule"
local route = require "resty.route"
local pcall = pcall
local log = ngx.log
local ERR = ngx.ERR


local ok, err = pcall(rule.run)
if not ok then
    log(ERR, "rule.run error:",err)
end

local ok, err = pcall(route.run)
if not ok then
    log(ERR, "route.run error:",err)
end

local ok, err = pcall(acl_rule.run)
if not ok then
    log(ERR, "acl_rule.run error:",err)
end



