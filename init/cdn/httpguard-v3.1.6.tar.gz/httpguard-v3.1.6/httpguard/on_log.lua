-- Copyright (C) Maohai Zhu (admin@centos.bz).

local log = require "resty/log"

log.run()