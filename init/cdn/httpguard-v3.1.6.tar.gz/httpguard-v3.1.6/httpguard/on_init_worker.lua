-- Copyright (C) Maohai Zhu (admin@centos.bz).

local util = require "resty.util"
local config_util = require "resty.config_util"
local config = require "resty.config"
if ngx.worker.id() == nil then
    ngx.log(ngx.ERR,"nginx lua version:", ngx.config.ngx_lua_version)
    return
end
util.save_worker_pid()
util.do_timed_job()
config_util.add_internal_rule(config)