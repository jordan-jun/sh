-- Copyright (C) Maohai Zhu (admin@centos.bz).

local json = require "resty.dkjson"
local util = require "resty.config_util"

local log = ngx.log
local ERR = ngx.ERR
local current_script_path = debug.getinfo(1, "S").source:sub(2)
local lua_root_path = current_script_path:sub( 1, 0 - string.len("/lib/resty/config.lua") -1 )

local function load_config()
    local config_path = lua_root_path .. "/conf/config.json"
    local file = io.open( config_path, "r")
    local config
    if file == nil then
        log(ERR, "config.json file not found.")
        return
    else
        local data = file:read("*all")
        file:close()
        config = json.decode(data)
        if config == nil then
            log(ERR, "decode file ", config_path, " failed")
            return
        end    
    end

    config.other = {}
    config.other.pkey = config.pkey ~= "" and config.pkey or util.make_random()
    local captcha_html = util.read_file_data(config.captcha_html_path)
    config.other.captcha_html = string.gsub(captcha_html,"{#BASE_URI}",config.base_uri)
    os.execute("gzip -f -c -9 ".. config.browser_verify_auto_html_path.. " > "..config.browser_verify_auto_html_path..".gz")
    os.execute("gzip -f -c -9 ".. config.slide_html_path .. " > " .. config.slide_html_path..".gz")
    os.execute("gzip -f -c -9 /opt/httpguard/httpguard/conf/encrypt.js > /opt/httpguard/httpguard/conf/encrypt.js.gz")

    config.other.browser_verify_auto_html = util.read_file_data(config.browser_verify_auto_html_path..".gz")
    config.other.slide_html = util.read_file_data(config.slide_html_path..".gz")
    config.other.encrypt_js = util.read_file_data("/opt/httpguard/httpguard/conf/encrypt.js.gz")

    config.other.white_ip_list = util.load_ip_from_string(config.whitelist)
    config.other.black_ip_list = util.load_ip_from_string(config.blacklist)
    -- 获取机器码
    config.other.machine_code = util.get_machine_code()

    return config
end

return load_config()
