-- Copyright (C) Maohai Zhu (admin@centos.bz).

local filter = require "resty.filter"
local util = require "resty.util"
local logger = require "resty.logger"
local resty_lock = require "resty.lock"

local dict = ngx.shared.guard
local ngx_exit = ngx.exit

local function iptables_only(ip)
    dict:lpush("pending-to-iptables", ip)
    ngx_exit(444)
end

local function iptables(ip)
    local pending_key = table.concat({ip,"pending"})
    local lock, err = resty_lock:new("guard")
    local lock_key = table.concat({ip,"lock"})
    local elapsed, err = lock:lock(lock_key)

    if not dict:get(pending_key) then
        dict:lpush("pending-to-iptables", ip)
        dict:add(pending_key,true)
    end

    local ok, err = lock:unlock()
    ngx_exit(444)
end

local function exit_code(status_code)
    ngx_exit(status_code)
end

return {
    iptables = iptables,
    exit_code = exit_code,
    iptables_only = iptables_only
}