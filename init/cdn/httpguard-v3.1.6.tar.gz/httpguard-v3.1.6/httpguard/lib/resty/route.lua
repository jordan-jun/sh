-- Copyright (C) Maohai Zhu (admin@centos.bz).

local json = require "resty.dkjson"
local util = require "resty.util"
local config_util = require "resty.config_util"
local config= require "resty.config"
local aes = require "resty.aes"
local filter = require "resty.filter"
local resty_md5 = require "resty.md5"
local log_dict = ngx.shared.log

local dict_captcha = ngx.shared.dict_captcha
local dict_black = ngx.shared.black
local dict_white = ngx.shared.white
local ngx_header = ngx.header
local ngx_print = ngx.print
local ngx_exit = ngx.exit
local string_lower = string.lower
local string_find = string.find
local string_sub = string.sub
local string_match = string.match
local dict = ngx.shared.guard
local get_headers = ngx.req.get_headers
local read_body = ngx.req.read_body
local get_body_data = ngx.req.get_body_data
local ngx_var = ngx.var
local table_concat =table.concat
local package_loaded =package.loaded
local get_method = ngx.req.get_method
local ngx_time = ngx.time
local math_randomseed = math.randomseed
local math_random = math.random
local ngx_md5 = ngx.md5
local aes_salt = "P563RDWn"
local encode_base64 = ngx.encode_base64
local decode_base64 = ngx.decode_base64
local table_insert = table.insert
local io_open = io.open
local re_match = ngx.re.match
local string_len = string.len
local string_reverse = string.reverse
local uri_args = ngx.req.get_uri_args
local logger = require "resty.logger"

-- 返回验证码图片
local function return_captcha()
    -- 获取客户端IP
    local client_ip = ngx_var.client_ip

    local now = ngx_time()
    math_randomseed(now)
    local random = math_random(1,10000) 
    -- 随机获取验证码
    local captcha_value = dict_captcha:get(random) 
    -- 记录此验证码到cookie
    local aes_key = filter.generate_key1(client_ip)
    local random_encrypt = filter.aes_encrypt(random, aes_key)
    -- 获取验证码图片
    local captcha_img = dict_captcha:get(captcha_value) 
    ngx_header['Set-Cookie'] = {table_concat({"random=",random_encrypt,"; path=/"})}
    ngx_header.content_type = "image/jpeg"
    ngx_print(captcha_img)
    ngx_exit(200)

end

-- 验证提交上来的验证码
local function verify_captcha()
    -- 获取post上传的json数据response
    read_body()
    local body = get_body_data() -- {"response":xxxxx}
    local body_json = json.decode(body)
    local response_post_arg = body_json["response"]

    -- 获取客户端IP
    local client_ip = ngx_var.client_ip
    local site_id = ngx_var.site_id

    -- post过来的验证码
    local response_post_arg = string_lower(response_post_arg) 

    -- 根据cookie中的加密random查找验证码
    -- 解密random
    local random = ngx_var["cookie_random"]
    if not random then
        logger.debug("no random")
        local info = {state = "failed",msg = ""}
        util.echo_json(info)
    end
        
    random = filter.decode_base64(random)
    if not random then
        logger.debug("decode_base64 random failed")
        local info = {state = "failed",msg = ""}
        util.echo_json(info)
    end
    
    local random_plain = filter.aes_decrypt(random, filter.generate_key1(client_ip))
    if not random_plain then
        logger.debug("first decrypt random failed")
        random_plain = filter.aes_decrypt(random, filter.generate_key2(client_ip))
        if not random_plain then
            logger.debug("second decrypt random failed")
            local info = {state = "failed",msg = ""}
            util.echo_json(info)
        end
    end    

    local captcha_value = dict_captcha:get(random_plain)
    local info
    if captcha_value == response_post_arg then
        filter.add_to_tmp_whitelist(client_ip, config.temp_whitelist_time, config.filter,site_id)
        info = {state = "success",msg = ""}
    else
        info = {state = "failed",msg = ""}
    end

    util.echo_json(info)
end

-- 返回机器码
local function return_machine_code()
    local machine_code = config.other.machine_code
    local info
    if machine_code then
        info = {state = "success", msg = machine_code}
    else
        info = {state = "failed", msg = nil}
    end
    util.echo_json(info)
end

-- 生效配置
local function reload_config()
    util.mark_config_reload()
    local info = {state = "success", msg="等待2秒生效配置"}
    -- 返回保存状态
    util.echo_json(info)    
end

local function nginx_status()
    local connections_active = ngx_var.connections_active
    local connections_reading = ngx_var.connections_reading
    local connections_writing = ngx_var.connections_writing
    local connections_waiting = ngx_var.connections_waiting
    local nginx_workers_cpu_time = dict:get("nginx_workers_cpu_time") or 0
    local status = {connection = {  connections_active = connections_active, 
                                    connections_reading = connections_reading, 
                                    connections_writing = connections_writing, 
                                    connections_waiting = connections_waiting
                                 },
                    cpu = nginx_workers_cpu_time            
                     }
    local info = {state = "success", msg=status}                 
    util.echo_json(info)
end


local function host_traffic()
    local now = ngx_time()
    local last_minute = now - (now % 60) - 60
    local host_list = util.get_host_list()
    local host_traffic_list = {}
    for _,host in pairs(host_list) do
        local key = table_concat({host,last_minute,"traffic"})
        local sum = log_dict:get(key) or 0
        local traffic = tonumber(string.format("%.1f", sum/60))
        table_insert(host_traffic_list,{res=host,value=traffic})
    end    

    local info = {state = "success" ,msg =host_traffic_list }
    util.echo_json(info)
end

local function host_req()
    local now = ngx_time()
    local last_minute = now - (now % 10) - 10
    local host_list = util.get_host_list()
    local host_req_list = {}
    for _,host in pairs(host_list) do
        local key = table_concat({host,last_minute,"req"})
        local sum = log_dict:get(key) or 0
        local qps = tonumber(string.format("%.1f", sum/10))
        table_insert(host_req_list,{res=host,value=qps})
    end    

    local info = {state = "success" ,msg =host_req_list }
    util.echo_json(info)
end

local function encrypt_js()
    ngx_header.content_type = "application/javascript"
    ngx_header.content_encoding= "gzip"
    ngx_print(config.other.encrypt_js)
    ngx_exit(200)    
end

local function clean_site_blacklist()
    read_body()
    local body = get_body_data()
    local body_json = json.decode(body)
    local site_id = body_json["site_id"]
    local ip
    local ip_table = {}

    dict:set("get_keys_black", true, 10)
    local black_list = dict_black:get_keys(0)
    dict:delete("get_keys_black")

    for _,key in pairs(black_list) do
        if string_find(key, "^" .. site_id .."%-") then
            dict:delete(key)
            dict_black:delete(key)
            local m = re_match(key,".*-(.*)-.*")
            ip = m[1]

            -- 清除计数
            for filter_name,_ in pairs(config.filter) do
                local challenge_key = table_concat({ip,filter_name,site_id})
                dict:delete(challenge_key)
            end

            dict:delete(table_concat({ip,"400",site_id}))
            dict:delete(table_concat({ip,"404",site_id}))
            dict:delete(table_concat({ip,"301",site_id}))

            table_insert(ip_table, ip)
        end
    end
    
    local ip_list = table_concat(ip_table, ",")
    local info = {state = "success" ,msg = ip_list}
    util.echo_json(info)
end

local function clean_site_whitelist()
    read_body()
    local body = get_body_data()
    local body_json = json.decode(body)
    local site_id = body_json["site_id"]
    dict:set("get_keys_white", true, 10)
    local white_list = dict_white:get_keys(0)
    dict:delete("get_keys_white")

    for _,key in pairs(white_list) do
        if string_find(key, "^" .. site_id .."%-") then
            ngx.log(ngx.ERR,key)
            dict:delete(key)
            dict_white:delete(key)
        end
    end
    
    local info = {state = "success" ,msg = nil}
    util.echo_json(info)

end

local function domain_auto_cc_state()
    local auto_cc_rule = config.auto_cc_rule
    local auto_cc_state_list = {}
    for host,_ in pairs(auto_cc_rule) do
        local auto_rule_key = host .. "-auto_rule"
        local value
        if dict:get(auto_rule_key) then
            value = "on"
        else
            value = "off"
        end
        table_insert(auto_cc_state_list,{res=host,value=value})
    end
    local info = {state = "success" ,msg = auto_cc_state_list}
    util.echo_json(info)
end

-- 路由表
local route_table = {
    ["/captcha.png"] = {
        GET = {auth=false, handler=return_captcha}
    },
    ["/verify-captcha"] = {
        POST = {auth=false, handler=verify_captcha}
    },
    ["/encrypt.js"] = {
        GET = {auth=false, handler=encrypt_js}
    },    
    ["/get-machine-code"] = {
        GET = {auth=true, handler=return_machine_code}
    },
    ["/reload-config"] = {
        POST = {auth=true, handler=reload_config}
    },       
    ["/nginx-status"] = {
        GET = {auth=true, handler=nginx_status}
    }, 
    ["/host-traffic"] = {
        GET = {auth=true, handler=host_traffic}
    },
    ["/host-req"] = {
        GET = {auth=true, handler=host_req}
    }, 
    ["/clean-site-blacklist"] = {
        POST = {auth=true, handler=clean_site_blacklist}
    },
    ["/clean-site-whitelist"] = {
        POST = {auth=true, handler=clean_site_whitelist}
    },
    ["/domain-auto-cc-state"] = {
        GET = {auth=true, handler=domain_auto_cc_state}
    },    
}

local function run()
    local uri = ngx_var.uri
    local start, ends = string_find(uri, config.base_uri, 1, true)
    if not start then
        return
    end

    local sub_path = string_sub(uri, ends)

    -- 如果没有找到api就读取本地文件
    local api_obj = route_table[sub_path]
    if not api_obj then
        ngx_exit(404)
    end

    local method = get_method()
    -- 获取客户端IP
    local client_ip = ngx_var.client_ip

    if not api_obj[method] then
        ngx_exit(405)
    end

    if api_obj[method].auth and client_ip ~= config.local_api_allow_ip then
        ngx_exit(403)
    end
    
    api_obj[method].handler()
end

return {
    run = run,
    return_captcha = return_captcha,
    verify_captcha = verify_captcha,
    return_machine_code = return_machine_code,
    reload_config = reload_config,
    nginx_status = nginx_status,
    get_iptables_list = get_iptables_list

}
