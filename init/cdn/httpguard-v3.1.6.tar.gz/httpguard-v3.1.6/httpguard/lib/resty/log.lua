local log_dict = ngx.shared.log
local ngx_var = ngx.var
local table_concat = table.concat
local ngx_time = ngx.time
local get_resp_headers = ngx.resp.get_headers
local filter = require "resty.filter"
local util = require "resty.util"
local config = require "resty.config"
local rule = require "resty.rule"
local get_headers = ngx.req.get_headers
local dict = ngx.shared.guard
local dict_black = ngx.shared.black
local action = require "resty.action"

local function log_host_traffic(host)
    local now = ngx_time()
    local current_minute = now - (now % 60)
    local key = table_concat({host,current_minute,"traffic"})
    local bytes_sent = ngx_var.bytes_sent
    local newval, err = log_dict:incr(key, bytes_sent)
    if not newval and err == "not found" then
        log_dict:add(key, 0)
        log_dict:incr(key, bytes_sent)
    end
end

local function log_host_req(host)
    local now = ngx_time()
    local current_minute = now - (now % 10)
    local key = table_concat({host,current_minute,"req"})
    local newval, err = log_dict:incr(key, 1)
    if not newval and err == "not found" then
        log_dict:add(key, 0)
        log_dict:incr(key, 1)
    end
end


-- 400 404 302 301状态码统计,封锁
local function block_some_status_code(status, uri)
    local rule_name = ngx_var.rule_name
    local site_id = ngx.ctx.site_id
    if site_id == nil then
        site_id = 0
    end    

    -- 获取客户端IP
    local remote_ip = ngx_var.remote_addr
    local headers = get_headers()    
    local client_ip = util.get_client_ip(remote_ip, headers[config.ip_header_name])
    ngx_var.client_ip = client_ip
        
    local is_white = rule.is_in_tmp_white_ip_list(client_ip, site_id)

    if (rule_name == "close") or (is_white == true) then
        return
    end    

    if status == 400 then
        local c400 = config.intercept400
        local state = c400.state
        if not state then
            return
        end
            
        local within_seconds = c400.within_seconds
        local max_req = c400.max_req

        local filter_name = "400"
        local count = filter.get_challenge_count(client_ip, within_seconds, filter_name)
        if count > max_req then
            filter.block(client_ip, site_id, config.filter, config.temp_blacklist_block_time)
            action.iptables_only(client_ip)
        end

    elseif status == 404 then
        -- 不统计favicon.ico
        if uri == "/favicon.ico" then
            return
        end

        local c404 = config.intercept404
        local state = c404.state
        if not state then
            return
        end
            
        local within_seconds = c404.within_seconds
        local max_req = c404.max_req

        local filter_name = "404"
        local count = filter.get_challenge_count(client_ip, within_seconds, filter_name)
        if count > max_req then
            filter.block(client_ip, site_id, config.filter, config.temp_blacklist_block_time)
        end
        
    elseif (status == 301) or (status == 302) then
        local c301 = config.intercept301
        local within_seconds = c301.within_seconds
        local filter_name = "301"
        local max_req = c301.max_req
        local state = c301.state

        if state and not (rule_name == "redirect_filter") then
            local count = filter.get_challenge_count(client_ip, within_seconds, filter_name)
            if count > max_req then
                filter.block(client_ip, site_id, config.filter, config.temp_blacklist_block_time)
                action.iptables_only(client_ip)
            end
        end
                  
    end 
end

-- 记录content type
local function record_content_type(status, host, uri)
    local content_type = get_resp_headers()['content-type']
    local scheme = ngx.ctx.scheme
    local url = table_concat({scheme,"://",host,uri})
    if not dict:get(url) and status == 200 then
        dict:set(url, content_type, 604800)
    end
end

local function run()
    local host = ngx.ctx.host
    local status = ngx.status
    local uri = ngx.ctx.uri

    block_some_status_code(status, uri)
    if host == nil then
        return
    end    
    log_host_traffic(host)
    log_host_req(host)
    record_content_type(status,host,uri)
end

return {
    run = run
}