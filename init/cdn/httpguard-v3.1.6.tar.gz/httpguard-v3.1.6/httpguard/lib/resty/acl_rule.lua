-- Copyright (C) Maohai Zhu (admin@centos.bz).

local util = require "resty.util"
local config = require "resty.config"

local ngx_var = ngx.var
local get_headers = ngx.req.get_headers
local re_find = ngx.re.find
local ipairs = ipairs
local ngx_exit = ngx.exit

-- 比较值
local function test_val(cond, val, op)
    if not val then
        return false
    end
        
    if op == "=" then
        return (cond == val)
    elseif op == "!=" then
        return (cond ~= val)
    elseif op == "~" then

        local from, to, err = re_find(val, cond, "jio")
        return ( from ~= nil)    

    elseif op == "!~" then
        local from, to, err = re_find(val, cond, "jio")
        return ( from == nil)    
    end

    return false
end

-- 匹配请求
local function match_request(acl_matcher, client_ip, user_agent, referer, req_uri, accept_language, geoip_country_code)
    -- 获取匹配器里各字段的值
    local matcher_ip = acl_matcher.ip
    local matcher_accept_language = acl_matcher.accept_language
    local matcher_user_agent = acl_matcher.user_agent
    local matcher_referer = acl_matcher.referer
    local matcher_uri = acl_matcher.uri
    local matcher_country_iso_code = acl_matcher.country_iso_code

    -- 定义匹配变量,布尔
    local ip_match = true
    local accept_language_match = true
    local user_agent_match = true
    local referer_match = true
    local uri_match = true
    local country_iso_code_match = true


    -- 匹配IP
    if matcher_ip then ip_match = test_val(matcher_ip.acl_match_val, client_ip, matcher_ip.acl_match_op) end

    -- 匹配accept_language
    if matcher_accept_language then accept_language_match = test_val(matcher_accept_language.acl_match_val, accept_language, matcher_accept_language.acl_match_op) end

    -- 匹配user_agent
    if matcher_user_agent then user_agent_match = test_val(matcher_user_agent.acl_match_val, user_agent, matcher_user_agent.acl_match_op) end

    -- 匹配referer
    if matcher_referer then referer_match = test_val(matcher_referer.acl_match_val, referer, matcher_referer.acl_match_op) end

    -- 匹配uri
    if matcher_uri then uri_match = test_val(matcher_uri.acl_match_val, req_uri, matcher_uri.acl_match_op) end

    -- 匹配country_iso_code
    if matcher_country_iso_code then country_iso_code_match = test_val(matcher_country_iso_code.acl_match_val, geoip_country_code, matcher_country_iso_code.acl_match_op) end
    
    return (ip_match and accept_language_match and user_agent_match and referer_match and uri_match and country_iso_code_match)
end


local function apply_rule(acl_data, default_action, client_ip, user_agent, referer, req_uri, accept_language, geoip_country_code)
    for _, v in ipairs(acl_data) do
        local acl_action = v.acl_action
        local acl_matcher = v.acl_matcher

        -- 匹配
        if match_request(acl_matcher, client_ip, user_agent, referer, req_uri, accept_language, geoip_country_code) then
            -- 执行动作
            if acl_action == "allow" then
                return
            else
                ngx_exit(403)
            end
        end
    end

    -- 默认行为
    if default_action == "allow" then
        return
    else
        ngx_exit(403)
    end    
end


local function run()
    -- 获取客户端IP
    local client_ip = ngx.ctx.client_ip
    local headers = ngx.ctx.headers

    -- 获取user_agent,referer,host,uri
    local user_agent = headers.user_agent
    local referer = headers.referer
    local req_uri = ngx.ctx.req_uri
    local accept_language = headers.accept_language
    local geoip_country_code = ngx_var.geoip_country_code
    local acl_rule = ngx_var.acl_rule

    -- 是否开启访问控制
    if not acl_rule or (acl_rule == "") then
        return
    end

    local rule = config.acl_rule[acl_rule] 
    local default_action = rule.default_action
    local acl_data = rule.acl_data

    -- 应用规则
    apply_rule(acl_data, default_action, client_ip, user_agent, referer, req_uri, accept_language, geoip_country_code)
end

return {
    test_val = test_val,
    match_request = match_request,
    apply_rule = apply_rule,
    run = run
}
