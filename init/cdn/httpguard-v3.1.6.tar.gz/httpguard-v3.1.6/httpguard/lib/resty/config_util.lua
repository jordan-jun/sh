-- Copyright (C) Maohai Zhu (admin@centos.bz).

local json = require "resty.dkjson"
local io_open = io.open
local log = ngx.log
local ERR = ngx.ERR
local table_concat = table.concat
local table_insert = table.insert
local table_getn = table.getn
local ngx_md5 = ngx.md5
local ngx_time = ngx.time
local math_randomseed = math.randomseed
local math_random = math.random
local string_sub = string.sub
local ac = require "ahocorasick"
local re_find = ngx.re.find
local string_find = string.find

-- 比较值
local function test_val(cond, val, op)
    if not val then
        return false
    end
        
    if op == "=" then
        return (cond == val)
    elseif op == "!=" then
        return (cond ~= val)

    elseif op == "~" then
        return ( re_find(val, cond, "jio") ~= nil)    
    elseif op == "!~" then
        return ( re_find(val, cond, "jio") == nil)    

    elseif op == "contain" then
        return ( string_find(val, cond, 1, true) ~= nil) 
    elseif op == "!contain" then
        return ( string_find(val, cond, 1, true) == nil)      

    elseif op == "AC" then
        local acinst = ac.create(cond)
        return ( ac.match(acinst, val) ~= nil) 
    elseif op == "!AC" then
        local acinst = ac.create(cond)
        return ( ac.match(acinst, val) == nil) 

    end

    return false
end

-- 自动添加内置规则
local function add_internal_rule(config)
    local rule_group = config.rules
    for k in pairs(rule_group) do
        local rules = rule_group[k]
        local need_internal_rule = false
        if not (type(rules) == "table") then
            goto continue
        end   

        for _, rule in ipairs(rules) do
            local match_name = rule.matcher
            local filter_name1 = rule.filter1
            local filter_name2 = rule.filter2
            local match = config.matcher[match_name] 

            local filter_match = false
            local filter = config.filter[filter_name1]
            if not (filter_name2 == "") then
                filter = config.filter[filter_name2]
            end
            if (filter.type == "slide") or (filter.type == "captcha") or (filter.type == "browser_verify_auto") then
                filter_match = true
            end  

            if match.content_type ~= nil then 
                local jpeg_true = test_val(match.content_type.value, "image/jpeg", match.content_type.operator)
                local json_true = test_val(match.content_type.value, "application/json", match.content_type.operator)
                local javascript_true = test_val(match.content_type.value, "application/javascript", match.content_type.operator)
                if  jpeg_true and json_true and javascript_true then
                    if filter_match == true then
                        need_internal_rule = true
                    end
                    break
                end    
            elseif match.req_uri ~= nil then
                local captcha_png_true = test_val(match.req_uri.value, "captcha.png", match.req_uri.operator)
                local verify_captcha_true = test_val(match.req_uri.value, "verify-captcha", match.req_uri.operator)
                local encrypt_js_true = test_val(match.req_uri.value, "encrypt.js", match.req_uri.operator)

                if captcha_png_true and verify_captcha_true and encrypt_js_true then
                    if filter_match == true then
                        need_internal_rule = true
                    end
                    break
                end      
            elseif match.uri ~= nil then
                local captcha_png_true = test_val(match.uri.value, "captcha.png", match.uri.operator)
                local verify_captcha_true = test_val(match.uri.value, "verify-captcha", match.uri.operator)
                local encrypt_js_true = test_val(match.uri.value, "encrypt.js", match.uri.operator)
                if captcha_png_true and verify_captcha_true and encrypt_js_true then
                    if filter_match == true then
                        need_internal_rule = true
                    end 
                    break
                end 
            else
                if filter_match == true then
                    need_internal_rule = true
                end     
                break  
            end
        end

        if need_internal_rule == true then
            if not (table_getn(rules) == 0) then
                local action = rules[1].action
                local internal_rule = {state=true,matcher="match_internal_source",filter1="internal_source_filter",filter2="",action=action}
                table_insert(rule_group[k], 1, internal_rule)
                log(ERR,"add a internal_rule to ",k)
            end
        end    

        ::continue::
    end
end

local function make_random()
    local char="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    math_randomseed(ngx_time()) 
    local r1 = math_random(1,62) 
    local r2 = math_random(1,62) 
    local r3 = math_random(1,62) 
    local r4 = math_random(1,62)
    local r5 = math_random(1,62) 
    local r6 = math_random(1,62) 
    local r7 = math_random(1,62)
    local r8 = math_random(1,62)
    local s1 = string_sub(char,r1,r1)
    local s2 = string_sub(char,r2,r2)
    local s3 = string_sub(char,r3,r3)
    local s4 = string_sub(char,r4,r4)
    local s5 = string_sub(char,r5,r5)
    local s6 = string_sub(char,r6,r6)
    local s7 = string_sub(char,r7,r7)
    local s8 = string_sub(char,r8,r8)
    local random = table_concat({s1, s2, s3, s4, s5, s6, s7, s8})
    return random
end

-- 获取机器码
local function get_machine_code()
    local route_fp = io_open("/proc/net/route")
    local default_dev,route_ip
    if not route_fp then
        log(ERR, "open /proc/net/route failed.")
        return nil, "route_file open failed."
    end

    -- 获取路由IP及默认网卡名称
    for line in route_fp:lines() do
        local m1, m2, m3 = string.match(line,"(%S+)%s+(%S+)%s+(%S+)")
        if m2 == "00000000" then
            default_dev = m1
            route_ip = m3
            break
        end
    end

    if not default_dev then
        log(ERR, "get default_dev failed")
        return nil, "get default dev failed"
    end
    
    if not route_ip then
        log(ERR, "get route ip failed")
        return nil, "get route ip failed"
    end

    -- 根据默认网卡名称获取网卡mac地址
    local addr_file = table_concat({"/sys/class/net/",default_dev,"/address"})
    local addr_fp = io_open(addr_file)

    if not addr_fp then
        log(ERR, "open ",addr_file, " failed.")
        return nil, "addr_file open failed"
    end
        
    local mac_addr = addr_fp:read("*all")
    return ngx_md5(table_concat({mac_addr, route_ip}))
end

local function read_file_data(path)
    local file = io.open(path, "r")
    if file == nil then
        log(ERR, "open ",path, " file failed.")
        return
    else
        local data = file:read("*all")
        file:close()
        return data
    end
end

local function get_ip_list(ip)
    local tonumber, print = tonumber, print
    local a, b, ip1, ip2, ip3, ip4, mask = ip:find( '(%d+).(%d+).(%d+).(%d+)/(%d+)')
    if not a then return {ip} end
    local ip = { tonumber( ip1 ), tonumber( ip2 ), tonumber( ip3 ), tonumber( ip4 ) }
    --list masks => wildcard
    local masks = {
        [1] = { 127, 255, 255, 255 },
        [2] = { 63, 255, 255, 255 },
        [3] = { 31, 255, 255, 255 },
        [4] = { 15, 255, 255, 255 },
        [5] = { 7, 255, 255, 255 },
        [6] = { 3, 255, 255, 255 },
        [7] = { 1, 255, 255, 255 },
        [8] = { 0, 255, 255, 255 },
        [9] = { 0, 127, 255, 255 },
        [10] = { 0, 63, 255, 255 },
        [11] = { 0, 31, 255, 255 },
        [12] = { 0, 15, 255, 255 },
        [13] = { 0, 7, 255, 255 },
        [14] = { 0, 3, 255, 255 },
        [15] = { 0, 1, 255, 255 },
        [16] = { 0, 0, 255, 255 },
        [17] = { 0, 0, 127, 255 },
        [18] = { 0, 0, 63, 255 },
        [19] = { 0, 0, 31, 255 },
        [20] = { 0, 0, 15, 255 },
        [21] = { 0, 0, 7, 255 },
        [22] = { 0, 0, 3, 255 },
        [23] = { 0, 0, 1, 255 },
        [24] = { 0, 0, 0, 255 },
        [25] = { 0, 0, 0, 127 },
        [26] = { 0, 0, 0, 63 },
        [27] = { 0, 0, 0, 31 },
        [28] = { 0, 0, 0, 15 },
        [29] = { 0, 0, 0, 7 },
        [30] = { 0, 0, 0, 3 },
        [31] = { 0, 0, 0, 1 }
    }
    --get wildcard
    local wildcard = masks[tonumber( mask )]
    --number of ips in mask
    local ipcount = math.pow( 2, ( 32 - mask ) )
    --network IP (route/bottom IP)
    local bottomip = {}
    for k, v in pairs( ip ) do
        --wildcard = 0?
        if wildcard[k] == 0 then
            bottomip[k] = v
        elseif wildcard[k] == 255 then
            bottomip[k] = 0
        else
            local mod = v % ( wildcard[k] + 1 )
            bottomip[k] = v - mod
        end
    end
    local ip1 = bottomip[1]
    local ip2 = bottomip[2]
    local ip3 = bottomip[3]
    local ip4 = bottomip[4]
    local iplist = {}
    for i=1,ipcount do
        local ip = table.concat({ip1,".",ip2,".",ip3,".",ip4})
        table.insert(iplist,ip)
        if ip4 == 256 then
                ip4 = 0
                ip3 = ip3 + 1  
        end
        if ip3 == 256 then
                ip3 = 0
                ip2 = ip2 + 1
        end
        if ip2 == 256 then
                ip2 = 0
                ip1 = ip1 + 1
        end
        ip4 = ip4 + 1
    end
    return iplist
end


local function load_ip_from_file(path)
    local ip_list = {}
    local tmp
    local file = io.open(path,'r')
    if file == nil then
        log(ERR, "open ",path," file failed.")
        return {}
    end

    for line in file:lines() do
        tmp = get_ip_list(line)
        for _,v in ipairs(tmp) do
            ip_list[v] = true
        end    
    end
    ip_list["127.0.0.1"] = true
    return ip_list
end

local function load_ip_from_string(data)
    local ip_list = {}
    local tmp

    for line in string.gmatch(data, "[^ ]+") do
        tmp = get_ip_list(line)
        for _,v in ipairs(tmp) do
            ip_list[v] = true
        end    
    end
    ip_list["127.0.0.1"] = true
    return ip_list
end

return {
    make_random = make_random,
    get_machine_code = get_machine_code,
    read_file_data = read_file_data,
    get_ip_list = get_ip_list,
    load_ip_from_file = load_ip_from_file,
    load_ip_from_string = load_ip_from_string,
    add_internal_rule = add_internal_rule,
}